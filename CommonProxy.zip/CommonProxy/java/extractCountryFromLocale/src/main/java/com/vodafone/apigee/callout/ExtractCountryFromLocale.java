package com.vodafone.apigee.callout;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Locale;
import com.apigee.flow.execution.ExecutionContext;
import com.apigee.flow.execution.ExecutionResult;
import com.apigee.flow.execution.spi.Execution;
import com.apigee.flow.message.MessageContext;

public class ExtractCountryFromLocale implements Execution{

	private final Map<String,String> parameters; // read-only
	private String languageLocale,countryCode;
	 public ExtractCountryFromLocale(Map<String, String> props){
		 parameters = new HashMap<String,String>();
	       Iterator iterator = props.keySet().iterator();
	       while(iterator.hasNext()){
	           Object key = iterator.next();
	           Object value = props.get(key);
	           if ((key instanceof String) && (value instanceof String)) {           
	               parameters.put((String) key, (String) value);
	           }
	       }
	 }
	 
	public ExecutionResult execute(MessageContext msgCtx, ExecutionContext extCtx) {
		languageLocale = msgCtx.getVariable(parameters.get("languageLocale"));
		if(languageLocale == null){
			msgCtx.setVariable("errorJSON", (Object)"a42_generic_internal_config_error");
			return ExecutionResult.ABORT;
		}
		else{
			if(languageLocale.contains("_")){
				languageLocale = languageLocale.replace("_", "-");
			}
			Locale loc = Locale.forLanguageTag(languageLocale);
			countryCode = loc.getCountry();
			msgCtx.setVariable("country", (Object)countryCode);
			return ExecutionResult.SUCCESS;
		}
	}
	/*public void ExecutionResultTest(){
		languageLocale = "en_UK";
		if(languageLocale.contains("_")){
			languageLocale = languageLocale.replace("_", "-");
		}
		Locale loc =Locale.forLanguageTag(languageLocale);
		System.out.println(loc.getCountry());
	}
	public static void main(String[] arg){
		Map<String, String> props;
		props = new HashMap<String,String>();
		ExtractCountryFromLocale extCountryFrom = new ExtractCountryFromLocale(props);
		extCountryFrom.ExecutionResultTest();
	}*/

}
