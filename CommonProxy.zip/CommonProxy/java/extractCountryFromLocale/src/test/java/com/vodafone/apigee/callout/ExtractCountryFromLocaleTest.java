package com.vodafone.apigee.callout;

public class ExtractCountryFromLocaleTest {

}
