package com.vf.xss.callout;

import org.owasp.encoder.Encode;
import com.apigee.flow.execution.ExecutionContext;
import com.apigee.flow.execution.ExecutionResult;
import com.apigee.flow.execution.spi.Execution;
import com.apigee.flow.message.MessageContext;

public class XSSEncoder implements Execution {
	public ExecutionResult execute(MessageContext context,
			ExecutionContext executionContext) {
		// TODO Auto-generated method stub
		try {					
			String detailsError = (String) context.getVariable("detailError");
			String detailsMessage = (String) context.getVariable("detailMessage");
			if(detailsError != null){
				String detailsEncodedError = Encode.forJavaScript(detailsError);		        
		        context.setVariable("detailError", detailsEncodedError);
			}
			if(detailsMessage != null){
				String detailsEncodedError = Encode.forJavaScript(detailsMessage);		        
		        context.setVariable("detailMessage", detailsEncodedError);
			}
			String error = (String) context.getVariable("respError");
			if(error != null){
				String encodedError = Encode.forJavaScript(error);		        
		        context.setVariable("respError", encodedError);
			}
		  } catch (Exception ex) {
		}		
		return ExecutionResult.SUCCESS;
	}
}
