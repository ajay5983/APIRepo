package com.vodafone.apigee.callout;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.apigee.flow.execution.ExecutionContext;
import com.apigee.flow.execution.ExecutionResult;
import com.apigee.flow.execution.spi.Execution;
import com.apigee.flow.message.MessageContext;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Predicate;
import com.jayway.jsonpath.spi.json.JacksonJsonNodeJsonProvider;
import com.jayway.jsonpath.spi.json.JsonProvider;
import com.jayway.jsonpath.spi.mapper.JacksonMappingProvider;
import com.jayway.jsonpath.spi.mapper.MappingProvider;

public class PayloadMasking implements Execution{
	private final Map<String, String> parameters;
	
	public PayloadMasking(Map<String, String> props) {
		parameters = new HashMap<String, String>();
		Iterator iterator = props.keySet().iterator();
		while (iterator.hasNext()) {
			Object key = iterator.next();
			Object value = props.get(key);
			if ((key instanceof String) && (value instanceof String)) {
				parameters.put((String) key, (String) value);
			}
		}
	}
	@Override
	public ExecutionResult execute(MessageContext msgCtx, ExecutionContext extCtx) {
		String maskingEnabled;
        String originalJson = null;
        String maskedDoc = null;
        boolean isRequestFlow = false;
        String jsonRequestPath = null;
        String jsonResponsePath = null;
        String respMessage = (String)msgCtx.getVariable("response.content");
        Integer responseStatusCode = (Integer)msgCtx.getVariable("response.status.code");
        String errorState = (String)msgCtx.getVariable("error.state");
        
        if ((respMessage == null || respMessage.isEmpty()) && responseStatusCode == null && (errorState == null || errorState.isEmpty())) {
            isRequestFlow = true;
        }
            if (isRequestFlow) {
            	originalJson = (String)msgCtx.getVariable("request.content");
				if (originalJson == null || originalJson.isEmpty()) {
				return ExecutionResult.SUCCESS;
				}
                jsonRequestPath = (String)msgCtx.getVariable(parameters.get("jsonPathRequestToMask"));
                if (jsonRequestPath != null && !jsonRequestPath.isEmpty() && originalJson != null && !originalJson.isEmpty()) {
                    maskedDoc = this.maskGivenInfo(jsonRequestPath, originalJson);
                }
            } else {
            	originalJson = (String)msgCtx.getVariable("response.content");
				if (originalJson == null || originalJson.isEmpty()) {
				return ExecutionResult.SUCCESS;
				}
                jsonResponsePath = (String)msgCtx.getVariable(parameters.get("jsonPathResponseToMask"));
                if (jsonResponsePath != null && !jsonResponsePath.isEmpty() && originalJson != null && !originalJson.isEmpty()) {
                    maskedDoc = this.maskGivenInfo(jsonResponsePath, originalJson);
                }
            }
        msgCtx.setVariable("maskedPayload", (Object)maskedDoc);
        return ExecutionResult.SUCCESS;
	}
	
    public String maskGivenInfo(String maskFields, String originalJson) {
        String maskedPayload = originalJson;
        String[] maskedDoc = null;
        String[] arrstring = maskedDoc = maskFields.split(",");
        int n = arrstring.length;
        int n2 = 0;
        while (n2 < n) {
            String maskField = arrstring[n2];
            Configuration configuration = Configuration.builder().jsonProvider((JsonProvider)new JacksonJsonNodeJsonProvider()).mappingProvider((MappingProvider)new JacksonMappingProvider()).build();
            try {
                maskedPayload = JsonPath.using((Configuration)configuration).parse(maskedPayload).set(maskField, (Object)"**********", new Predicate[0]).json().toString();
            }catch (com.jayway.jsonpath.PathNotFoundException pathExp) {
 			    System.out.println("Exception caused due to PathNotFound Exception");
             }
			catch (com.jayway.jsonpath.InvalidJsonException invalidJsonExp) {
 			   System.out.println("Exception caused due to InvalidJson Exception");
             }
            catch (Exception genericExp) {
               System.out.println("Exception caused due to unhandled Exception");
               //genericExp.printStackTrace();
            }
            ++n2;
        }
        return maskedPayload;
    }

}
