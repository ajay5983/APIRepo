package com.vodafone.apigee.callout;

import java.util.HashMap;
import java.util.Map;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class AccessCountryFromLocaleTest {
	@Test
	public void executeTest1()
	{
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("languageLocale", "en_UK");
   	 	AccessCountryFromLocale accessCountryFromLocale = new AccessCountryFromLocale(parameters);
	    assertEquals("UK",accessCountryFromLocale.executeSimulation("en_UK"));
	}
	@Test
	public void executeTest2()
	{
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("languageLocale", "en-UK");
   	 	AccessCountryFromLocale accessCountryFromLocale = new AccessCountryFromLocale(parameters);
	    assertEquals("UK",accessCountryFromLocale.executeSimulation("en-UK"));
	}
	@Test
	public void executeTest3()
	{
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("languageLocale", null);
   	 	AccessCountryFromLocale accessCountryFromLocale = new AccessCountryFromLocale(parameters);
	    assertEquals("a42_generic_internal_config_error",accessCountryFromLocale.executeSimulation(null));
	}
	@Test
	public void executeTest4()
	{
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("languageLocale", "abc");
   	 	AccessCountryFromLocale accessCountryFromLocale = new AccessCountryFromLocale(parameters);
	    assertEquals("",accessCountryFromLocale.executeSimulation("abc"));
	}
}
