package com.vodafone.apigee.callout;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import com.apigee.flow.execution.ExecutionContext;
import com.apigee.flow.execution.ExecutionResult;
import com.apigee.flow.execution.spi.Execution;
import com.apigee.flow.message.MessageContext;
import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;

public class ValidationMSISDN implements Execution {
	private final Map<String, String> parameters;

	public ValidationMSISDN(Map<String, String> props) {
		parameters = new HashMap<String, String>();
		Iterator iterator = props.keySet().iterator();
		while (iterator.hasNext()) {
			Object key = iterator.next();
			Object value = props.get(key);
			if ((key instanceof String) && (value instanceof String)) {
				parameters.put((String) key, (String) value);
			}
		}
	}

	public ExecutionResult execute(MessageContext msgCtx, ExecutionContext extCtx) {
		String msisdn = msgCtx.getVariable(parameters.get("msisdn"));
		String errorJSON = null;
		PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
		Phonenumber.PhoneNumber phone = null;
		try {
			Boolean flag = false;
			if (msisdn != null && msisdn.length()>0) {

				if (msisdn.contains(",")) {

					String[] msisdnList = msisdn.split(",");
					if(msisdnList.length>0){
					for (int i = 0; i < msisdnList.length; i++) {
						if (!msisdnList[i].equalsIgnoreCase("null") && msisdnList[i].length()>0) {
							if (msisdnList[i].contains("tel:+")) {
								msisdnList[i] = msisdnList[i].replace("tel:", "");
							} else if (msisdnList[i].contains("tel%3A%2B")) {
								msisdnList[i] = msisdnList[i].replace("tel%3A%2B", "");
								msisdnList[i] = "+" + msisdnList[i];
							} else {

								msisdnList[i] = "+" + msisdnList[i];
							}
							if (msisdnList[i] != "+null") {
								phone = phoneUtil.parse(msisdnList[i], null);
								flag = phoneUtil.isValidNumber(phone);
								if (!flag)
									break;
							}
						} else {
							errorJSON = "a42_generic_missing_request_parameter";
							flag = false;
							break;
						}
					}
					}
					else{
						errorJSON = "a42_generic_missing_request_parameter";
					}
				} else {
					if (msisdn.contains("tel:+")) {
						msisdn = msisdn.replace("tel:", "");
					} else if (msisdn.contains("tel%3A%2B")) {
						msisdn = msisdn.replace("tel%3A%2B", "");
						msisdn = "+" + msisdn;
					} else {
						msisdn = "+" + msisdn;
					}
					if (msisdn != "+null") {
						phone = phoneUtil.parse(msisdn, null);
						flag = phoneUtil.isValidNumber(phone);
					}
				}
				if (flag) {
					msgCtx.setVariable("msisdnStatus", (Object) "valid");
					return ExecutionResult.SUCCESS;
				} else {
					if (errorJSON == null) {
						errorJSON = "a42_generic_invalid_request_parameter";
					}
					msgCtx.setVariable("msisdnStatus", (Object) "invalid");
					msgCtx.setVariable("errorJSON", (Object) errorJSON);
					msgCtx.setVariable("request_param", (Object) "MSISDN");
					return ExecutionResult.ABORT;
				}
			} else {
				msgCtx.setVariable("errorJSON", (Object) "a42_generic_missing_request_parameter");
				msgCtx.setVariable("request_param", (Object) "MSISDN");
				return ExecutionResult.ABORT;
			}
		} catch (NumberParseException e) {
			msgCtx.setVariable("errorJSON", (Object) "a42_generic_invalid_request_parameter");
			msgCtx.setVariable("request_param", (Object) "MSISDN");
			return ExecutionResult.ABORT;
		} catch (Exception e) {
			msgCtx.setVariable("errorJSON", (Object) "a42_generic_internal_config_error");
			return ExecutionResult.ABORT;
		}
	}

	public String executeSimulation(String msisdn) {
		String errorJSON = null;
		PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
		Phonenumber.PhoneNumber phone = null;
		try {
			Boolean flag = false;
			if (msisdn != null && msisdn.length()>0) {

				if (msisdn.contains(",")) {

					String[] msisdnList = msisdn.split(",");
					if(msisdnList.length>0){
					for (int i = 0; i < msisdnList.length; i++) {
						if (!msisdnList[i].equalsIgnoreCase("null") && msisdnList[i].length()>0) {
							if (msisdnList[i].contains("tel:+")) {
								msisdnList[i] = msisdnList[i].replace("tel:", "");
							} else if (msisdnList[i].contains("tel%3A%2B")) {
								msisdnList[i] = msisdnList[i].replace("tel%3A%2B", "");
								msisdnList[i] = "+" + msisdnList[i];
							} else {

								msisdnList[i] = "+" + msisdnList[i];
							}
							if (msisdnList[i] != "+null") {
								phone = phoneUtil.parse(msisdnList[i], null);
								flag = phoneUtil.isValidNumber(phone);
								if (!flag)
									break;
							}
						} else {
							errorJSON = "a42_generic_missing_request_parameter";
							flag = false;
							break;
						}
					}
					}
					else{
						errorJSON = "a42_generic_missing_request_parameter";
					}
				} else {
					if (msisdn.contains("tel:+")) {
						msisdn = msisdn.replace("tel:", "");
					} else if (msisdn.contains("tel%3A%2B")) {
						msisdn = msisdn.replace("tel%3A%2B", "");
						msisdn = "+" + msisdn;
					} else {
						msisdn = "+" + msisdn;
					}
					if (msisdn != "+null") {
						phone = phoneUtil.parse(msisdn, null);
						flag = phoneUtil.isValidNumber(phone);
					}
				}
				if (flag) {
					errorJSON = "valid";
					return errorJSON;
				} else {
					if (errorJSON == null) {
						errorJSON = "a42_generic_invalid_request_parameter";
					}
					return errorJSON;
				}
			} else {
				errorJSON = "a42_generic_missing_request_parameter";
				return errorJSON;
			}
		} catch (NumberParseException e) {
			errorJSON = "a42_generic_invalid_request_parameter";
			return errorJSON;
		} catch (Exception e) {
			errorJSON = "a42_generic_internal_config_error";
			return errorJSON;
		}
	}

	
	/* public static void main(String[] args) { Map<String, String> parameters =
	  new HashMap<String, String>(); parameters.put("msisdn",
	  "null,491730490563"); ValidationMSISDN validationMSISDN = new ValidationMSISDN(parameters);
	  System.out.println("1."+validationMSISDN.executeSimulation("null,tel:+491730490563"));
	  System.out.println("2."+validationMSISDN.executeSimulation("491730490563,491736780578"));
	  System.out.println("3."+validationMSISDN.executeSimulation("tel:+491730490563,tel:+491736780578"));
	  System.out.println("4."+validationMSISDN.executeSimulation("4917367805,tel:+491736780578"));
	  System.out.println("5."+validationMSISDN.executeSimulation("491730490563,null"));
	  System.out.println("6."+validationMSISDN.executeSimulation("null,null"));
	  /*System.out.println("7."+validationMSISDN.executeSimulation(""));
	  System.out.println("8."+validationMSISDN.executeSimulation(",null"));
	  System.out.println("9."+validationMSISDN.executeSimulation(","));
	  System.out.println("10."+validationMSISDN.executeSimulation(",,,"));
	  }*/
	 
}
