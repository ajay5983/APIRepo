package com.vodafone.apigee.callout;

import java.util.HashMap;
import java.util.Map;

public class PhoneUtil {

	public static void main(String[] args) {
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("msisdn", "491736780578");
   	 	ValidationMSISDN validationMSISDN = new ValidationMSISDN(parameters);
   	 	System.out.println(validationMSISDN.executeSimulation("491736780578"));
   	 	System.out.println(validationMSISDN.executeSimulation("tel:+491736780578"));
   	 	System.out.println(validationMSISDN.executeSimulation("4917367805"));
   	 	System.out.println(validationMSISDN.executeSimulation("tel:+4917367805"));
   	 	System.out.println(validationMSISDN.executeSimulation(null));
   	 	System.out.println(validationMSISDN.executeSimulation("abc"));
	}

}
