package com.vodafone.apigee.callout;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

public class ValidationMSISDNTest {
	@Test
	public void executeTest1()
	{
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("msisdn", "491736780578");
   	 	ValidationMSISDN validationMSISDN = new ValidationMSISDN(parameters);
	    assertEquals("valid",validationMSISDN.executeSimulation("491736780578"));
	}
	@Test
	public void executeTest2()
	{
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("msisdn", "tel:+491736780578");
   	 	ValidationMSISDN validationMSISDN = new ValidationMSISDN(parameters);
	    assertEquals("valid",validationMSISDN.executeSimulation("tel:+491736780578"));
	}
	@Test
	public void executeTest3()
	{
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("msisdn", "tel:+4917367805");
   	 	ValidationMSISDN validationMSISDN = new ValidationMSISDN(parameters);
	    assertEquals("a42_generic_invalid_request_parameter",validationMSISDN.executeSimulation("tel:+4917367805"));
	}
	@Test
	public void executeTest4()
	{
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("msisdn", "4917367805");
   	 	ValidationMSISDN validationMSISDN = new ValidationMSISDN(parameters);
	    assertEquals("a42_generic_invalid_request_parameter",validationMSISDN.executeSimulation("4917367805"));
	}
	@Test
	public void executeTest5()
	{
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("msisdn", "abcd");
   	 	ValidationMSISDN validationMSISDN = new ValidationMSISDN(parameters);
	    assertEquals("a42_generic_invalid_request_parameter",validationMSISDN.executeSimulation("abcd"));
	}
	@Test
	public void executeTest6()
	{
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("msisdn", null);
   	 	ValidationMSISDN validationMSISDN = new ValidationMSISDN(parameters);
	    assertEquals("a42_generic_missing_request_parameter",validationMSISDN.executeSimulation(null));
	}
	@Test
	public void executeTest7()
	{
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("msisdn", "491730490563,491736780578");
   	 	ValidationMSISDN validationMSISDN = new ValidationMSISDN(parameters);
	    assertEquals("valid",validationMSISDN.executeSimulation("491730490563,491736780578"));
	}
	@Test
	public void executeTest8()
	{
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("msisdn", "tel:+491730490563,tel:+491736780578");
   	 	ValidationMSISDN validationMSISDN = new ValidationMSISDN(parameters);
	    assertEquals("valid",validationMSISDN.executeSimulation("tel:+491730490563,tel:+491736780578"));
	}
	@Test
	public void executeTest9()
	{
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("msisdn", "4917367805,tel:+491736780578");
   	 	ValidationMSISDN validationMSISDN = new ValidationMSISDN(parameters);
	    assertEquals("a42_generic_invalid_request_parameter",validationMSISDN.executeSimulation("4917367805,tel:+491736780578"));
	}
	@Test
	public void executeTest10()
	{
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("msisdn", "491730490563,null");
   	 	ValidationMSISDN validationMSISDN = new ValidationMSISDN(parameters);
	    assertEquals("a42_generic_missing_request_parameter",validationMSISDN.executeSimulation("491730490563,null"));
	}
	@Test
	public void executeTest11()
	{
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("msisdn", "null,491730490563");
   	 	ValidationMSISDN validationMSISDN = new ValidationMSISDN(parameters);
	    assertEquals("a42_generic_missing_request_parameter",validationMSISDN.executeSimulation("null,491730490563"));
	}
	@Test
	public void executeTest12()
	{
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("msisdn", "null,null");
   	 	ValidationMSISDN validationMSISDN = new ValidationMSISDN(parameters);
	    assertEquals("a42_generic_missing_request_parameter",validationMSISDN.executeSimulation("null,null"));
	}
	@Test
	public void executeTest13()
	{
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("msisdn", "tel:+491730490563,tel%3A%2B491736780578");
   	 	ValidationMSISDN validationMSISDN = new ValidationMSISDN(parameters);
	    assertEquals("valid",validationMSISDN.executeSimulation("tel:+491730490563,tel%3A%2B491736780578"));
	}
	@Test
	public void executeTest14()
	{
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("msisdn", "tel%3A%2B491736780578,tel:+491730490563");
   	 	ValidationMSISDN validationMSISDN = new ValidationMSISDN(parameters);
	    assertEquals("valid",validationMSISDN.executeSimulation("tel%3A%2B491736780578,tel:+491730490563"));
	}
	@Test
	public void executeTest15()
	{
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("msisdn", "tel%3A%2B491736780578,tel%3A%2B491730490563");
   	 	ValidationMSISDN validationMSISDN = new ValidationMSISDN(parameters);
	    assertEquals("valid",validationMSISDN.executeSimulation("tel%3A%2B491736780578,tel:+491730490563"));
	}
	@Test
	public void executeTest16()
	{
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("msisdn", "");
   	 	ValidationMSISDN validationMSISDN = new ValidationMSISDN(parameters);
	    assertEquals("a42_generic_missing_request_parameter",validationMSISDN.executeSimulation(""));
	}
	@Test
	public void executeTest17()
	{
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("msisdn", ",");
   	 	ValidationMSISDN validationMSISDN = new ValidationMSISDN(parameters);
	    assertEquals("a42_generic_missing_request_parameter",validationMSISDN.executeSimulation(","));
	}
	@Test
	public void executeTest18()
	{
		Map<String,String> parameters = new HashMap<String,String>();
   	 	parameters.put("msisdn", ",");
   	 	ValidationMSISDN validationMSISDN = new ValidationMSISDN(parameters);
	    assertEquals("a42_generic_missing_request_parameter",validationMSISDN.executeSimulation(",null"));
	}
}
