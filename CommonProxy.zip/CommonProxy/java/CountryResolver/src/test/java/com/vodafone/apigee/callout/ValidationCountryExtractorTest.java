package com.vodafone.apigee.callout;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.mockito.Mockito;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
public class ValidationCountryExtractorTest {
	@Test
	public void executeTest()
	{
		Map<String,String> parameters = new HashMap<String,String>();
		 parameters.put("msisdn", "inputmsisdn");
		ValidationCountryExtractor validationCountryExtractor = new ValidationCountryExtractor(parameters);
	    assertEquals("DE",validationCountryExtractor.executeTesting("491736780578"));
	}
	@Test
	public void executeTest1()
	{
		Map<String,String> parameters = new HashMap<String,String>();
		 parameters.put("msisdn", "inputmsisdn");
		ValidationCountryExtractor validationCountryExtractor = new ValidationCountryExtractor(parameters);
	    assertEquals("a42_generic_invalid_request_parameter",validationCountryExtractor.executeTesting("491736654777677767780578"));
	}
	@Test
	public void executeTest2()
	{
		Map<String,String> parameters = new HashMap<String,String>();
		 parameters.put("msisdn", "inputmsisdn");
		ValidationCountryExtractor validationCountryExtractor = new ValidationCountryExtractor(parameters);
	    assertEquals("a42_generic_missing_request_parameter",validationCountryExtractor.executeTesting(null));
	}
	@Test
	public void executeTest3()
	{
		//PhoneValidatorUtil phnVl = Mockito.mock(PhoneValidatorUtil.class);
		Map<String,String> parameters = new HashMap<String,String>();
		 parameters.put("msisdn", "inputmsisdn");
		ValidationCountryExtractor validationCountryExtractor = new ValidationCountryExtractor(parameters);
	    // define return value for method getUniqueId()
		//when(phnVl.getTlcFromMsisdn("4979890422151")).thenReturn("49");
		 //StockService stockServiceMock = mock(StockService.class);
	    
	    // use mock in test....
	    assertEquals("a42_generic_missing_request_parameter",validationCountryExtractor.executeTesting(null));
	}
}