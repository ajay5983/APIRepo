package com.vodafone.apigee.callout;

import java.util.HashMap;
import java.util.Map;

import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;

public class PhoneValidatorUtil {
    public static boolean isPhoneValid(String number) {
        boolean bool;
        if (number == null) {
            return false;
        }
        if (!PhoneValidatorUtil.checkChars(number)) {
            return false;
        }
        bool = false;
        PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
        Phonenumber.PhoneNumber phone = null;
        try {
            try {
                phone = phoneUtil.parse(number, "");
                bool = true;
            }
            catch (NumberParseException e) {
                bool = false;
            }
        }
        catch (Throwable v0) {}
        return bool;
    }

    private static boolean checkChars(String number) {
        String msisdn = number;
        if (!msisdn.startsWith("+")) {
            return false;
        }
        msisdn = msisdn.substring(1, msisdn.length());
        try {
            Long.parseLong(msisdn);
        }
        catch (Exception e) {
            return false;
        }
        return true;
    }
    public static String getTlcFromMsisdn(String msisdn) {
        if (!(msisdn = msisdn.replace("tel:", "")).startsWith("+")) {
            msisdn = "+" + msisdn;
        }
        PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
        Phonenumber.PhoneNumber phone = null;
        String cc = null;
        try {
            phone = phoneUtil.parse(msisdn, "");
            cc = String.valueOf(phone.getCountryCode());
        }
        catch (NumberParseException e) {
            cc = null;
        }
        return cc;
    }

    public static String getRegionCodeForCountry(String cc) {
        PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
        return phoneUtil.getRegionCodeForCountryCode(Integer.parseInt(cc));
    }

    public static void main(String[] args) {
    	Map<String,String> parameters = new HashMap<String,String>();
    	 parameters.put("msisdn", "4479890422151");
    	 ValidationCountryExtractor validationCountryExtractor = new ValidationCountryExtractor(parameters);
    	 System.out.println("valid msisdn: " + validationCountryExtractor.executeTesting("491736780578"));
    	 System.out.println("if msisdn is null: " + validationCountryExtractor.executeTesting(null));
    	 System.out.println("invalid msisdn:" + validationCountryExtractor.executeTesting("491454654546566780578"));
    }
}


