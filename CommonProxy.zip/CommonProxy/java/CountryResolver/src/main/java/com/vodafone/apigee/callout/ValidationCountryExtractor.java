package com.vodafone.apigee.callout;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import com.apigee.flow.execution.ExecutionContext;
import com.apigee.flow.execution.ExecutionResult;
import com.apigee.flow.execution.spi.Execution;
import com.apigee.flow.message.MessageContext;
import com.google.i18n.phonenumbers.NumberParseException;

public class ValidationCountryExtractor implements Execution {
	
	private final Map<String,String> parameters; // read-only
	 public ValidationCountryExtractor(Map<String, String> props){
		 parameters = new HashMap<String,String>();
	       Iterator iterator = props.keySet().iterator();
	       while(iterator.hasNext()){
	           Object key = iterator.next();
	           Object value = props.get(key);
	           if ((key instanceof String) && (value instanceof String)) {           
	               parameters.put((String) key, (String) value);
	           }
	       }
	 }
	public ExecutionResult execute(MessageContext messageContext, ExecutionContext executionContext) {
		try{
			String msisdn = messageContext.getVariable(parameters.get("msisdn"));
			if(msisdn==null || msisdn.length()==0){
				messageContext.setVariable("errorJSON", (Object)"a42_generic_missing_request_parameter");
				messageContext.setVariable("request_param", (Object)"MSISDN");
				return ExecutionResult.ABORT;
			}
			if (!PhoneValidatorUtil.isPhoneValid("+" + msisdn) || msisdn.length() < 9 || msisdn.length() > 15) {
				messageContext.setVariable("errorJSON", (Object)"a42_generic_invalid_request_parameter");
				messageContext.setVariable("request_param", (Object)"MSISDN");
	            return ExecutionResult.ABORT;
	        }
			String countryCode = PhoneValidatorUtil.getTlcFromMsisdn((String)msisdn);
			if(countryCode==null){
				messageContext.setVariable("errorJSON", (Object)"a42_generic_invalid_request_parameter");
				messageContext.setVariable("request_param", (Object)"MSISDN");
				return ExecutionResult.ABORT;
			}
			else{
				messageContext.setVariable("country", (Object)countryCode);
				String countryCodeISO=PhoneValidatorUtil.getRegionCodeForCountry(countryCode);
				if(countryCodeISO!=null){
					messageContext.setVariable("countryISO", countryCodeISO);
				}
				else{
					messageContext.setVariable("errorJSON", (Object)"a42_generic_invalid_request_parameter");
					messageContext.setVariable("request_param", (Object)"MSISDN");
					return ExecutionResult.ABORT;
				}
				return ExecutionResult.SUCCESS;
			}
			}
			catch(Exception e){
				return ExecutionResult.ABORT;
			}
	}
	public String executeTesting(String msisdn){
		String country="";
		try{
			if(msisdn==null){
				country="a42_generic_missing_request_parameter";
				return country;
			}
			if (!PhoneValidatorUtil.isPhoneValid("+" + msisdn) || msisdn.length() < 9 || msisdn.length() > 15) {
				country="a42_generic_invalid_request_parameter";
	            return country;
	        }
			String countryCode = PhoneValidatorUtil.getTlcFromMsisdn((String)msisdn);
			String countryCodeISO=PhoneValidatorUtil.getRegionCodeForCountry(countryCode);
			if(countryCode==null){
				country="a42_generic_invalid_request_parameter";
				return countryCode;
			}
			else{
				country=countryCodeISO;
				return country;
			}
			}
			catch(Exception e){
				country="a42_generic_invalid_request_parameter";
				return country;
			}
	}

}
