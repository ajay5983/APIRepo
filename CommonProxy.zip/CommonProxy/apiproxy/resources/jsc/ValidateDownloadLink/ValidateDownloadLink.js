validateDownloadLink = function validateDownloadLink() { // eslint-disable-line no-undef
	var downloadLinks = context.getVariable("download_links");
	var expiryTime = context.getVariable("expiry_time");
	var fileType = context.getVariable("file_type");
	var msisdn = context.getVariable("accesstoken.msisdn");
	var sub = context.getVariable("accesstoken.sub");
	var acr = context.getVariable("accesstoken.acr");
	var xJwt = context.getVariable("response.header.X-JWT");
	var token = context.getVariable("jws_token");
	var jsonArray = [];
	var cacheExpiryTime = [];
	var downloadCacheExpiry = context.getVariable("download_cache_expiry");
	if (xJwt) {
		token = xJwt;
	}
	var flag = false;

	if (downloadLinks){

		downloadLinks = downloadLinks.split(",");
		expiryTime = expiryTime.split(",");
		fileType = fileType.split(",");
		for (var i = 0; downloadLinks.length > i;++i){
			if (!flag) {
				var modifiedJson = {};
				var downloadLink = downloadLinks[i];
				if (downloadLink !== "NoURL") {
					var result = downloadLink.match(/^(https):\/\/(\w+:{0,1}\w*@)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&=]*)/);// eslint-disable-line no-useless-escape

					if (result) {

						modifiedJson.url = downloadLink;
						modifiedJson.backendAuth = {};
						modifiedJson.backendAuth.fieldType = "header";
						modifiedJson.backendAuth.fieldName = "Authorization";
						modifiedJson.backendAuth.value = "Bearer " + token;
						modifiedJson.sslInfo = {};
						modifiedJson.sslInfo.sslEnabled = context.getVariable("ROUTING.target_ssl_enabled");
						modifiedJson.sslInfo.clientAuthEnabled = context.getVariable("ROUTING.target_ssl.client.auth.enabled");
						modifiedJson.sslInfo.keyStore = context.getVariable("ROUTING.target.ssl.key.store");
						modifiedJson.sslInfo.keyAlias = context.getVariable("ROUTING.target.ssl.key.alias");
						modifiedJson.sslInfo.trustStore = context.getVariable("ROUTING.target.ssl.trust.store");
						modifiedJson.sslInfo.ciphers = context.getVariable("ROUTING.ssl.ciphers");
						modifiedJson.sslInfo.protocols = context.getVariable("ROUTING.ssl.protocols");
						modifiedJson.sslInfo.ignoreValidationErrors = context.getVariable("ROUTING.ssl.ignore.validation.errors");
						if (fileType[i] && fileType[i] !== "NoFileType"){
							modifiedJson.fileType = fileType[i];
						}
						if (msisdn){
							modifiedJson.msisdn = msisdn;
						}
						if (sub){
							modifiedJson.sub = sub;
						}
						if (acr){
							modifiedJson.acr = acr;
						}
						if (expiryTime[i]){
							var date = new Date();
							var currentEpochTimeInSec = Math.round(date.getTime() / 1000);
							currentEpochTimeInSec = Math.floor(currentEpochTimeInSec);
							if (currentEpochTimeInSec > expiryTime[i]){ // eslint-disable-line max-depth
								flag = true;
							}
							var cacheExpiry = expiryTime[i] - currentEpochTimeInSec;
							cacheExpiry = Math.floor(cacheExpiry);
							cacheExpiryTime.push(cacheExpiry);
							modifiedJson.expiryTime = expiryTime[i].toString();
						} else {
							cacheExpiryTime.push(downloadCacheExpiry);
						}
						jsonArray.push(JSON.stringify(modifiedJson));
					} else {
						flag = true;
					}
				} else {
					cacheExpiryTime.push("");
					jsonArray.push(JSON.stringify(modifiedJson));
				}
			}
			if (flag) {
				context.setVariable("errorJSON", "a42_generic_internal_server_error");
				throw "internalServerError";
			}
		}
	}
	context.setVariable("jsonArray", jsonArray);
	context.setVariable("cacheExpiryTime", cacheExpiryTime);
};
