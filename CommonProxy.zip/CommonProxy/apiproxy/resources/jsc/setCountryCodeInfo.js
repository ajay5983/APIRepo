/* used to set countryCode on the basis of input msisdn*/
var result =false;
var errorJSON = "";
try{
var country_code_id_info = context.getVariable('country_code_id_info');
var country_code_id_infos = context.getVariable('country_code_id_infos');
if(country_code_id_infos!=null){
	country_code_id_infos = JSON.parse(country_code_id_infos);
	var country = context.getVariable('countryISO');
	if(country_code_id_infos[country]){
		context.setVariable('country_'+country+'_info_name',country_code_id_infos[country]['NAME']);
	    context.setVariable('country_'+country+'_info_group',country_code_id_infos[country]['GROUP']);
	    context.setVariable('country_'+country+'_info_currency',country_code_id_infos[country]['CURRENCY']);
	    context.setVariable('country_'+country+'_info_currency',country_code_id_infos[country]['ALPHA3']);
	    context.setVariable('country_'+country+'_info_currency',country_code_id_infos[country]['ALPHA2']);
	}
	else{
		errorJSON = 'a42_generic_country_not_supported';
		result = true;
	}
    }
	else if(country_code_id_info!=null){
	country_code_id_info = JSON.parse(country_code_id_info);
	var country = context.getVariable('country');
	if(country_code_id_info[country]){
		context.setVariable('country_'+country+'_info_name',country_code_id_info[country]['NAME']);
	    context.setVariable('country_'+country+'_info_group',country_code_id_info[country]['GROUP']);
	    context.setVariable('country_'+country+'_info_currency',country_code_id_info[country]['CURRENCY']);
	    context.setVariable('country_'+country+'_info_currency',country_code_id_info[country]['ALPHA3']);
	    context.setVariable('country_'+country+'_info_currency',country_code_id_info[country]['ALPHA2']);
	}
	else{
		errorJSON = 'a42_generic_country_not_supported';
		result = true;
	}
    }
}catch(err){
	errorJSON = 'a42_generic_internal_config_error';
	result = true;
}
if(result){
	context.setVariable("errorJSON",errorJSON);
	throw errorJSON;
}