validationContentType = function validationContentType(){ // eslint-disable-line no-undef
	try {
		var verb = context.getVariable("request.verb");
		var errorJSON, allowedContentTypeVal, contentTypeValKvm, contentType;
		// Content-Type Validation
		if (verb === "PATCH") {
			contentTypeValKvm = context.getVariable("validation_content_type_header_patch");
			if (contentTypeValKvm) {
				allowedContentTypeVal = contentTypeValKvm.split(",");
				contentType = context.getVariable("request.header.Content-Type");
				if (contentType) {
					contentType = contentType.toLowerCase();
					if (allowedContentTypeVal.indexOf(contentType) === -1) {
						errorJSON = "a42_generic_invalid_content_type_header";
						context.setVariable("errorJSON", errorJSON);
						throw "invalidHeaderException";
					}
				} else {
					context.setVariable("errorJSON", "a42_generic_invalid_content_type_header");
					throw "invalidHeaderException";
				}
			} else {
				errorJSON = "a42_generic_internal_config_error";
				context.setVariable("errorJSON", errorJSON);
				throw "invalidHeaderException";
			}
		} else if (verb === "PUT" || verb === "POST") {
			contentTypeValKvm = context.getVariable("validation_content_type_header");
			if (contentTypeValKvm) {
				allowedContentTypeVal = contentTypeValKvm.split(",");
				contentType = context.getVariable("request.header.Content-Type");
				if (contentType) {
					contentType = contentType.toLowerCase();
					if (allowedContentTypeVal.indexOf(contentType) === -1) {
						errorJSON = "a42_generic_invalid_content_type_header";
						context.setVariable("errorJSON", errorJSON);
						throw "invalidHeaderException";
					}
				} else {
					context.setVariable("errorJSON", "a42_generic_invalid_content_type_header");
					throw "invalidHeaderException";
				}
			} else {
				errorJSON = "a42_generic_internal_config_error";
				context.setVariable("errorJSON", errorJSON);
				throw "invalidHeaderException";
			}
		}
	} catch (e) {
		throw "InvalidContentTypeException";
	}
};