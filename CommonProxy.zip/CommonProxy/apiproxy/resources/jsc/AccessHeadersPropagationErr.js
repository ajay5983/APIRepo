try
{
	var status_code = context.getVariable('message.status.code');
	var api_name = context.getVariable('apiproxy.name');
	var Org_UUID = context.getVariable('app.vf_app_org_uuid') || '';

	var VF_INT_TRACE_ID = context.getVariable('VF_INT_TRACE_ID_req');
	var vf_trace_transaction_id = context.getVariable('vf_trace_transaction_id_req') || context.getVariable('vf.trace.transaction.id') || context.getVariable('VF_INT_TRACE_ID_req');
	
	var VF_INT_TRACK_ID = context.getVariable('VF_INT_TRACK_ID_req');
	if(VF_INT_TRACK_ID)
	{
		VF_INT_TRACK_ID = VF_INT_TRACK_ID + '.' + api_name + '-apix';
	}
	else
	{
		VF_INT_TRACK_ID = api_name + '-apix';
	}
	
	var VF_INT_CALLER_ID;
	if(context.getVariable('VF_INT_CALLER_ID_req'))
	{
		VF_INT_CALLER_ID = context.getVariable('VF_INT_CALLER_ID_req');
	}
	else if(Org_UUID)
	{
		VF_INT_CALLER_ID = Org_UUID;
	}
	else
	{
		VF_INT_CALLER_ID = 'unknown';
	}
	
	var VF_EXT_TRACE_ID = context.getVariable('VF_EXT_TRACE_ID_req');
	var VF_EXT_REFERENCE_ID = context.getVariable('VF_EXT_REFERENCE_ID_req');
	var VF_EXT_BP_ID = context.getVariable('VF_EXT_BP_ID_req');
	var X_Frame_Options = context.getVariable('X_Frame_Options');
	var X_Content_Type_Options = context.getVariable('X_Content_Type_Options');
	var X_XSS_Protection = context.getVariable('X_XSS_Protection');
	var VF_GIG_TRANSACTION_ID = context.getVariable("VF_GIG_TRANSACTION_ID_req");
	
	if(VF_INT_TRACE_ID) context.setVariable('message.header.VF_INT_TRACE_ID',VF_INT_TRACE_ID);
	if(vf_trace_transaction_id) context.setVariable('message.header.vf-trace-transaction-id',vf_trace_transaction_id);
	if(VF_INT_TRACK_ID) context.setVariable('message.header.VF_INT_TRACK_ID',VF_INT_TRACK_ID);
	if(VF_INT_CALLER_ID) context.setVariable('message.header.VF_INT_CALLER_ID',VF_INT_CALLER_ID);
	if(VF_EXT_TRACE_ID) context.setVariable('message.header.VF_EXT_TRACE_ID',VF_EXT_TRACE_ID);
	if(VF_EXT_REFERENCE_ID) context.setVariable('message.header.VF_EXT_REFERENCE_ID',VF_EXT_REFERENCE_ID);
	if(VF_EXT_BP_ID) context.setVariable('message.header.VF_EXT_BP_ID',VF_EXT_BP_ID);
	if(X_Frame_Options) context.setVariable('message.header.X-Frame-Options',X_Frame_Options);
	if(X_Content_Type_Options) context.setVariable('message.header.X-Content-Type-Options',X_Content_Type_Options);
	if(X_XSS_Protection) context.setVariable('message.header.X-XSS-Protection',X_XSS_Protection);
	if(VF_GIG_TRANSACTION_ID) context.setVariable('message.header.VF_GIG_TRANSACTION_ID',VF_GIG_TRANSACTION_ID);
	
	if((status_code >= 200) && (status_code < 400))
	{
		context.setVariable('message.header.VF_INT_STATUS_FLOW','ok');
	}
	else
	{
		context.setVariable('message.header.VF_INT_STATUS_FLOW','failure');
	}
}
catch(err)
{
	context.setVariable('errorJSON','a42_generic_internal_server_error');
	throw err;
}
