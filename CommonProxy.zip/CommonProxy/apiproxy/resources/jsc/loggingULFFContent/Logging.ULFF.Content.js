generateLogPayload = function generateLogPayload() {
	try {
		var transactionID = context.getVariable('vf.trace.transaction.id') ;
		var vfExtTraceID = context.getVariable('vfExtTraceID') || '';
		var vfExtReferenceId = context.getVariable('vfExtReferenceId') || '';
		var vfExtBpId = context.getVariable('vfExtBpId') || '';
		var accessPayloadSize = context.getVariable('access_payload_size');
		var ulffMaxContentSize = context.getVariable('logging_ulff_max_size');
		var loggingPayloadEnabled = context.getVariable('logging_payload_enabled') || true;
		var maskingBodyEnabled = context.getVariable('masking_body_enabled');
		var countryCode = context.getVariable('countryISO') || context.getVariable('request.header.vf-country-code') || '';
		var oauthTokenDetails =  context.getVariable("oauthTokenDetails");
		var scheme = context.getVariable("target.scheme");
		var host = context.getVariable("target.host");
		var port = context.getVariable("target.port");
		var uri = context.getVariable("request.uri");
		var inboundRequestUri = context.getVariable("proxy.url");
		var errorJSON = context.getVariable("errorJSON");
		var headersToMask =  context.getVariable('headersToMask');
		var payloadMSISDN = context.getVariable('inputMsisdn') || '';
		var err = context.getVariable("err");
		var desc = context.getVariable("description");
		var subscriberId = context.getVariable("vodafoneId") || '';
		var internalTransactionID = context.getVariable('vf.gig.transaction.id') || '';
		var layerTransactionID = context.getVariable('layer.transaction.id') || '';

		var HeaderList = context.getVariable('message.headers.names');
		var headers = '';
		var formParam = context.getVariable("message.formparams.names");
		var formParamToMask = context.getVariable("formParamToMask");

		var queryParamToMask = context.getVariable('queryParamToMask');
		var isMaskingEnabled = context.getVariable("masking_qparam_enabled");

		var date = new Date();
		var dateForLog = date.toISOString();

		if (isMaskingEnabled == 'true' && (queryParamToMask!== null))
		{
			inboundRequestUri  = maskQueryParam(queryParamToMask, inboundRequestUri);
			masked_request_uri = maskQueryParam(queryParamToMask, context.getVariable("request.uri"));
		}

		if(payloadMSISDN)
		{
			if (isNaN(payloadMSISDN) && payloadMSISDN.search(/tel:+/i) != -1) {
			payloadMSISDN = payloadMSISDN.toLowerCase();
			payloadMSISDN = payloadMSISDN.replace('tel:+', '');
			}
		}

		var payload = '';
		var oauthMsisdn =context.getVariable('accesstoken.msisdn') || '';
		var oauthClientId = context.getVariable('client_id') || '';
		var reasonPhrase = '';
		var statusCode = '';
		var errorDescription = '';
		var errorCode = '';

		if(oauthMsisdn)
		{
			if (isNaN(oauthMsisdn) && oauthMsisdn.search(/tel:+/i) != -1) {
			oauthMsisdn = oauthMsisdn.toLowerCase();
			oauthMsisdn = oauthMsisdn.replace('tel:+', '');
			}
		}

		var flow = context.flow;
		if(context.getVariable("ContextFlowFlag")=="true")
		{
			flow = "ERROR";
		}
		var  loggingUlffContent = {
				"transaction-id":transactionID,
				"external-trace-id": vfExtTraceID,
				"external-reference-id": vfExtReferenceId,
				"usecase-id": vfExtBpId,
				"country-code": countryCode,
				"internal-transaction-id": internalTransactionID,
				"layer-transaction-id": layerTransactionID
				};

		if(errorJSON){
			errorJSON = JSON.parse(context.getVariable(errorJSON));
			reasonPhrase = errorJSON.reasonPhrase;
			statusCode = errorJSON.statusCode;
			errorDescription = errorJSON.errorDescription;
			errorCode=errorJSON.errorCode;
		}

		var responseStatusCode = context.getVariable("message.status.code");
		var responseStatus = '';
		if((responseStatusCode == 502) || (responseStatusCode == 503))
		{
			responseStatus = 'timeout';
		}
		else if((responseStatusCode >= 200) && (responseStatusCode < 400))
		{
			responseStatus = 'ok';
		}
		else if((responseStatusCode >= 400) && (responseStatusCode < 500))
		{
			responseStatus = 'error';
		}
		else if(responseStatusCode >= 500)
		{
			responseStatus = 'failure';
		}

		var VF_INT_STATUS_FLOW;
		var status_code = context.getVariable('message.status.code');
		if(context.getVariable('VF_INT_STATUS_FLOW_resp'))
		{
			VF_INT_STATUS_FLOW = context.getVariable('VF_INT_STATUS_FLOW_resp');
		}
		else if((status_code >= 200) && (status_code < 400))
		{
			VF_INT_STATUS_FLOW = 'ok';
		}
		else
		{
			VF_INT_STATUS_FLOW = 'failure';
		}
		
		if(formParam !== null)
		{
			var fparam = {};
			var formparamstr = formParam.toString();
			formparamstr = formparamstr.replace('[',''); formparamstr = formparamstr.replace(']',''); formparamstr = formparamstr.replace(' ', '');
			
			var formparamArray = formparamstr.split(',');
			for(var x=0; x<formparamArray.length; x++)
			{
				var ParamValue = context.getVariable('request.formparam.'+formparamArray[x]+'.values')+'';
				ParamValue = ParamValue.substr(1, ParamValue.length - 2);
				ParamValue = ParamValue.replace(/[\\]/g,'\\\\').replace(/["]/g, '\\"');
				fparam[formparamArray[x]] = ParamValue; 
			}
		}

		if(accessPayloadSize && loggingPayloadEnabled){
			if(maskingBodyEnabled){
				payload = context.getVariable('maskedPayload');
			}
			
			if (maskingBodyEnabled == 'true' && (formParamToMask!== null) && (formParam!== null)){
				var formparams  = maskFormParam(formParamToMask, fparam);
				formparams = JSON.stringify(formparams);
				formparams = formparams.replace("{","");
				formparams = formparams.replace("}","");
				formparams = formparams.replace(/:/g,"=");
				formparams = formparams.replace(/,/g,"&");
				formparams = formparams.replace(/["]/g,"");
				
			}
			if(accessPayloadSize<ulffMaxContentSize){
			switch (flow) {
			case "PROXY_REQ_FLOW":
				loggingUlffContent["payload"]= formparams || payload || context.getVariable('message.content');
				loggingUlffContent["logpoint"]="request-in";
				loggingUlffContent["status"]='';
				loggingUlffContent["status-flow"]='';
				loggingUlffContent["error-code"]='';
				loggingUlffContent["subscriber-id"]=subscriberId;
				loggingUlffContent["error"]='';
				loggingUlffContent["error-msg"]='';
				loggingUlffContent["layer"]="apix";
				loggingUlffContent["content-type"]=context.getVariable('request.header.Content-Type');
				loggingUlffContent["timestamp-in"]=dateForLog;
				loggingUlffContent["timestamp-out"]='';
				loggingUlffContent["inbound-request-uri"]=context.getVariable('request.path');
				loggingUlffContent["caller-id"]=context.getVariable('VF_INT_CALLER_ID_req_Orig') || context.getVariable('app.vf_app_org_uuid') || 'unknown';
				loggingUlffContent["outbound-url"]='';
				
				var VF_INT_TRACK_ID = context.getVariable('VF_INT_TRACK_ID_req_Orig') || '';
				if(VF_INT_TRACK_ID)
				{
					loggingUlffContent["correlation-tracking"]=VF_INT_TRACK_ID + '.' + context.getVariable('apiproxy.name') + '-apix';
				}
				else
				{
					loggingUlffContent["correlation-tracking"]=context.getVariable('apiproxy.name') + '-apix';
				}
				break;
			case "PROXY_RESP_FLOW":
				loggingUlffContent["payload"]=formparams || payload || context.getVariable('message.content');
				loggingUlffContent["logpoint"]="response-out";
				loggingUlffContent["status"]=responseStatus;
				loggingUlffContent["status-flow"]=VF_INT_STATUS_FLOW||'';
				loggingUlffContent["status-code"]=statusCode || context.getVariable("message.status.code");
				loggingUlffContent["error-code"]='';
				loggingUlffContent["subscriber-id"]=subscriberId;
				loggingUlffContent["error"]='';
				loggingUlffContent["error-msg"]='';		
				loggingUlffContent["layer"]="apix";
				loggingUlffContent["content-type"]=context.getVariable('request.header.Content-Type');
				loggingUlffContent["timestamp-in"]='';
				loggingUlffContent["timestamp-out"]=dateForLog;
				loggingUlffContent["inbound-request-uri"]='';
				loggingUlffContent["caller-id"]=context.getVariable('VF_INT_CALLER_ID_resp') || context.getVariable('VF_INT_CALLER_ID_req') || context.getVariable('app.vf_app_org_uuid') || 'unknown';
				loggingUlffContent["outbound-url"]='';
				
				var VF_INT_TRACK_ID = context.getVariable('VF_INT_TRACK_ID_resp')||context.getVariable('VF_INT_TRACK_ID_req');
				if(VF_INT_TRACK_ID)
				{
					loggingUlffContent["correlation-tracking"]=VF_INT_TRACK_ID + '.' + context.getVariable('apiproxy.name') + '-apix';
				}		
				break;
			case "TARGET_REQ_FLOW":
				loggingUlffContent["payload"]=formparams || payload || context.getVariable('message.content');
				loggingUlffContent["logpoint"]="request-out";
				loggingUlffContent["status"]='';
				loggingUlffContent["status-flow"]='';
				loggingUlffContent["error-code"]='';
				loggingUlffContent["subscriber-id"]=subscriberId;
				loggingUlffContent["error"]='';
				loggingUlffContent["error-msg"]='';
				loggingUlffContent["layer"]="apix";
				loggingUlffContent["content-type"]=context.getVariable('request.header.Content-Type');
				loggingUlffContent["timestamp-in"]='';
				loggingUlffContent["timestamp-out"]=dateForLog;
				loggingUlffContent["inbound-request-uri"]='';
				loggingUlffContent["caller-id"]=context.getVariable('VF_INT_CALLER_ID_req_Orig') || context.getVariable('app.vf_app_org_uuid') || 'unknown';
				loggingUlffContent["outbound-url"]=context.getVariable('outboundTargetUrl') || context.getVariable('target.url');
				
				var VF_INT_TRACK_ID = context.getVariable('VF_INT_TRACK_ID_req_Orig') || '';
				if(VF_INT_TRACK_ID)
				{
					loggingUlffContent["correlation-tracking"]=VF_INT_TRACK_ID + '.' + context.getVariable('apiproxy.name') + '-apix';
				}
				else
				{
					loggingUlffContent["correlation-tracking"]=context.getVariable('apiproxy.name') + '-apix';
				}		
				break;
			case "TARGET_RESP_FLOW":
				loggingUlffContent["payload"]=formparams || payload || context.getVariable('message.content');
				loggingUlffContent["logpoint"]="response-in";
				loggingUlffContent["status"]=responseStatus;
				loggingUlffContent["status-flow"]=VF_INT_STATUS_FLOW||'';
				loggingUlffContent["status-code"]=statusCode || context.getVariable("message.status.code");
				loggingUlffContent["error-code"]='';
				loggingUlffContent["subscriber-id"]=subscriberId;
				loggingUlffContent["error"]='';
				loggingUlffContent["error-msg"]='';		
				loggingUlffContent["layer"]="apix";
				loggingUlffContent["content-type"]=context.getVariable('request.header.Content-Type');
				loggingUlffContent["timestamp-in"]=dateForLog;
				loggingUlffContent["timestamp-out"]='';
				loggingUlffContent["inbound-request-uri"]='';
				loggingUlffContent["caller-id"]=context.getVariable('VF_INT_CALLER_ID_resp') || context.getVariable('VF_INT_CALLER_ID_req') || context.getVariable('app.vf_app_org_uuid') || 'unknown';
				loggingUlffContent["outbound-url"]='';		
				
				var VF_INT_TRACK_ID = context.getVariable('VF_INT_TRACK_ID_resp')||context.getVariable('VF_INT_TRACK_ID_req');
				if(VF_INT_TRACK_ID)
				{
					loggingUlffContent["correlation-tracking"]=VF_INT_TRACK_ID + '.' + context.getVariable('apiproxy.name') + '-apix';
				}
				break;
			case "ERROR":
				var logPoint = context.getVariable("logPoint");
				if(logPoint == "response-in")
				{
					loggingUlffContent["payload"]=formparams || payload || context.getVariable('message.content');
					loggingUlffContent["logpoint"]="response-in";
					loggingUlffContent["status"]=responseStatus;
					loggingUlffContent["status-flow"]=VF_INT_STATUS_FLOW||'';
					loggingUlffContent["status-code"]=statusCode || context.getVariable("message.status.code");
					loggingUlffContent["error-code"]=statusCode || context.getVariable("message.status.code");
					loggingUlffContent["subscriber-id"]=subscriberId;
					loggingUlffContent["error"]=errorCode || err || '';
					loggingUlffContent["error-msg"]=errorDescription || desc || '';	
					loggingUlffContent["layer"]="apix";
					loggingUlffContent["content-type"]=context.getVariable('request.header.Content-Type');
					loggingUlffContent["timestamp-in"]=dateForLog;
					loggingUlffContent["timestamp-out"]='';
					loggingUlffContent["inbound-request-uri"]='';
					loggingUlffContent["caller-id"]=context.getVariable('VF_INT_CALLER_ID_resp') || context.getVariable('VF_INT_CALLER_ID_req') || context.getVariable('app.vf_app_org_uuid') || 'unknown';
					loggingUlffContent["outbound-url"]='';		
					
					var VF_INT_TRACK_ID = context.getVariable('VF_INT_TRACK_ID_resp')||context.getVariable('VF_INT_TRACK_ID_req');
					if(VF_INT_TRACK_ID)
					{
						loggingUlffContent["correlation-tracking"]=VF_INT_TRACK_ID + '.' + context.getVariable('apiproxy.name') + '-apix';
					}
					break;
				}
				else
				{
					loggingUlffContent["payload"]=formparams || payload || context.getVariable('message.content');
					loggingUlffContent["logpoint"]="response-out";
					loggingUlffContent["status"]=responseStatus;
					loggingUlffContent["status-flow"]=VF_INT_STATUS_FLOW||'';
					loggingUlffContent["status-code"]=statusCode || context.getVariable("message.status.code");
					loggingUlffContent["error-code"]=statusCode || context.getVariable("message.status.code");
					loggingUlffContent["subscriber-id"]=subscriberId;
					loggingUlffContent["error"]=errorCode || err || '';
					loggingUlffContent["error-msg"]=errorDescription || desc || '';
					loggingUlffContent["layer"]="apix";
					loggingUlffContent["content-type"]=context.getVariable('request.header.Content-Type');
					loggingUlffContent["timestamp-in"]='';
					loggingUlffContent["timestamp-out"]=dateForLog;
					loggingUlffContent["inbound-request-uri"]='';
					loggingUlffContent["caller-id"]=context.getVariable('VF_INT_CALLER_ID_resp') || context.getVariable('VF_INT_CALLER_ID_req') || context.getVariable('app.vf_app_org_uuid') || 'unknown';
					loggingUlffContent["outbound-url"]='';
					
					var VF_INT_TRACK_ID = context.getVariable('VF_INT_TRACK_ID_resp')||context.getVariable('VF_INT_TRACK_ID_req');
					if(VF_INT_TRACK_ID)
					{
						loggingUlffContent["correlation-tracking"]=VF_INT_TRACK_ID + '.' + context.getVariable('apiproxy.name') + '-apix';
					}
					else
					{
						loggingUlffContent["correlation-tracking"]=context.getVariable('apiproxy.name') + '-apix';
					}
					break;
				}
			}
			}
			
		}
		else if(loggingPayloadEnabled){
			if(maskingBodyEnabled){
				payload = context.getVariable('maskedPayload');
			}
			if (maskingBodyEnabled == 'true' && (formParamToMask!== null) && (formParam!== null)){
				var formparams  = maskFormParam(formParamToMask, fparam);
				formparams = JSON.stringify(formparams);
				formparams = formparams.replace("{","");
				formparams = formparams.replace("}","");
				formparams = formparams.replace(/:/g,"=");
				formparams = formparams.replace(/,/g,"&");
				formparams = formparams.replace(/["]/g,"");
				
			}
			switch (flow) {
			case "PROXY_REQ_FLOW":
				loggingUlffContent["payload"]=formparams || payload || context.getVariable('message.content');
				loggingUlffContent["logpoint"]="request-in";
				loggingUlffContent["status"]='';
				loggingUlffContent["status-flow"]='';
				loggingUlffContent["error-code"]='';
				loggingUlffContent["subscriber-id"]=subscriberId;
				loggingUlffContent["error"]='';
				loggingUlffContent["error-msg"]='';		
				loggingUlffContent["layer"]="apix";
				loggingUlffContent["content-type"]=context.getVariable('request.header.Content-Type');
				loggingUlffContent["timestamp-in"]=dateForLog;
				loggingUlffContent["timestamp-out"]='';
				loggingUlffContent["inbound-request-uri"]=context.getVariable('request.path');
				loggingUlffContent["caller-id"]=context.getVariable('VF_INT_CALLER_ID_req_Orig') || context.getVariable('app.vf_app_org_uuid') || 'unknown';
				loggingUlffContent["outbound-url"]='';
				
				var VF_INT_TRACK_ID = context.getVariable('VF_INT_TRACK_ID_req_Orig') || '';
				if(VF_INT_TRACK_ID)
				{
					loggingUlffContent["correlation-tracking"]=VF_INT_TRACK_ID + '.' + context.getVariable('apiproxy.name') + '-apix';
				}
				else
				{
					loggingUlffContent["correlation-tracking"]=context.getVariable('apiproxy.name') + '-apix';
				}
				break;
			case "PROXY_RESP_FLOW":
				loggingUlffContent["payload"]=formparams || payload || context.getVariable('message.content');
				loggingUlffContent["logpoint"]="response-out";
				loggingUlffContent["status"]=responseStatus;
				loggingUlffContent["status-flow"]=VF_INT_STATUS_FLOW||'';
				loggingUlffContent["status-code"]=statusCode || context.getVariable("message.status.code");
				loggingUlffContent["error-code"]='';
				loggingUlffContent["subscriber-id"]=subscriberId;
				loggingUlffContent["error"]='';
				loggingUlffContent["error-msg"]='';		
				loggingUlffContent["layer"]="apix";
				loggingUlffContent["content-type"]=context.getVariable('request.header.Content-Type');
				loggingUlffContent["timestamp-in"]='';
				loggingUlffContent["timestamp-out"]=dateForLog;
				loggingUlffContent["inbound-request-uri"]='';
				loggingUlffContent["caller-id"]=context.getVariable('VF_INT_CALLER_ID_resp') || context.getVariable('VF_INT_CALLER_ID_req') || context.getVariable('app.vf_app_org_uuid') || 'unknown';
				loggingUlffContent["outbound-url"]='';
				
				var VF_INT_TRACK_ID = context.getVariable('VF_INT_TRACK_ID_resp')||context.getVariable('VF_INT_TRACK_ID_req');
				if(VF_INT_TRACK_ID)
				{
					loggingUlffContent["correlation-tracking"]=VF_INT_TRACK_ID + '.' + context.getVariable('apiproxy.name') + '-apix';
				}
				break;
			case "TARGET_REQ_FLOW":
				loggingUlffContent["payload"]=formparams || payload || context.getVariable('message.content');
				loggingUlffContent["logpoint"]="request-out";
				loggingUlffContent["status"]='';
				loggingUlffContent["status-flow"]='';
				loggingUlffContent["error-code"]='';
				loggingUlffContent["subscriber-id"]=subscriberId;
				loggingUlffContent["error"]='';
				loggingUlffContent["error-msg"]='';		
				loggingUlffContent["layer"]="apix";
				loggingUlffContent["content-type"]=context.getVariable('request.header.Content-Type');
				loggingUlffContent["timestamp-in"]='';
				loggingUlffContent["timestamp-out"]=dateForLog;
				loggingUlffContent["inbound-request-uri"]='';
				loggingUlffContent["caller-id"]=context.getVariable('VF_INT_CALLER_ID_req_Orig') || context.getVariable('app.vf_app_org_uuid') || 'unknown';
				loggingUlffContent["outbound-url"]=context.getVariable('outboundTargetUrl') || context.getVariable('target.url');
				
				var VF_INT_TRACK_ID = context.getVariable('VF_INT_TRACK_ID_req_Orig') || '';
				if(VF_INT_TRACK_ID)
				{
					loggingUlffContent["correlation-tracking"]=VF_INT_TRACK_ID + '.' + context.getVariable('apiproxy.name') + '-apix';
				}
				else
				{
					loggingUlffContent["correlation-tracking"]=context.getVariable('apiproxy.name') + '-apix';
				}		
				break;
			case "TARGET_RESP_FLOW":
				loggingUlffContent["payload"]=formparams || payload || context.getVariable('message.content');
				loggingUlffContent["logpoint"]="response-in";
				loggingUlffContent["status"]=responseStatus;
				loggingUlffContent["status-flow"]=VF_INT_STATUS_FLOW||'';
				loggingUlffContent["status-code"]=statusCode || context.getVariable("message.status.code");
				loggingUlffContent["error-code"]='';
				loggingUlffContent["subscriber-id"]=subscriberId;
				loggingUlffContent["error"]='';
				loggingUlffContent["error-msg"]='';
				loggingUlffContent["layer"]="apix";
				loggingUlffContent["content-type"]=context.getVariable('request.header.Content-Type');
				loggingUlffContent["timestamp-in"]=dateForLog;
				loggingUlffContent["timestamp-out"]='';
				loggingUlffContent["inbound-request-uri"]='';
				loggingUlffContent["caller-id"]=context.getVariable('VF_INT_CALLER_ID_resp') || context.getVariable('VF_INT_CALLER_ID_req') || context.getVariable('app.vf_app_org_uuid') || 'unknown';
				loggingUlffContent["outbound-url"]='';
				
				var VF_INT_TRACK_ID = context.getVariable('VF_INT_TRACK_ID_resp')||context.getVariable('VF_INT_TRACK_ID_req');
				if(VF_INT_TRACK_ID)
				{
					loggingUlffContent["correlation-tracking"]=VF_INT_TRACK_ID + '.' + context.getVariable('apiproxy.name') + '-apix';
				}		
				break;
			case "ERROR":
				var logPoint = context.getVariable("logPoint");
				if(logPoint == "response-in")
				{
					loggingUlffContent["payload"]=formparams || payload || context.getVariable('message.content');
					loggingUlffContent["logpoint"]="response-in";
					loggingUlffContent["status"]=responseStatus;
					loggingUlffContent["status-flow"]=VF_INT_STATUS_FLOW||'';
					loggingUlffContent["status-code"]=statusCode || context.getVariable("message.status.code");
					loggingUlffContent["error-code"]=statusCode || context.getVariable("message.status.code");
					loggingUlffContent["subscriber-id"]=subscriberId;
					loggingUlffContent["error"]=errorCode || err || '';
					loggingUlffContent["error-msg"]=errorDescription || desc || '';
					loggingUlffContent["layer"]="apix";
					loggingUlffContent["content-type"]=context.getVariable('request.header.Content-Type');
					loggingUlffContent["timestamp-in"]=dateForLog;
					loggingUlffContent["timestamp-out"]='';
					loggingUlffContent["inbound-request-uri"]='';
					loggingUlffContent["caller-id"]=context.getVariable('VF_INT_CALLER_ID_resp') || context.getVariable('VF_INT_CALLER_ID_req') || context.getVariable('app.vf_app_org_uuid') || 'unknown';
					loggingUlffContent["outbound-url"]='';
					
					var VF_INT_TRACK_ID = context.getVariable('VF_INT_TRACK_ID_resp')||context.getVariable('VF_INT_TRACK_ID_req');
					if(VF_INT_TRACK_ID)
					{
						loggingUlffContent["correlation-tracking"]=VF_INT_TRACK_ID + '.' + context.getVariable('apiproxy.name') + '-apix';
					}		
					break;
				}
				else
				{
					loggingUlffContent["payload"]=formparams || payload || context.getVariable('message.content');
					loggingUlffContent["logpoint"]="response-out";
					loggingUlffContent["status"]=responseStatus;
					loggingUlffContent["status-flow"]=VF_INT_STATUS_FLOW||'';
					loggingUlffContent["status-code"]=statusCode || context.getVariable("message.status.code");
					loggingUlffContent["error-code"]=statusCode || context.getVariable("message.status.code");
					loggingUlffContent["subscriber-id"]=subscriberId;
					loggingUlffContent["error"]=errorCode || err || '';
					loggingUlffContent["error-msg"]=errorDescription || desc || '';
					loggingUlffContent["layer"]="apix";
					loggingUlffContent["content-type"]=context.getVariable('request.header.Content-Type');
					loggingUlffContent["timestamp-in"]='';
					loggingUlffContent["timestamp-out"]=dateForLog;
					loggingUlffContent["inbound-request-uri"]='';
					loggingUlffContent["caller-id"]=context.getVariable('VF_INT_CALLER_ID_resp') || context.getVariable('VF_INT_CALLER_ID_req') || context.getVariable('app.vf_app_org_uuid') || 'unknown';
					loggingUlffContent["outbound-url"]='';
					
					var VF_INT_TRACK_ID = context.getVariable('VF_INT_TRACK_ID_resp')||context.getVariable('VF_INT_TRACK_ID_req');
					if(VF_INT_TRACK_ID)
					{
						loggingUlffContent["correlation-tracking"]=VF_INT_TRACK_ID + '.' + context.getVariable('apiproxy.name') + '-apix';
					}
					else
					{
						loggingUlffContent["correlation-tracking"]=context.getVariable('apiproxy.name') + '-apix';
					}
					break;
				}
			}
		}
		
		if (loggingUlffContent["payload"])
		{
			loggingUlffContent["message-size"]= loggingUlffContent["payload"].length;
		}
		else
		{
			loggingUlffContent["message-size"]= 0;
		}

		loggingUlffContent["msisdn"]=payloadMSISDN ||oauthMsisdn;
		loggingUlffContent["caller-apikey"]=oauthClientId;

		loggingUlffContent["component"]=context.getVariable('apiproxy.name');
		loggingUlffContent["service"] = context.getVariable('currentFlowName')||'';

		if(context.getVariable('X_Forwarded_Proto_req') && context.getVariable('X_Forwarded_Host_req') && context.getVariable('X_Forwarded_Port_req'))
		{
			loggingUlffContent["server-name"]=context.getVariable('X_Forwarded_Proto_req') + '://' + context.getVariable('X_Forwarded_Host_req') + ':' + context.getVariable('X_Forwarded_Port_req');
		}
		else
		{
			loggingUlffContent["server-name"]='';
		}

		loggingUlffContent["env-name"]=context.getVariable('environment.name');
		loggingUlffContent["flow"]=flow;
		loggingUlffContent["message-processor-uuid"]=context.getVariable("system.uuid");
		loggingUlffContent["acr"]=context.getVariable("acr")||'';

		
		if(HeaderList != '[]')
		{
			var HeaderListStr = HeaderList.toString();
			HeaderListStr = HeaderListStr.replace('[',''); HeaderListStr = HeaderListStr.replace(']',''); HeaderListStr = HeaderListStr.replace(' ', '');
			
			var HeaderListArray = HeaderListStr.split(',');
			for(k=0; k<HeaderListArray.length; k++)
			{
				var HdrValue = context.getVariable('message.header.'+HeaderListArray[k]+'.values')+'';
				HdrValue = HdrValue.substr(1, HdrValue.length - 2);
				HdrValue = HdrValue.replace(/[\\]/g,'\\\\').replace(/["]/g, '\\"');
				headers = headers + ('"'+HeaderListArray[k]+'":"'+HdrValue+'",');
				
				if(HeaderListArray[k].search(/authorization/i) != -1)
				{
					var AuthHdrName = HeaderListArray[k];
				}
			}
			
			headers = headers.substr(0, headers.length - 1);
			headers = '{' + headers + '}';
			headers = JSON.parse(headers);

			var headers_auth = headers[AuthHdrName];
			if(headers_auth)
			{
				headers_auth = headers_auth.substr(0,21);
				headers[AuthHdrName] = headers_auth;
			}
		}
		
		
		if(headersToMask && headers){
			loggingUlffContent["headers"] = maskHeaders(headersToMask, headers);
		}else{
			loggingUlffContent["headers"] = headers;
		}

		loggingUlffContent["service-flow"] = context.getVariable('current.flow.name')||'';
		loggingUlffContent["api-product"]= context.getVariable("apiproduct.name") || "";
		loggingUlffContent["caller-app"]= context.getVariable("developer.app.name") || "";
		loggingUlffContent["verb"]= context.getVariable("request.verb");

		loggingUlffContent["throttling-limit"]= context.getVariable("throttling_spike_arrest_rate") || "";
		loggingUlffContent["api-quota-1min-limit"]= context.getVariable("throttling_quota_1min_count") || "";
		loggingUlffContent["api-quota-5min-limit"]= context.getVariable("throttling_quota_5min_count") || "";
		loggingUlffContent["api-quota-10min-limit"]= context.getVariable("throttling_quota_10min_count") || "";
		loggingUlffContent["client-quota-1min-limit"]= context.getVariable("throttling_quota_client_1min_count") || "";
		loggingUlffContent["client-quota-10min-limit"]= context.getVariable("throttling_quota_client_10min_count") || "";
		loggingUlffContent["backend-quota-limit"]= context.getVariable("throttling_quota_backend_count") || "";
		loggingUlffContent["resource-quota-limit"]= context.getVariable("throttling_quota_resource_count") || "";

		context.setVariable("loggingUlffContent", JSON.stringify(loggingUlffContent));
	} catch (err) {
		context.setVariable("loggingUlffContent", JSON.stringify(loggingUlffContent));		
		throw err;
	}
}

function maskHeaders(headersToMask, headers){
	headersToMask = headersToMask.toLowerCase();
	headersList= headersToMask.split(",");
	
	if(response){
		for(var i in response.headers){
			if(i && headersList.indexOf(i.toLowerCase()) > -1 ){
				headers[i] = "********";
			}
		}
	} else{
		for(var i in request.headers){
			if(i && headersList.indexOf(i.toLowerCase()) > -1 ){
				headers[i] = "********";
			}
		}
	}
	return headers;
};

function maskFormParam(formParamToMask, fparam){
	formParamToMask = formParamToMask.toLowerCase();
	formParamList = formParamToMask.split(",");
	
	for(var i in fparam){
		if(i && formParamList.indexOf(i.toLowerCase()) > -1 ){
			fparam[i] = "********";
		}
	}
	return fparam;
};

function maskQueryParam(queryParamToMask, inboundRequestUri){	
	queryParamToMask = queryParamToMask.toLowerCase();
	QueryList= queryParamToMask.split(",");
	var newString = inboundRequestUri;
	for(var i in QueryList){				
	  var re = new RegExp("[\\?&]" + QueryList[i] + "=([^&#]*)");
	  var matches = re.exec(inboundRequestUri);			
		if (newString.indexOf(QueryList[i])>0) {        
			var delimeter = matches[0].charAt(0);
			newString = newString.replace(re, delimeter + QueryList[i] + "=" + "masked");
			}
		}
		return newString;

};
