function AccessPayloadSize()
{
	try
	{
		var max_request_uri_size = context.getVariable('max_request_uri_size');
		var max_header_size = context.getVariable('max_header_size');
		var max_content_size = context.getVariable('max_content_size');
				
		var proxy_url = context.getVariable('proxy.url');
		var HeaderList = context.getVariable('request.headers.names');
		var payload	= context.getVariable('message.content');
		
		var errorJSON;
		var exceptionName='';
		
		context.setVariable('access_payload_size',payload.length);
		
		if(isNaN(max_request_uri_size)==true || isNaN(max_header_size)==true || isNaN(max_content_size)==true)
		{
			throw err;
		}
		
		if(max_request_uri_size)
		{
			if(proxy_url.length > max_request_uri_size)
			{
				errorJSON = 'a42_generic_large_url';
				context.setVariable('errorJSON',errorJSON);
				exceptionName = 'genericLargeURL';
				throw exceptionName;
			}
		}
		
		if(max_header_size && HeaderList!='[]')
		{
			var HdrSize = 0;
			for(var HdrName in request.headers)
			{
				var HdrValue = context.getVariable('request.header.'+HdrName+'.values')+'';
				HdrSize = HdrSize + (HdrName.length + HdrValue.length-2);
			}
			if(HdrSize > max_header_size)
			{
					errorJSON = 'a42_generic_large_header_value';
					context.setVariable('errorJSON',errorJSON);
					exceptionName = 'genericLargeHeaderValue';
					throw exceptionName;
			}
		}
		
		if(max_content_size && payload)
		{	
			if(payload.length > max_content_size)
			{
				errorJSON = 'a42_generic_large_payload';
				context.setVariable('errorJSON',errorJSON);
				exceptionName = 'genericLargePayload';
				throw exceptionName;
			}		
		}
	}

	catch(err)
	{
		if(!errorJSON)
		{
			context.setVariable('errorJSON','a42_generic_internal_config_error');
			throw err;
		}
		else
		{
			throw exceptionName;
		}
	}
}