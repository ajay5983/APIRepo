/* global context*/
generateLogBackEndServiceCallOut = function generateLogBackEndServiceCallOut(){ // eslint-disable-line no-undef


	var inboundRequestUri = context.getVariable("proxy.url");
	var serviceCalloutReq = context.getVariable("ULFF_LOGGING_REQ_VAR");
	var serviceCalloutRes = context.getVariable("ULFF_LOGGING_RES_VAR");

	try {
		var oauthTokenAttributes = context.getVariable("oauthTokenDetails");
		if (oauthTokenAttributes) {
			var oauthTokenDetails = JSON.parse(oauthTokenAttributes);
		}
	} catch (err) {
		throw err;
	}

	var flow = context.flow;
	var customVariables = context.getVariable('customVariables');
	var apiName = context.getVariable('apiproxy.name');
	var orgName = context.getVariable('organization.name');
	var envName = context.getVariable('environment.name');
	var flowName = context.getVariable('current.flow.name');

	var messageProcessorUUID = context.getVariable('system.uuid');
	var usecaseId = context.getVariable('request.header.x-vf-ext-bp-id');
	var msisdn = context.getVariable('msisdn');
	var countryCode = context.getVariable('countryCode');

	var apiRateLimit = context.getVariable('apiproduct.developer.quota.limit')
			|| context.getVariable('limit');

	var backendUri = context.getVariable("SERVICE_CALLOUT_URL");

	var transactionId = getTranscationID();

	var logData = {

		"transaction-id" : transactionId,
		"timestamp" : getTimeStamp(),
		"component" : "APIX",
		"server-name" : orgName,
		"service" : apiName,
		"env-name" : envName,
		"inbound-request-uri" : inboundRequestUri,
		"service-flow" : flowName,
		"flow" : flow,
		"message-processor-uuid" : messageProcessorUUID,
		"api-rate-limit" : apiRateLimit,
		"uri" : backendUri
				|| context.getVariable(serviceCalloutReq + ".header.Host")
				+ context.getVariable(serviceCalloutReq + ".uri")
	}

	if (null == oauthTokenDetails || "" == oauthTokenDetails) {
		logData["api-product"] = context.getVariable("apiproduct.name");
		logData["caller-id"] = context.getVariable("developer.email");
		logData["caller-app"] = context.getVariable("developer.app.name");
		logData["caller-apikey"] = context.getVariable("client_id");
		logData["msisdn"] = msisdn;
	} else {
		logData["api-product"] = oauthTokenDetails.Scopes;
		logData["caller-id"] = oauthTokenDetails.callerID;
		logData["caller-app"] = oauthTokenDetails.appName;
		logData["caller-apikey"] = oauthTokenDetails.ClientId;
		logData["msisdn"] = oauthTokenDetails.Msisdn;
	}
	logData["usecase-id"] = usecaseId;
	logData["country-code"] = countryCode;
	logData["customVariables"] = customVariables;
	logData["error"] = null;
	logData["error-code"] = null;
	if (!serviceCalloutRes || !serviceCalloutReq) {
		context.setVariable("logSCdata", false);
	} else {
		context.setVariable("logSCdata", true);
		context.setVariable("ULFF_LOGGING_REQ_VAR", null);
		context.setVariable("ULFF_LOGGING_RES_VAR", null);
		if (serviceCalloutRes) {
			var resLogData = logData;
			resLogData["headers"] = getHeadersWithValues(context
					.getVariable(serviceCalloutRes + ".headers.names"),
					serviceCalloutRes);
			resLogData["payload"] = context
					.getVariable("ServiceCallout.response");
			resLogData["logpoint"] = "backend-service-callout-response";
			resLogData["status-code"] = context.getVariable(serviceCalloutRes
					+ ".status.code");
			var status = getStatus(context.getVariable(serviceCalloutRes
					+ ".status.code"), context.getVariable(serviceCalloutRes
					+ ".reason.phrase"));
			resLogData["status"] = status;
			if (resLogData["payload"]) {
				resLogData["message-size"] = resLogData["payload"].length;
			} else {
				resLogData["message-size"] = 0;
			}
			context.setVariable("resLogData", JSON.stringify(resLogData));
		}
		if (serviceCalloutReq) {
			var reqLogData = logData;
			reqLogData["headers"] = getHeadersWithValues(context
					.getVariable(serviceCalloutReq + ".headers.names"),
					serviceCalloutReq);
			resLogData["payload"] = context
					.getVariable("ServiceCallout.response");
			reqLogData["logpoint"] = "backend-service-callout-request";
			if (reqLogData["payload"]) {
				reqLogData["message-size"] = reqLogData["payload"].length;
			} else {
				reqLogData["message-size"] = 0;
			}
			context.setVariable("reqLogData", JSON.stringify(reqLogData));
		}
	}


	function generateUUID() {
		var d = new Date().getTime();
		var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,
				function(c) {
					var r = (d + Math.random() * 16) % 16 | 0;
					d = Math.floor(d / 16);
					return (c == 'x' ? r : (r & 0x7 | 0x8)).toString(16);
				});
		return uuid;
	}

	function getStatus(statusCode, reasonPhrase) {
		var status = null;
		if (statusCode && reasonPhrase) {
			statusCode = statusCode.toString();
			if ((reasonPhrase.toLowerCase()).indexOf("timeout") > -1) {
				status = "timeout";
			} else if ((statusCode.charAt(0) === "1"
					|| statusCode.charAt(0) === "2" || statusCode.charAt(0) === "3")) {
				status = "ok";
			} else {
				status = "error";
			}

		}
		return status;
	}

	function getTimeStamp() {

		var d = new Date();
		var n = d.toTimeString();
		var timezone = "+";

		n = d.getTimezoneOffset() + "";
		if (n > 0) {
			timezone = "-"
		}
		n = n.substring(1);
		var hours = ("00" + (n / 60)).slice(-2);
		var minutes = ("00" + (n % 60)).slice(-2);
		timezone += hours + ":" + minutes;

		return ("00" + (context.getVariable("system.time.year"))).slice(-4)
				+ "-"
				+ ("00" + (context.getVariable("system.time.month"))).slice(-2)
				+ "-"
				+ ("00" + (context.getVariable("system.time.day"))).slice(-2)
				+ "T"
				+ ("00" + (context.getVariable("system.time.hour"))).slice(-2)
				+ ":"
				+ ("00" + (context.getVariable("system.time.minute")))
						.slice(-2)
				+ ":"
				+ ("00" + (context.getVariable("system.time.second")))
						.slice(-2)
				+ ","
				+ ("00" + (context.getVariable("system.time.millisecond")))
						.slice(-3) + timezone;
	}

	function getTranscationID() {
		var transactionId = context.getVariable("requestUUIDToLog");
		if (!transactionId) {
			transactionId = context
					.getVariable("request.header.x-vf-trace-transaction-id");
			if (!transactionId)
				transactionId = generateUUID();
			context.setVariable("requestUUIDToLog", transactionId);
		}
		return transactionId;
	}

	function getHeadersWithValues(headerNames, flowObject) {

		var headerJson = {};
		if (null == headerNames || "" == headerNames) {
			return headerJson;
		} else if (null == flowObject || "" == flowObject) {
			return headerJson;
		}
		headerNames = headerNames + "";
		headerNames = headerNames.replace("[", "");
		headerNames = headerNames.replace("]", "");

		var headerArray = headerNames.split(",");
		for (var i = 0; i < headerArray.length; i++) {
			var header = headerArray[i];
			if (header) {
				header = header.trim();
				var headerVal = context.getVariable(flowObject + '.header.'
						+ header);
				headerJson[header] = headerVal;

			}
		}
		context.setVariable("debugHeaderJson", JSON.stringify(headerJson));
		return JSON.stringify(headerJson);
	}

};
