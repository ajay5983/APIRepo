try
{
	checkXSSInRequest();
}
catch(err)
{
	throw err;
}