buildDownloadUrl = function buildDownloadUrl(){ // eslint-disable-line no-undef

	var apixEndPoint = context.getVariable("APIXEndpoint");
	var downloadUrl = [];
	var hashCodeSHA2 = context.getVariable("sha2codeArray");
	var bearerToken = context.getVariable("access_token");
	var expireIn = context.getVariable("expires_in");
	var cookie = "bearer-token=" + bearerToken + "; Path=/"
    + "; Max-Age=" + expireIn + "; Secure; HttpOnly";

	context.setVariable("response.header.Set-Cookie", cookie);

	if (hashCodeSHA2) {
		hashCodeSHA2 = hashCodeSHA2.split(",");
		for (var i = 0 ; hashCodeSHA2.length > i;++i){
			if (hashCodeSHA2[i]){
				downloadUrl.push("https://" + apixEndPoint + "/v1/download/" + hashCodeSHA2[i]);
			} else {
				downloadUrl.push("");
			}
		}
	}
	context.setVariable("downloadUrl", downloadUrl.toString());
};