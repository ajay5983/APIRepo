try
{
	CSMOpCoValidation();
}
catch(err)
{
	throw err;
}