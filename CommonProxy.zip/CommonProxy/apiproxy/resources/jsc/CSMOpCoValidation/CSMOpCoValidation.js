/* global context*/
CSMOpCoValidation = function CSMOpCoValidation(){ // eslint-disable-line no-undef

var opCo = context.getVariable("request.header.vf-country-code");
var customizedErrorMessage='';

if(opCo === null || opCo == ""){
	customizedErrorMessage={
			"statusCode": "400",
			"reasonPhrase": "Bad Request", 
			"errorCode": "invalid_request", 
			"errorDescription": "The request is missing the mandatory request header vf-country-code"
			};
	
	context.setVariable("errorJSON", 'customizedErrorMessage');
	context.setVariable("customizedErrorMessage", JSON.stringify(customizedErrorMessage));
	throw "Bad Request";
	
}else{
    context.setVariable("countryISO",opCo.toUpperCase());
}

}

