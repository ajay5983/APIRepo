var faultName = context.getVariable("faultName");
var errorMessage = context.getVariable("errorMessage");
var errorDetail = context.getVariable("errorDetail");
var errorCode = context.getVariable("errorCode");
var errorId = context.getVariable("errorId");
var acceptHeader = context.getVariable("request.header.Accept");
var errorResponseType = "json";
var errorJSON = context.getVariable("errorJSON");
	
	if (faultName == "InvalidAPICallAsNoApiProductMatchFound"){
		parsedJSON = JSON.parse(context.getVariable("a42_oauth_unauthorized_client"));
		context.setVariable("parsedJSON",parsedJSON);
		errorMessage = parsedJSON.reasonPhrase;
		errorDetail = parsedJSON.errorDescription;
		errorCode = parsedJSON.statusCode;	
		errorId = parsedJSON.errorCode;
		
	}else if (faultName == "InvalidClientIdForGivenResource"){
		parsedJSON = JSON.parse(context.getVariable("a42_oauth_scope_missing_invalid"));
		context.setVariable("parsedJSON",parsedJSON);
		errorMessage = parsedJSON.reasonPhrase;
		errorDetail = parsedJSON.errorDescription;
		errorCode = parsedJSON.statusCode;	
		errorId = parsedJSON.errorCode;
		
	}else if (faultName == "invalid_access_token"){
		parsedJSON = JSON.parse(context.getVariable("a42_generic_invalid_access_token"));
		context.setVariable("parsedJSON",parsedJSON);
		errorMessage = parsedJSON.reasonPhrase;
		errorDetail = parsedJSON.errorDescription;
		errorCode = parsedJSON.statusCode;	
		errorId = parsedJSON.errorCode;
	} 
	else if (faultName == "InvalidBasicAuthenticationSource"){
		parsedJSON = JSON.parse(context.getVariable("a42_generic_invalid_authorization_header"));
		context.setVariable("parsedJSON",parsedJSON);
		errorMessage = parsedJSON.reasonPhrase;
		errorDetail = parsedJSON.errorDescription;
		errorCode = parsedJSON.statusCode;	
		errorId = parsedJSON.errorCode;
	} 
	else if (faultName == "access_token_expired"){
		parsedJSON = JSON.parse(context.getVariable("a42_generic_expired_access_token"));
		context.setVariable("parsedJSON",parsedJSON);
		errorMessage = parsedJSON.reasonPhrase;
		errorDetail = parsedJSON.errorDescription;
		errorCode = parsedJSON.statusCode;	
		errorId = parsedJSON.errorCode;
	}
	else if (faultName == "access_token_not_approved"){
		parsedJSON = JSON.parse(context.getVariable("a42_generic_revoked_access_token"));
		context.setVariable("parsedJSON",parsedJSON);
		errorMessage = parsedJSON.reasonPhrase;
		errorDetail = parsedJSON.errorDescription;
		errorCode = parsedJSON.statusCode;	
		errorId = parsedJSON.errorCode;
	}
	else if (faultName == "SpikeArrestViolation"){
		parsedJSON = JSON.parse(context.getVariable("a42_generic_spike_arrest_violation"));
		context.setVariable("parsedJSON",parsedJSON);
		errorMessage = parsedJSON.reasonPhrase;
		errorDetail = parsedJSON.errorDescription;
		errorCode = parsedJSON.statusCode;	
		errorId = parsedJSON.errorCode;
	}
	else if (faultName == "QuotaViolation"){
		parsedJSON = JSON.parse(context.getVariable("a42_generic_quota_limit_reached"));
		context.setVariable("parsedJSON",parsedJSON);
		errorMessage = parsedJSON.reasonPhrase;
		errorDetail = parsedJSON.errorDescription;
		errorCode = parsedJSON.statusCode;	
		errorId = parsedJSON.errorCode;
	}
	 else if (faultName == "JsonPathParsingFailure"){
		parsedJSON = JSON.parse(context.getVariable("a42_generic_invalid_json_format"));
		context.setVariable("parsedJSON",parsedJSON);
		errorMessage = parsedJSON.reasonPhrase;
		errorDetail = parsedJSON.errorDescription;
		errorCode = parsedJSON.statusCode;	
		errorId = parsedJSON.errorCode;
	 }
	else if ((faultName == "") || (faultName == null)){
		parsedJSON = JSON.parse(context.getVariable("a42_generic_internal_server_error"));
		context.setVariable("parsedJSON",parsedJSON);
		errorMessage = parsedJSON.reasonPhrase;
		errorDetail = parsedJSON.errorDescription;
		errorCode = parsedJSON.statusCode;	
		errorId = parsedJSON.errorCode;
	}
 else if (errorJSON){
	 parsedJSON = JSON.parse(context.getVariable(errorJSON));
	 context.setVariable("parsedJSON",parsedJSON);
	 errorMessage = parsedJSON.reasonPhrase;
	errorDetail = parsedJSON.errorDescription;
	errorCode = parsedJSON.statusCode;	
	errorId = parsedJSON.errorCode;
	 
 }
 
 else if ( (!(errorMessage == null)) || (!(errorMessage == "")) )
 {
		errorMessage = errorMessage;
		errorDetail = errorDetail;
		errorCode = errorCode;	
		errorId = errorId;
 }
 
 else {
	parsedJSON = JSON.parse(context.getVariable(errorJSON));
	context.setVariable("parsedJSON",parsedJSON);
	errorMessage = parsedJSON.reasonPhrase;
	errorDetail = parsedJSON.errorDescription;
	errorCode = parsedJSON.statusCode;	
	errorId = parsedJSON.errorCode;
	}

 if	((acceptHeader == "application/xml") ||(acceptHeader == "text/xml") ){
	 errorResponseType = "xml"; 
 }
 
context.setVariable("errorResponseType", errorResponseType);
context.setVariable("errorMessage",errorMessage);
context.setVariable("errorDetail",errorDetail);
context.setVariable("errorCode",errorCode);
context.setVariable("errorId",errorId);

var date = new Date();
dateForFault = date.toISOString();
context.setVariable("dateForFault", dateForFault);