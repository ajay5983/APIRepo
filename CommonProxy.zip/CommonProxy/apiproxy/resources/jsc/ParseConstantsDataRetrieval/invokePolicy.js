try
{
    ParseConstantsDataRetrieval();
}

catch(err){
	context.setVariable("errorJSON","a42_generic_internal_config_error");
	throw err;
}