try{
var country_code = context.getVariable("countryISO");
var apiname = context.getVariable("apiname");

if(!country_code){
	country_code = context.getVariable("accesstoken.country");
	context.setVariable("countryISO", country_code);
}

var dxl_opco_configuration =  context.getVariable("dxl_opco_configuration");
var isCachingEnabled = false;
var expiry = 0;
var countrySpecificCacheName;

var flowName = context.getVariable("currentFlowName");

if(!flowName){
	flowName = context.getVariable("current.flow.name");
}

dxl_opco_configuration =  JSON.parse(dxl_opco_configuration);

if(dxl_opco_configuration[country_code]){
	if(dxl_opco_configuration[country_code].enabled && dxl_opco_configuration[country_code].indexOf(flowName) > -1){
		isCachingEnabled = true;
		expiry = dxl_opco_configuration[country_code].expiry;
		countrySpecificCacheName = "dxl_" + country_code + "_" + apiname + "_cache";
	}	
}

context.setVariable("isCachingEnabled", isCachingEnabled);
context.setVariable("expiry", expiry);
context.setVariable("dxl_country_cache", countrySpecificCacheName);

}catch(err){
	context.setVariable('errorJSON','a42_generic_internal_server_error');
	throw err;
}