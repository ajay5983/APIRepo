// This is used to check and validate scope and set Flow Name
try {
	var tokenscopes = context.getVariable("accesstoken.scope");
	tokenscopes =  tokenscopes.split(' ');
	
	var apiScopes = context.getVariable("apiScopes");
	var valid_api_scopes = false;
	
	//API level scope Validation
	if(apiScopes){
		apiScopes =  apiScopes.split(',');
		for(var i = 0 ; tokenscopes.length > i ; i++){
			if(apiScopes.indexOf(tokenscopes[i]) > -1){
				valid_api_scopes = true;
				break;
			}
		}
	}
	
	if(!valid_api_scopes){
		context.setVariable('errorJSON', 'a42_generic_invalid_scope_for_api');
		throw "insufficientScopeError";
	}
	
	//Resource Level Scope Validation
	var flowName = context.getVariable("current.flow.name");
	context.setVariable("currentFlowName",flowName);
	
	var valid_resource_scopes = false;
	
	var allowedScopes = context.getVariable('allowedScopes');
	var flowScopes;

	allowedScopes =  JSON.parse(allowedScopes);
	
	for(var i = 0 ; allowedScopes.length > i ; i++){
		if(allowedScopes[i].flowName === flowName){
			flowScopes = allowedScopes[i].allowedScopesList;
	        break;
	    }
	}
	
	if(flowScopes){
		flowScopes =  flowScopes.split(',');
		for(var i=0; flowScopes.length > i; i++)
		{
			if(tokenscopes.indexOf(flowScopes[i]) > -1)
			{
				valid_resource_scopes = true;
				break;
			}
		}	
	}
	
	if (!valid_resource_scopes)
	{
		context.setVariable('errorJSON', 'a42_generic_insufficient_scope');
		throw "insufficientScopeError";
	}
}
catch (err)
{
	throw err;
}