AccessCountryEnabled = function AccessCountryEnabled()
{
	try
	{
		var country = context.getVariable('countryISO');
		var access_country_enabled = context.getVariable('access_country_enabled');
		var errorJSON;
		var exceptionName='';
		
		if ((!country) || (typeof access_country_enabled == 'undefined'))
		{
			errorJSON = 'a42_generic_internal_config_error';
			context.setVariable('errorJSON',errorJSON);
			exceptionName = 'internalConfigError';
			throw exceptionName;
		}
		else if(access_country_enabled != '')
		{
			access_country_enabled_array = access_country_enabled.split(",");
			if(access_country_enabled_array.indexOf(country) == -1)
			{
				errorJSON = 'a42_generic_invalid_country_id';
				context.setVariable('errorJSON',errorJSON);
				exceptionName = 'invalidCountryID';
				throw exceptionName;
			}
		}
	}
	catch(err)
	{
		if(!errorJSON)
		{
			context.setVariable('errorJSON','a42_generic_internal_server_error');
			throw err;
		}
		else
		{
			throw exceptionName;
		}
	}
}