checkServiceEligibilty = function checkServiceEligibilty(){ // eslint-disable-line no-undef
var serviceEligibilityCheckUserInfoResponse = context.getVariable("serviceEligibilityCheckUserInfoResponse");
var serviceEligibilityRequirements = context.getVariable("serviceEligibilityRequirements");
var isKYCStatusRequired =  false;
var isProfileCompleteNessRequired = false;

var isKYCStatusVerified =  true;
var isProfileCompleteNessVerified =  true;

var KYCStatus;
var profileCompletenessStatus;

serviceEligibilityRequirements = serviceEligibilityRequirements.split(",");

if(serviceEligibilityRequirements.indexOf("KYCStatus") > -1){
	isKYCStatusRequired =  true;
}

if(serviceEligibilityRequirements.indexOf("Completeness") > -1){
	isProfileCompleteNessRequired =  true;
}

if(isKYCStatusRequired){
	if(serviceEligibilityCheckUserInfoResponse["kyc"] && serviceEligibilityCheckUserInfoResponse["kyc"]["status"]){
		KYCStatus = serviceEligibilityCheckUserInfoResponse["kyc"]["status"].trim();
		if(KYCStatus !== 'verified'){
			isKYCStatusVerified =  false;
		}
	}else{
		isKYCStatusVerified = false;
	}
}

if(isProfileCompleteNessRequired){
	if(serviceEligibilityCheckUserInfoResponse["kyc"] && serviceEligibilityCheckUserInfoResponse["kyc"]["completeness"]){
		profileCompletenessStatus = serviceEligibilityCheckUserInfoResponse["kyc"]["completeness"].trim();
		if(profileCompletenessStatus !== 'completed'){
			isProfileCompleteNessVerified =  false;
		}
	}else{
		isProfileCompleteNessVerified = false;
	}
}

if((isKYCStatusRequired && !isKYCStatusVerified) || (isProfileCompleteNessRequired && !isProfileCompleteNessVerified)){
	context.setVariable("isServiceEligibilityVerified" , false);
	context.setVariable("errorResponseType", "json");
	context.setVariable("errorMessage", "kyc validation and completeness required");
	context.setVariable("errorDetail","missing kyc and/or completeness");
	context.setVariable("errorCode", "403");
	context.setVariable("reasonPhrase", "Unauthorized");
	
	var claims = context.getVariable("accesstoken.claimsFromRequest");
  	claims = JSON.parse(claims);
	var errorDescription = {};
  	if(claims["local_sub"]){
		errorDescription.localSub = claims["local_sub"];
    }else{
    	errorDescription.localSub = "";
    }
	
	var country = context.getVariable("accesstoken.Customer-Country-Code");

	if(!country){
		country = context.getVariable("msisdnCountry");
	}
	
	errorDescription.country = country;
	
	if(isKYCStatusRequired){
		if(KYCStatus){
			errorDescription.kycStatus = KYCStatus;
		}else{
			errorDescription.kycStatus = "";
		}
	}
	
	if(isProfileCompleteNessRequired){
		if(profileCompletenessStatus){
			errorDescription.completeness = profileCompletenessStatus;
		}else{
			errorDescription.completeness = "";
		}
	}
	
	context.setVariable("errorDescription", JSON.stringify(errorDescription));
	
}else{
	context.setVariable("isServiceEligibilityVerified" , true);
	context.setVariable("serviceEligibilityStatus" , "satisfied");
}
}
