try
{
	var HeaderList = context.getVariable('request.headers.names').toString();
	var IncomingMethod = context.getVariable('request.verb');
	
	var runtime_cors_allowed_origins = context.getVariable('runtime_cors_allowed_origins');
	var runtime_cors_allowed_methods = context.getVariable('runtime_cors_allowed_methods');
	
	var network_cors_allowed_origins = context.getVariable('network_cors_allowed_origins');
	var network_cors_allowed_methods =  context.getVariable('network_cors_allowed_methods');
	
	var validFlag;
	var errorJSON;
	var exceptionName='';
	
	if(HeaderList.search(/origin/i) != -1)
	{
	    var IncomingOrigin = context.getVariable('request.header.Origin');
		IncomingOrigin = IncomingOrigin.toLowerCase();
		if(network_cors_allowed_origins && network_cors_allowed_methods)
		{
			if(network_cors_allowed_origins.indexOf(IncomingOrigin) != -1)
			{
				if(network_cors_allowed_methods.indexOf(IncomingMethod) != -1)
				{
					validFlag=true;
				}
			}
		}
		else if(runtime_cors_allowed_origins && runtime_cors_allowed_methods){
		   if(runtime_cors_allowed_origins.indexOf(IncomingOrigin) != -1)
			{
				if(runtime_cors_allowed_methods.indexOf(IncomingMethod) != -1)
				{
					validFlag=true;
				}
			}
		}
		else
		{
			errorJSON = 'a42_generic_internal_config_error';
			context.setVariable('errorJSON',errorJSON);
			exceptionName = 'internalConfigError';
			throw exceptionName;
		}
		if(validFlag != true)
		{
			errorJSON = 'a42_generic_invalid_origin';
			context.setVariable('errorJSON',errorJSON);
			exceptionName = 'invalidCORSOrigin';
			throw exceptionName;
		}
	}
}
catch(err){
    if(!errorJSON)
    {
        context.setVariable('errorJSON','a42_generic_internal_config_error');
        throw err;
    }
    else
    {
        throw exceptionName;
    }
}