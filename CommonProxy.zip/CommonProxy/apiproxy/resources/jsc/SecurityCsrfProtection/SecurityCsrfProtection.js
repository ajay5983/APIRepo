securityCsrfProtection = function securityCsrfProtection(){ // eslint-disable-line no-undef
	try {
		var csrfHeader = context.getVariable("request.header.vf-csrf-token");
		var cookie = context.getVariable("request.header.Cookie");
		var authorization = context.getVariable("request.header.Authorization");
		var csrfAttribute = context.getVariable("accesstoken.csrf-token");
		var errorJSON;
		var csrfTokenCookie;
		if (cookie) {
			cookie = cookie.replace(/\s/g, "");
			var csrfTokenCookieArray = cookie.split(";");
			var sections;
			for (var i = 0; i < csrfTokenCookieArray.length; i++) {
				sections = csrfTokenCookieArray[i].split("=");
				if (sections[0] === "csrf-token") {
					csrfTokenCookie = sections[1];
					break;
				}
			}
		}
		if (csrfHeader || csrfTokenCookie){
			if (csrfHeader !== csrfTokenCookie) {
				errorJSON = "a42_generic_forbidden_error";
				context.setVariable("errorJSON", errorJSON);
				throw "missingHeaderException";
			}
			if (authorization !== null && authorization.indexOf("Bearer") !== -1) {
				if (csrfHeader !== csrfAttribute) {
					errorJSON = "a42_generic_forbidden_error";
					context.setVariable("errorJSON", errorJSON);
					throw "InValidTokenException";
				}
			}
		}
	} catch (err) {
		throw err;
	}
};