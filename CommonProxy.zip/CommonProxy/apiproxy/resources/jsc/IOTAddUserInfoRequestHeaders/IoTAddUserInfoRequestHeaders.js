adduserInfoRequestHeaders = function adduserInfoRequestHeaders(){ // eslint-disable-line no-undef
	var userInfoJWEToken = context.getVariable("userInfoJWEToken");

if(userInfoJWEToken){
	context.setVariable("request.header.UserInfoToken",userInfoJWEToken);
	context.setVariable("internalUserInfoCall","true");
}

var customerCountryCode = context.getVariable("msisdnCountry");
var existingCountryCodeInHeaders = context.getVariable("request.header.Customer-Country-Code");

if(customerCountryCode && !existingCountryCodeInHeaders){
	context.setVariable("request.header.Customer-Country-Code",customerCountryCode);
}

};