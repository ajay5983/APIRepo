populateErrorResponseVariables = function populateErrorResponseVariables() { // eslint-disable-line no-undef
	try {
		var transactionID = context.getVariable("vf.trace.transaction.id");
		if (transactionID) {
			transactionID = transactionID.replace(/[\\]/g, "\\\\").replace(/["]/g, "\\\"");
		}
		context.setVariable("transactionID", transactionID);
		var errorPayload = "";
		var reasonPhrase = "Internal Server Error";
		var description = "The authorization server encountered an unexpected condition that prevented it from fulfilling the request";
		var errMessage = "server_error";
		var statusCode = "500";

		var faultName = context.getVariable("fault.name");
		var errorJSON = context.getVariable("errorJSON");
		var httpStatusCode = context.getVariable("message.status.code");
		var errorId = "";
		var hypermediaStandard = context.getVariable("hypermedia_standard");
		var hypermediaValue = "";
		var requestParam = context.getVariable("request_param");
		var requestHeader = context.getVariable("request_header");

		if (hypermediaStandard === "a42") {
			hypermediaValue = hypermediaStandard + "_";
		}

		if (errorJSON && context.getVariable(errorJSON)) {
			errorPayload = JSON.parse(context.getVariable(errorJSON));

			reasonPhrase = errorPayload.reasonPhrase;

			if ((requestParam) && (errorJSON === "a42_generic_missing_request_parameter")) {
				description = errorPayload.errorDescription + " " + requestParam;
			} else if ((requestParam) && (errorJSON === "a42_generic_invalid_request_parameter")) {
				description = "The request parameter " + requestParam + " is invalid";
			} else if ((requestHeader) && (errorJSON === "a42_generic_missing_request_header")) {
				description = errorPayload.errorDescription + " " + requestHeader;
			} else if ((requestHeader) && (errorJSON === "a42_generic_invalid_request_header")) {
				description = "The request header " + requestHeader + " is invalid";
			} else {
				description = errorPayload.errorDescription;
			}

			errMessage = errorPayload.errorCode;
			statusCode = errorPayload.statusCode;

		} else if (faultName === "InvalidAPICallAsNoApiProductMatchFound") {
			errorId = hypermediaValue + "generic_unauthorized_app_for_api";
		} else if (faultName === "InvalidClientIdForGivenResource") {
			errorId = hypermediaValue + "oauth_scope_missing_invalid";
		} else if (faultName === "invalid_access_token") {
			errorId = hypermediaValue + "generic_invalid_access_token";
		} else if (faultName === "InvalidBasicAuthenticationSource") {
			errorId = hypermediaValue + "generic_invalid_authorization_header";
		} else if (faultName === "access_token_expired") {
			errorId = hypermediaValue + "generic_expired_access_token";
		} else if (faultName === "access_token_not_approved") {
			errorId = hypermediaValue + "generic_revoked_access_token";
		} else if (faultName === "SpikeArrestViolation") {
			errorId = hypermediaValue + "generic_spike_arrest_violation";
		} else if (faultName === "QuotaViolation") {
			errorId = hypermediaValue + "generic_quota_limit_reached";
		} else if (faultName === "JsonPathParsingFailure") {
			errorId = hypermediaValue + "generic_invalid_json_format";
		} else if (httpStatusCode === 502) {
			errorId = hypermediaValue + "generic_bad_gateway";
		} else if (httpStatusCode === 503) {
			errorId = hypermediaValue + "generic_service_unavailable";
		} else if (httpStatusCode === 504) {
			errorId = hypermediaValue + "generic_gateway_timeout";
		} else {
			errorId = hypermediaValue + "generic_internal_server_error";
		}

		if (errorId && context.getVariable(errorId)) {
			errorPayload = JSON.parse(context.getVariable(errorId));
			if (errorPayload) {
				reasonPhrase = errorPayload.reasonPhrase;
				description = errorPayload.errorDescription;
				errMessage = errorPayload.errorCode;
				statusCode = errorPayload.statusCode;
			}
		}

		context.setVariable("reasonPhrase", reasonPhrase);
		context.setVariable("description", description);
		context.setVariable("errMessage", errMessage);
		context.setVariable("statusCode", statusCode);

		var dateForFault = new Date().toISOString();
		context.setVariable("dateForFault", dateForFault);

	} catch (err) {
		throw err;
	}
};
