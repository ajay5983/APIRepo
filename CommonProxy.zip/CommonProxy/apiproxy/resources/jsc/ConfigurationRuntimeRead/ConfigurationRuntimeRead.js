configurationRuntimeRead = function configurationRuntimeRead(){ // eslint-disable-line no-undef
	try {
		var corsInfo = context.getVariable("cors_info");
		var countryWhitelisting = context.getVariable("country_whitelisting");

		var apiName = context.getVariable("api_name");
		var corsApiName = "CORS_".concat(apiName);

		var errorJSON;

		if (apiName) {
			if (corsInfo) {
				corsInfo = JSON.parse(corsInfo);
				if (corsInfo[corsApiName]) {
					if (corsInfo[corsApiName].CORS_ENABLED){
						context.setVariable("runtime_cors_access_enabled", corsInfo[corsApiName].CORS_ENABLED);
					}
					if (corsInfo[corsApiName].CORS_ALLOWED_ORIGINS){
						context.setVariable("runtime_cors_allowed_origins", corsInfo[corsApiName].CORS_ALLOWED_ORIGINS);
					}
					if (corsInfo[corsApiName].CORS_ALLOWED_HEADERS){
						context.setVariable("runtime_cors_allowed_headers", corsInfo[corsApiName].CORS_ALLOWED_HEADERS);
					}
					if (corsInfo[corsApiName].CORS_ALLOWED_METHODS){
						context.setVariable("runtime_cors_allowed_methods", corsInfo[corsApiName].CORS_ALLOWED_METHODS);
					}
					if (corsInfo[corsApiName].CORS_MAX_AGE){
						context.setVariable("runtime_cors_max_age", corsInfo[corsApiName].CORS_MAX_AGE);
					}
					context.removeVariable("cors_info");
				}
			}
			if (countryWhitelisting) {
				countryWhitelisting = JSON.parse(countryWhitelisting);
				if (countryWhitelisting[apiName]) {
					context.setVariable("runtime_whitelisting", JSON.stringify(countryWhitelisting[apiName]));
					context.removeVariable("country_whitelisting");
				} else {
					errorJSON = "a42_generic_internal_config_error";
					context.setVariable("errorJSON", errorJSON);
					throw "internalConfigError";
				}
			} else {
				errorJSON = "a42_generic_internal_config_error";
				context.setVariable("errorJSON", errorJSON);
				throw "internalConfigError";
			}

		} else {
			errorJSON = "a42_generic_internal_config_error";
			context.setVariable("errorJSON", errorJSON);
			throw "internalConfigError";
		}

	} catch (err){
		throw err;
	}
};
