AccessInHeadersFilter = function AccessInHeadersFilter()
{
	try
	{
		var validation_in_headers = context.getVariable('validation_in_headers');
		var HeaderList = context.getVariable('request.headers.names')+'';
		var errorJSON;
		
		if(validation_in_headers)
		{
			if(isJSON(validation_in_headers))
			{
			    validation_in_headers=JSON.parse(JSON.stringify(validation_in_headers).toLowerCase());
				if(HeaderList!='[]')
				{
					HeaderList = HeaderList.substr(1, HeaderList.length - 2);
					var HeaderListArray = HeaderList.split(',');
					for(i=0;i<HeaderListArray.length;i++){
						HeaderListArray[i] = HeaderListArray[i].trim();
					}

					for(i=0;i<HeaderListArray.length;i++)
					{
					   	var headerNameInLowerCase = HeaderListArray[i].toLowerCase();
						var validationHeaderobject = validation_in_headers[headerNameInLowerCase];

						if ( !validationHeaderobject) {
							context.removeVariable('request.header.'+ headerNameInLowerCase);
						}
						else {
						    context.setVariable("headerObject"+headerNameInLowerCase,JSON.stringify(validationHeaderobject));
							var isHeaderValidate = validationHeaderobject.validate;
							var headerValue = context.getVariable("request.header."+HeaderListArray[i]);
						
							if ( isHeaderValidate ) {
								var type = validationHeaderobject.type;

								if ( type ) {
                                    switch (type) {
                                    	case 'string':
                                    	    if( typeof headerValue !== 'string' ) {
                                    	    	context.setVariable('errorJSON','a42_generic_invalid_request_parameter');
		                                        throw "internalConfigError";
                                    	    }

                                    	case 'number':
                                    	    if( typeof headerValue !== 'number' ) {
                                    	    	context.setVariable('errorJSON','a42_generic_invalid_request_parameter');
		                                        throw "internalConfigError";
                                    	    }
                                    	    
										case 'dateTime':
                                    	   if (!isValidDateTimeFormat())
											 {
											 	  context.setVariable('errorJSON','a42_generic_invalid_request_header_date_format');
								                     throw "internalConfigError";
											 }
                                    }    
                                }
                                else {
								var formatSpecified = validationHeaderobject.format;
								var regex = typeFormatter(formatSpecified);
								if ( regex ){
									var result = regex.test(headerValue);
									if ( !result ) {
										context.setVariable('errorJSON','a42_generic_invalid_request_parameter');
							                throw "internalConfigError";
									}
								}
							}
							} 

						}
					}
				}
				
			}
			else{
					if(HeaderList!='[]')
					{
					   	validation_in_headers = validation_in_headers.toLowerCase();
						var validation_in_headersArray = validation_in_headers.split(',');
						validation_in_headersArray = validation_in_headersArray.map(function (el) {
				 		 return el.trim();
						}); 
						
						HeaderList = HeaderList.substr(1, HeaderList.length - 2);
						var HeaderListArray = HeaderList.split(',');
							
						for(i=0;i<HeaderListArray.length;i++)
						{
							var headerNameInLowerCase=HeaderListArray[i].trim().toLowerCase();

							if(validation_in_headersArray.indexOf(headerNameInLowerCase) == -1)
							{
								context.removeVariable('request.header.'+ headerNameInLowerCase);
							}
						}
					}
			}
		}
		else
		{
			errorJSON = 'a42_generic_internal_config_error';
			context.setVariable('errorJSON',errorJSON);
			throw 'internalConfigError';
		}
	}
	catch(err)
	{
		throw err;
	}
}

function isJSON(myStr){
    if(typeof(myStr) === 'string'){
        return false;
    }
    context.setVariable('isJson', true);
    return true;
} 

function isValidDateTimeFormat(dateTime) {
    var patt = new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(\.\d+)?(([+-]\d\d:\d\d)|Z)?$/i);
    return patt.test(dateTime);
}

escapeRegex = function(string) {
  return string.replace(/[-\/\\^$*+?.()|{}<>]/g, '\\$&')
};

function typeFormatter(formatSpecified)
{
	 switch(formatSpecified)
	{
		case 'EMAIL':
        var regex = new RegExp(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/);
		return regex;
	
		case 'DATE_TIME':
         var regex = new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(\.\d+)?(([+-]\d\d:\d\d)|Z)?$/i);
		return regex;

		case 'ACCEPT_HEADER':
        var regex = new RegExp(/^[ A-Za-z0-9*./;,=+]*$/);
		return regex;
		
		case 'ALPHA_NUMERIC':
         var regex = new RegExp(/^[A-Za-z0-9]*$/);
		return regex;
		
        case 'NUMERIC':
          var regex = new RegExp(/^[0-9]*$/);
		return regex;
		
		case 'COUNTRY_CODE':
		  var regex = new RegExp(/^[A-Z]{2}$/);
		return regex;
		  
	}
	
}
