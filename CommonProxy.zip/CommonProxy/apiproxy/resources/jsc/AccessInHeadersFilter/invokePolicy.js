try
{
	AccessInHeadersFilter();
}
catch(err)
{
	throw err;
}