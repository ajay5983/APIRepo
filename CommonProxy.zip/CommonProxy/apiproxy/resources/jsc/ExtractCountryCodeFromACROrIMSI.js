try
{
	var KvmConfig = context.getVariable("mcc_country_code_mapping");
	KvmConfig = JSON.parse(KvmConfig);
	var acr = context.getVariable("acr");
	var imsi = context.getVariable("imsi");
	var errorJSON;
	
	if (acr)
	{
	    var acrMCC = acr.substring(0,3);
	    countryISO = KvmConfig[acrMCC];
		context.setVariable("countryISO",countryISO);
	}
	else if (imsi)
	{
		if(imsi.length > 15 || isNaN(imsi))
		{
			errorJSON = "a42_generic_invalid_request_parameter";
			context.setVariable("errorJSON",errorJSON);
			context.setVariable("request_param","IMSI");
			throw "invalidParamException";
		}
		else
		{
			var	imsiMCC = imsi.substring(0,3);
			countryISO = KvmConfig[imsiMCC];
			context.setVariable("countryISO",countryISO);
		}
	}
	else
	{
	    context.setVariable("errorJSON","a42_generic_country_not_supported");
	}
}
catch (err)
{
	if(errorJSON)
	{
		throw errorJSON;
	}
	else
	{
		context.setVariable("errorJSON","a42_generic_internal_config_error");
	}
}