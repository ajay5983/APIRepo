queryParamForUserInfo = function queryParamForUserInfo(){ // eslint-disable-line no-undef
var sub = context.getVariable("accesstoken.sub");
//var apixAppID = context.getVariable("request.header.Apix-App-Id");
var iotBackendPassword = context.getVariable("IoT-Backend-Password");
var scope = context.getVariable("accesstoken.scopeFromRequest");
var whitelisted = context.getVariable("accesstoken.whitelisted");
var userInfoEncrypt =context.getVariable("UserInfoEncrypt");
var internalUserInfo = context.getVariable("internalUserInfo");

var getUserIfnoQuery = "/"+sub+"?"+"scope="+scope+"&app-id="+iotBackendPassword+"&whitelisted="+whitelisted+"&encryption="+userInfoEncrypt;

context.setVariable("userInfoCalloutTargetPath",getUserIfnoQuery);
};