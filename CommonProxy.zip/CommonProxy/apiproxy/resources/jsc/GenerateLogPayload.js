

var headers = null;
var inboundRequestUri = context.getVariable("proxy.url");
var verb = context.getVariable("request.verb");

var payload = null;
var flow = context.flow;
var timestamp = context.getVariable('system.time');
var customVariables = context.getVariable('customVariables');
var errorMessage = null;
var responseHeaders = "";
var apiName = context.getVariable('apiproxy.name');
var orgName = context.getVariable('organization.name');
var envName = context.getVariable('environment.name');
var flowName = context.getVariable('current.flow.name');

var messageProcessorUUID = context.getVariable('system.uuid');
var usecaseId= context.getVariable('request.header.x-vf-ext-bp-id');
var msisdn =  context.getVariable('msisdn') || context.getVariable('msisdnInCache');
var countryCode = context.getVariable('countryCode');

var apiRateLimit = context.getVariable('apiproduct.developer.quota.limit') || context.getVariable('limit');
 
context.getVariable('loadbalancing.targetserver');
context.getVariable('target.ip');
context.getVariable('target.port');
context.getVariable('targetserver.name');

var maskedPayload = context.getVariable('maskedPayload');
//IMPORTANT:Remove the maskedPayload from context after caching it into a local variable.
context.removeVariable('maskedPayload');

var headersToMask =  context.getVariable('headersToMask');


var oauthTokenDetails =  context.getVariable("oauthTokenDetails");
var oauthMsisdn = null;
var oauthApiRateLimit = null;
var oauthCallerApp = null;
var oauthClientId = null;
var oauthApiProduct = null;
var oauthCallerId = null;
if (oauthTokenDetails) {
	try {
		oauthTokenDetails = JSON.parse(oauthTokenDetails);
		oauthMsisdn = oauthTokenDetails.Msisdn;
		oauthApiRateLimit = oauthTokenDetails.limit;
		oauthCallerApp = oauthTokenDetails.appName;
		oauthClientId = oauthTokenDetails.ClientId;
		oauthApiProduct = oauthTokenDetails.Scopes;
		oauthCallerId = oauthTokenDetails.callerID;
	} catch (err) {
	}
}


var transactionId = getTranscationID();

 logData = {
	"transaction-id" : transactionId,
	"timestamp" : getTimeStamp(),
	"component" : "APIX",
	"server-name" : orgName,
    "service" : apiName,
	"env-name" : envName,
    "inbound-request-uri" : inboundRequestUri,
	"service-flow" :  flowName,
	"flow" : flow,
    "message-processor-uuid" : messageProcessorUUID,
    "api-rate-limit" : apiRateLimit || oauthApiRateLimit
 }

	logData["api-product"]= context.getVariable("apiproduct.name") || oauthApiProduct;
    logData["caller-id"]= context.getVariable("developer.email") || oauthCallerId;
	logData["caller-app"]= context.getVariable("developer.app.name") || oauthCallerApp;
	logData["caller-apikey"]= context.getVariable("client_id") || oauthClientId;
    logData["usecase-id"]= usecaseId;
    logData["msisdn"]= msisdn || oauthMsisdn;
    logData["country-code"]= countryCode; 
    logData["customVariables"]= customVariables; 
    logData["error"]= null; 
    logData["error-code"]= null; 
    
 
switch (flow) {
case "PROXY_REQ_FLOW":
   
    logData["logpoint"]= "request-in";
    headers= JSON.parse(JSON.stringify(context.proxyRequest.headers));
	logData["payload"]= maskedPayload || context.getVariable("request.content");
    logData["status-code"]= null;
    logData["status"]= null;          
	logData["external-trace-id"]= context.getVariable("request.header.x-vf-ext-trace-id");
	logData["external-reference-id"]= context.getVariable("request.header.x-vf-ext-reference-id");
	break;
	
case "PROXY_RESP_FLOW":
    
    logData["logpoint"]= "response-out";
	headers= JSON.parse(JSON.stringify(context.proxyResponse.headers));
	logData["payload"]= maskedPayload ||  context.getVariable("response.content");
    logData["status-code"]= context.getVariable("response.status.code");
    logData["status"]= getStatus(context.getVariable("response.status.code"), context.getVariable("response.reason.phrase"));
    context.setVariable("message.header.x-vf-trace-transaction-id", context.getVariable("request.header.x-vf-trace-transaction-id") || transactionId);
    break;
	
case "TARGET_REQ_FLOW":
        
    context.setVariable("request.header.x-vf-trace-transaction-id", context.getVariable("request.header.x-vf-trace-transaction-id") || transactionId);
	logData["logpoint"]= "request-out";
    headers= JSON.parse(JSON.stringify(context.targetRequest.headers));
	logData["payload"]= maskedPayload ||  context.getVariable("request.content");
    logData["status-code"]= null;
    logData["status"]= null;        
	break;
	
  case "TARGET_RESP_FLOW":
    
    logData["logpoint"]= "response-in";
    headers= JSON.parse(JSON.stringify(context.targetResponse.headers));
	logData["payload"]=  maskedPayload || context.getVariable("response.content");
    logData["status-code"]= context.getVariable("response.status.code");
    logData["status"]= getStatus(context.getVariable("response.status.code"), context.getVariable("response.reason.phrase"));        
    logData["outbound-url"]= context.getVariable("target.scheme")+"://"+context.getVariable("target.host") + ":" + context.getVariable("target.port") + context.getVariable("request.uri");
    break;
	
case "ERROR":
	
    logData["logpoint"]= "response-out";
    headers= JSON.parse(JSON.stringify(context.error.headers));
	logData["payload"]= maskedPayload ||  context.getVariable("message.content");
    logData["status"]= getStatus(context.getVariable("message.status.code"), context.getVariable("message.reason.phrase"));
    logData["status-code"]= context.getVariable("message.status.code");
    logData["error"]= context.getVariable("message.reason.phrase");
    logData["error-code"]= context.getVariable("message.status.code");
    if (context.getVariable("target.scheme") && context.getVariable("target.host") && context.getVariable("request.uri"))
    logData["outbound-url"]= context.getVariable("target.scheme")+"://"+context.getVariable("target.host") + ":" + context.getVariable("target.port") + context.getVariable("request.uri");
    else 
    logData["outbound-url"]= null;
    break;

}
 if (logData["payload"]){
       logData["message-size"]= logData["payload"].length;
 }else {
     logData["message-size"]= 0;
 }
 
 if(headersToMask && headers){
	 logData["headers"] = maskHeaders(headersToMask, headers);
 }else{
	 logData["headers"] = headers;
 }
 
context.setVariable("logData", JSON.stringify(logData));

function addAttrbuteToLogPayload(key, value){
  if(key && value) {
  logData[key] = value;
  }
}

function maskHeaders(headersToMask, headers){
	headersToMask = headersToMask.toLowerCase();
	headersList= headersToMask.split(",");
	for(var i in headers){
		if(i && headersList.indexOf(i.toLowerCase()) > -1 ){
			headers[i] = "***";
		}
	}
	return headers;
};


function generateUUID(){
    var d = new Date().getTime();
    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = (d + Math.random()*16)%16 | 0;
        d = Math.floor(d/16);
        return (c=='x' ? r : (r&0x7|0x8)).toString(16);
    });
    return uuid;
};

function getStatus(statusCode, reasonPhrase) {
	var status = null;
	if (statusCode && reasonPhrase) {
		statusCode = statusCode.toString();
		if ((reasonPhrase.toLowerCase()).indexOf("timeout") > -1) {
			status = "timeout";
		} else if ((statusCode.charAt(0) === "1"
				|| statusCode.charAt(0) === "2" || statusCode.charAt(0) === "3")) {
			status = "ok";
		} else {
			status = "error";
		    logData["error"]= context.getVariable("message.reason.phrase");
		    logData["error-code"]= context.getVariable("message.status.code");
		}

	}
	return status;
};



function getTimeStamp(){

var d=new Date();
var n=d.toTimeString();     
var timezone = "+";

n = d.getTimezoneOffset()+"";
if (n > 0){
  timezone = "-"
}
n = n.substring(1);
var hours =  ("00"+(n / 60)).slice(-2) ;
var minutes = ("00"+(n % 60)).slice(-2);
timezone +=  hours+":"+minutes;

  return ("00"+(context.getVariable("system.time.year"))).slice(-4) + "-"
  +   ("00"+(context.getVariable("system.time.month"))).slice(-2) + "-"
  +   ("00"+(context.getVariable("system.time.day"))).slice(-2) + "T"
  +   ("00"+(context.getVariable("system.time.hour"))).slice(-2) + ":"
  +   ("00"+(context.getVariable("system.time.minute"))).slice(-2) + ":"
  +   ("00"+(context.getVariable("system.time.second"))).slice(-2) + ","
  +   ("00"+(context.getVariable("system.time.millisecond"))).slice(-3) 
  + timezone;
}


function getTranscationID(){
var transactionId = context.getVariable("requestUUIDToLog");
if (!transactionId) {
     transactionId = context.getVariable("request.header.x-vf-trace-transaction-id");
	 if (!transactionId)  
		transactionId = generateUUID();
     context.setVariable("requestUUIDToLog", transactionId);
}  
return transactionId;
}
