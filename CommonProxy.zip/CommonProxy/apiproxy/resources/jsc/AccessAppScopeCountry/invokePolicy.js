try
{
	AccessAppScopeCountry();
}

catch(err)
{
	throw err;
}