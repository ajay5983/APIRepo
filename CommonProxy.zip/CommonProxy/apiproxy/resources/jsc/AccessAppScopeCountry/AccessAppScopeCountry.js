AccessAppScopeCountry =  function AccessAppScopeCountry() {
try
{
	var country = context.getVariable('countryISO');
	var scope = context.getVariable('valid_scopes');
	
	var errorJSON;
	var exceptionName = '';
	var ScopeFlag = false;
	var CountryFlag = false;

	var access_scope_country_config = context.getVariable('access_scope_country_config');

	if(access_scope_country_config)
	{
		if(country && scope)
		{
			var scopeArray = scope.split(' ');
			
			access_scope_country_config = JSON.parse(access_scope_country_config);
			for(i=0;i<scopeArray.length;i++)
			{
				if(typeof(access_scope_country_config[scopeArray[i]]) != 'undefined')
				{
					ScopeFlag=true;
					var activeScopeConfig = access_scope_country_config[scopeArray[i]];
						
					if(activeScopeConfig.indexOf(country) != -1)
					{
						CountryFlag=true;
						break;
					}
				}
			}

			if(!ScopeFlag)
			{
				errorJSON = 'a42_generic_internal_config_error';
				context.setVariable('errorJSON',errorJSON);
				exceptionName = 'internalConfigError';
				throw exceptionName;
			}
			
			if(!CountryFlag)
			{
				errorJSON = 'a42_generic_invalid_country_id';
				context.setVariable('errorJSON',errorJSON);
				exceptionName = 'invalidCountryError';
				throw exceptionName;
			}
		}
		else
		{
			errorJSON = 'a42_generic_internal_config_error';
			context.setVariable('errorJSON',errorJSON);
			exceptionName = 'internalConfigError';
			throw exceptionName;
		}
	}
}
catch(err)
{
	if(!errorJSON)
	{
		context.setVariable('errorJSON','a42_generic_internal_server_error');
		throw err;
	}
	else
	{
		throw exceptionName;
	}
}
}