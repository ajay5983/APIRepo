try {
	var error_payload = "";
	var reasonPhrase = "Internal Server Error";
	var description = "The authorization sever encountered an unexpected condition that prevented it from full filling the request";
	var errMessage = "server_error";
	var statusCode = "500";

	var faultName = context.getVariable('fault.name');
	var errorJSON = context.getVariable('errorJSON');
	var error_ID = '';
	var hypermedia_standard = context.getVariable('hypermedia_standard');
	var hypermediaValue = '';

	if (hypermedia_standard == "a42") {
		hypermediaValue = hypermedia_standard + '_';
	}

	if (errorJSON) {
		error_payload = JSON.parse(context.getVariable(errorJSON));

		reasonPhrase = error_payload.reasonPhrase;
		description = error_payload.errorDescription;
		errMessage = error_payload.errorCode;
		statusCode = error_payload.statusCode;

	} else if (faultName == "InvalidAPICallAsNoApiProductMatchFound") {
		error_ID = hypermediaValue + "oauth_unauthorized_client";
	} else if (faultName == "InvalidClientIdForGivenResource") {
		error_ID = hypermediaValue + "oauth_scope_missing_invalid";
	} else if (faultName == "invalid_access_token") {
		error_ID = hypermediaValue + "generic_invalid_access_token";
	} else if (faultName == "InvalidBasicAuthenticationSource") {
		error_ID = hypermediaValue + "generic_invalid_authorization_header";
	} else if (faultName == "access_token_expired") {
		error_ID = hypermediaValue + "generic_expired_access_token";
	} else if (faultName == "access_token_not_approved") {
		error_ID = hypermediaValue + "generic_revoked_access_token";
	} else if (faultName == "SpikeArrestViolation") {
		error_ID = hypermediaValue + "generic_spike_arrest_violation";
	} else if (faultName == "QuotaViolation") {
		error_ID = hypermediaValue + "generic_quota_limit_reached";
	} else if (faultName == "JsonPathParsingFailure") {
		error_ID = hypermediaValue + "generic_invalid_json_format";
	} else {
		error_ID = hypermediaValue + "generic_internal_server_error";
	}

	if (error_ID) {
		error_payload = JSON.parse(context.getVariable(error_ID));
		if (error_payload) {
			reasonPhrase = error_payload.reasonPhrase;
			description = error_payload.errorDescription;
			errMessage = error_payload.errorCode;
			statusCode = error_payload.statusCode;
		}
	}

	context.setVariable('reasonPhrase', reasonPhrase);
	context.setVariable('description', description);
	context.setVariable('errMessage', errMessage);
	context.setVariable('statusCode', statusCode);

	var dateForFault = new Date().toISOString();
	context.setVariable("dateForFault", dateForFault);

} catch (err) {
	throw err;
}