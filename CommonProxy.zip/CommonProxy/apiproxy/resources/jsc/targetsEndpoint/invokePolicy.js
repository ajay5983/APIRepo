try{
	targetsEndpoint();
}

catch(err){
	throw err;
}