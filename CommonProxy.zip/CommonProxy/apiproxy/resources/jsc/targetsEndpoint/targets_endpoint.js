targetsEndpoint = function targetsEndpoint(){
	try {
		var target = context.getVariable("targets_endpoint_properties");
		var pathSuffix = context.getVariable("proxy.pathsuffix");
		var defaultTarget = context.getVariable("defaultTarget");
		var backendURIPath = context.getVariable("backendURIPath");
		var inputTarget = context.getVariable('request.header.x-vf-target-env');
		var inputTargetStub = context.getVariable('request.header.x-vf-target-stub');
		context.setVariable("target.copy.pathsuffix", false);
		var isTargetError = false;
		var isDefTargetError = false;
		var isMultipleTargetError = false;
		var targetName = "";
		var targetURL = "";
		var protocol = 'http';

		if (!target)
			isTargetError = true;
		else {
			if((inputTargetStub == "true") && (inputTarget)){
				isMultipleTargetError = true;
			}else if((inputTargetStub == "true") && (!inputTarget)){
				targetName = "target-stub";
			}else if((inputTargetStub == "false") || (!inputTargetStub)){
				if(inputTarget == null || inputTarget == ""){
					if(defaultTarget){
						targetName = defaultTarget;
					}else{
						targetName = "smart-routing_target-env-default";
						if (!target[targetName]){
							isDefTargetError = true;
						}
					}
				}else{
					targetName = "smart-routing_"+inputTarget;
				}
			}
		}
		
		if ((!isTargetError) && (!isDefTargetError) && (!isMultipleTargetError)) {

			try {

				target = JSON.parse(target);
				var sslEnabled = target[targetName].TARGET_SSL_ENABLED;
				if (sslEnabled == true) {
					protocol = 'https';
				}

				if (target[targetName] && target[targetName].TARGET_HOST) {
				
						if(target[targetName].TARGET_BASEPATH){
						targetURL = protocol + '://'
								+ target[targetName].TARGET_HOST + ':'
								+ target[targetName].TARGET_PORT + target[targetName].TARGET_BASEPATH + backendURIPath;
						}else{
							targetURL = protocol + '://'
								+ target[targetName].TARGET_HOST + ':'
								+ target[targetName].TARGET_PORT + backendURIPath;
						}

					context.setVariable("target.url", targetURL);
					context.setVariable("ROUTING.target.host",
							target[targetName].TARGET_HOST);
					context.setVariable("ROUTING.target.port",
							target[targetName].TARGET_PORT);
					context.setVariable("ROUTING.target.enabled",
							target[targetName].TARGET_ENABLED);
					context.setVariable("ROUTING.ssl.ciphers",
							target[targetName].TARGET_SSL_CIPHERS);
					context.setVariable("ROUTING.target_ssl_enabled",
							target[targetName].TARGET_SSL_ENABLED);
					context.setVariable("ROUTING.target_ssl.client.auth.enabled",
							target[targetName].TARGET_SSL_CLIENT_AUTH_ENABLED);
					context.setVariable("ROUTING.target.ssl.key.store",
							target[targetName].TARGET_SSL_KEY_STORE);
					context.setVariable("ROUTING.target.ssl.key.alias",
							target[targetName].TARGET_SSL_KEY_ALIAS);
					context.setVariable("ROUTING.target.ssl.trust.store",
							target[targetName].TARGET_SSL_TRUST_STORE);
					context.setVariable("ROUTING.ssl.protocols",
							target[targetName].TARGET_SSL_PROTOCOLS);
					context.setVariable("ROUTING.ssl.ignore.validation.errors",
							target[targetName].TARGET_SSL_IGNORE_VALIDATION_ERRORS);
				}
				if (targetURL == "")
					isTargetError = true;
			} catch (e) {
				isTargetError = true;
			}
		}

		context.setVariable("isTargetError", isTargetError);
		context.setVariable("isDefTargetError", isDefTargetError);
		context.setVariable("isMultipleTargetError", isMultipleTargetError);

		if (isTargetError) {
			context.setVariable("errorJSON", "a42_generic_invalid_target_header");
			throw isTargetError;
		}else if (isDefTargetError) {
			context.setVariable("errorJSON", "a42_generic_invalid_target_header");
			throw isDefTargetError;
		}else if (isMultipleTargetError) {
			context.setVariable("errorJSON", "a42_generic_missing_request_header");
			throw isMultipleTargetError;
		}
	} catch (err) {
		throw err;
	}
}