function ProcessCountryQuota(){
try
{
	var opCoInRequest = context.getVariable('countryISO');
	var errorJSON;
	if(opCoInRequest)
	{
		var country_throttling_quota_resource_enabled = context.getVariable(opCoInRequest + '_throttling_quota_resource_enabled');
		var country_throttling_quota_resource_count = context.getVariable(opCoInRequest + '_throttling_quota_resource_count');
		
		if(country_throttling_quota_resource_enabled && country_throttling_quota_resource_count && !(isNaN(country_throttling_quota_resource_count)))
		{
			context.setVariable('throttling_quota_country_1min_enabled',country_throttling_quota_resource_enabled);
			context.setVariable('throttling_quota_country_1min_count',country_throttling_quota_resource_count);
		}
		else
		{
			errorJSON = 'a42_generic_internal_config_error';
			context.setVariable('errorJSON',errorJSON);
			throw 'internalConfigError';
		}
	}
	else
	{
		errorJSON = 'a42_generic_internal_config_error';
		context.setVariable('errorJSON',errorJSON);
		throw 'internalConfigError';
	}
}
catch(err){
    if(!errorJSON)
    {
        context.setVariable('errorJSON','a42_generic_internal_config_error');
        throw err;
    }
    else
    {
        throw 'internalConfigError';
    }
}
}