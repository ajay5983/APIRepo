var customizedErrorMessage='';

try {
		customizedErrorMessage={
				"statusCode": "501",
				"reasonPhrase": "Not Implemented", 
				"errorCode": "server_error", 
				"errorDescription": "No CSM endpoint configured for given OpCo"
				};
}
catch (err){	
	context.setVariable("errorJSON", 'customizedErrorMessage');
	context.setVariable("customizedErrorMessage", JSON.stringify(customizedErrorMessage));
	throw "Not Implemented";
}