try
{
	var api_name = context.getVariable('apiproxy.name').toLowerCase();
	
	if(api_name.indexOf("internal") == -1)
	{
		context.setVariable('api_category','External');
	}
	else
	{
		context.setVariable('api_category','Internal');
	}
}

catch(err)
{
	context.setVariable('errorJSON','a42_generic_internal_server_error');
	throw err;
}