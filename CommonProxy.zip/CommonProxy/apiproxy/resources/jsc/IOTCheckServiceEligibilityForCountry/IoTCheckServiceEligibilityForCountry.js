checkServiceEligibiltyForCountry = function checkServiceEligibiltyForCountry(){ // eslint-disable-line no-undef
var serviceEligibilityConfiguration = context.getVariable("ServiceEligibilityConfiguration");
var isConfigError =  false;
var country = context.getVariable("accesstoken.Customer-Country-Code");

if(!country){
	country = context.getVariable("msisdnCountry");
}

var isServiceEligibilityRequired = false;

try{
	serviceEligibilityConfiguration = JSON.parse(serviceEligibilityConfiguration);
}catch(err){
	isConfigError = true;
}

if(!isConfigError){
	if(serviceEligibilityConfiguration[country]){
		var serviceEligibilityConfig = serviceEligibilityConfiguration[country].split(",");
		if(serviceEligibilityConfig.length > 0){
			isServiceEligibilityRequired = true;
		}
	}
}

if(isServiceEligibilityRequired){
	var sub = context.getVariable("accesstoken.sub");
	var apixAppID = context.getVariable("developer.app.id");
	var scope = context.getVariable("accesstoken.scopeFromRequest");
	var whitelisted = context.getVariable("accesstoken.whitelisted");

	var serviceEligibilityCheckUserInfoCalloutTargetPath = "/"+sub+"?"+"scope="+scope+"&app-id="+apixAppID+"&whitelisted="+whitelisted;

	context.setVariable("serviceEligibilityCheckUserInfoCalloutTargetPath",serviceEligibilityCheckUserInfoCalloutTargetPath);
}
	
context.setVariable("isServiceEligibilityRequired" , isServiceEligibilityRequired);
context.setVariable("serviceEligibilityRequirements" , serviceEligibilityConfiguration[country]);
}
