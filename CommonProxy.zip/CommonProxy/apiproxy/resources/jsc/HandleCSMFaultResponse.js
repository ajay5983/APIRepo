//Extract common error variables for Business and Technical errors

var failureCode = context.getVariable("failureCode");
var err = context.getVariable("errorCode");
var msg = context.getVariable("errorMessage");
var errorName = context.getVariable("Name");
var faultcode=context.getVariable("faultCode");
var transId = context.getVariable("transId");
var customizedErrorMessage='';

if(err === null){
	err="";
}

if(msg===null) {
	msg="";
}


if (errorName===null) {
    errorName="";
}


//Extract faultCode for tech errors

var desc = errorName +" - "+msg+" (" +err+ ")";



//Technical error handling
if (faultcode!==null)
{
	if (faultcode.toLowerCase().indexOf("client")!=-1)
	{
            customizedErrorMessage={
			"statusCode": "400",
			"reasonPhrase": "Bad Request", 
			"errorCode": "client_error", 
			"errorDescription": "Bad Request"
			};
	
	context.setVariable("errorJSON", 'customizedErrorMessage');
	context.setVariable("customizedErrorMessage", JSON.stringify(customizedErrorMessage));
	throw "Bad Request";
	}
	else if (faultcode.toLowerCase().indexOf("server")!=-1)
	{
		if (failureCode==602)
		{
			 
			statusCode="500";
			reasonPhrase="Internal Server Error";
			errorCode= "multiple_subscriptions";
			errorDescription="Multiple subscriptions found.";
			

			
		}
		else
		{
			
			statusCode= "500",
			reasonPhrase= "Internal Server Error", 
			errorCode= "server_error", 
			errorDescription= "Internal Server Error"
			
		}
			
    }
}

//Business error handling
if (faultcode===null)
{
if (err!=="" && err!=="000")
{
           
			statusCode= "400",
			reasonPhrase= "Bad Request", 
			errorCode= "server_error", 
			errorDescription= "Bad Request"
			
}
}

	context.setVariable("statusCode",statusCode);
	context.setVariable("reasonPhrase", reasonPhrase);
	context.setVariable("errorCode", errorCode);
	context.setVariable("errorDescription", errorDescription);

