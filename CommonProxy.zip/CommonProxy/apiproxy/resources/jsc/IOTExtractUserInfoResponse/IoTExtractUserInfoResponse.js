extractUserInfoResponse = function extractUserInfoResponse(){ // eslint-disable-line no-undef
	
var userInfoResponse = context.getVariable("IoTUserInfoCalloutResponse.content");
var statusCode = context.getVariable("IoTUserInfoCalloutResponse.status.code");
var statusReasonPhrase=context.getVariable("IoTUserInfoCalloutResponse.reason.phrase");
var CacheControl = context.getVariable("IoTUserInfoCalloutResponse.header.Cache-Control");
var Pragma = context.getVariable("IoTUserInfoCalloutResponse.header.Pragma");
var customizedErrorMessage='';

var responseData= JSON.parse(userInfoResponse);
if (statusCode != "200"){
	customizedErrorMessage={
			"statusCode": statusCode,
			"reasonPhrase": statusReasonPhrase, 
			"errorCode": responseData.error, 
			"errorDescription": responseData.error_description,
			};
			context.setVariable("errorJSON", 'customizedErrorMessage');
			context.setVariable("customizedErrorMessage", JSON.stringify(customizedErrorMessage));
			throw "InternalUserInforError";	
}
	
else {
	if(responseData.jwe){
		context.setVariable("userInfoJWEToken",responseData.jwe);
	}else{
		context.setVariable("userInfoJWEToken",userInfoResponse);
	}
}

};