//parses the JSON object from the first step and checks the enabled flag  THROTTLING_QUOTA_1MIN_ENABLED

var throttlingQuota = context.getVariable("throttling.quota");
var quota = '';
var isEnabled = false;
var quotaRate = '';
try{
	throttling_Quota = JSON.parse(throttlingQuota);
	isEnabled = throttling_Quota.THROTTLING_QUOTA_1MIN.THROTTLING_QUOTA_1MIN_ENABLED;
	quotaRate = throttling_Quota.THROTTLING_QUOTA_1MIN.THROTTLING_QUOTA_1MIN_COUNT;
	context.setVariable("throttlingQuota1minEnabled",isEnabled);
	if(isEnabled){
		context.setVariable("throttlingQuota1minCount",quotaRate);
	}
}
catch(error){
}