buildTargetUrl = function buildTargetUrl() { // eslint-disable-line no-undef
	var target = context.getVariable("environment_targets_endpoint_properties");
	var targetpathsuffix = context.getVariable("proxy.pathsuffix");
	var enviromentTarget = context.getVariable("request.header.vf-target-environment");
	var enviromentName = context.getVariable("environment.name");
	var envTargetValidEnviroment = context.getVariable("env_target_valid_enviroment");
	var requestQuery = context.getVariable("request.querystring");
	var country = context.getVariable("countryISO");
	var flowName = context.getVariable("currentFlowName");
	var defaultTarget = "defaultTarget" + country;
	defaultTarget = context.getVariable(defaultTarget);

	var isTargetError = false;
	var isEnvTargetError = false;

	var targetName = "";
	var targetURL = "";
	var protocol = "http";

	envTargetValidEnviroment = envTargetValidEnviroment.split(",");

	if (enviromentTarget && envTargetValidEnviroment.indexOf(enviromentName.trim()) > -1) {
		if (!target) {
			isEnvTargetError = true;
		} else {
			try {
				target = JSON.parse(target);

				if (!target[enviromentTarget]) {
					isEnvTargetError = true;
				}

			} catch (err) {
				isEnvTargetError = true;
			}
		}

		if (!isEnvTargetError) {
			targetName = enviromentTarget;
			target = target[targetName][flowName];
		}
	} else if (!target) {
		isTargetError = true;
	} else {
		targetName = defaultTarget;
		try {
			target = JSON.parse(target);
			target = target[targetName][flowName];
		} catch (err) {
			isTargetError = true;
		}
	}

	if (!isTargetError && !isEnvTargetError) {

		try {

			var sslEnabled = target.TARGET_SSL_ENABLED;
			if (sslEnabled === true) {
				protocol = "https";
			}

			if (target && target.TARGET_HOST) {
				targetURL = protocol + "://" + target.TARGET_HOST + ":"
				+ target.TARGET_PORT + target.TARGET_PATH + targetpathsuffix;

				if (requestQuery) {
					targetURL = targetURL + "?" + requestQuery;
				}

				context.setVariable("target.url", targetURL);
				context.setVariable("ROUTING.target.host",
					target.TARGET_HOST);
				context.setVariable("ROUTING.target.port",
					target.TARGET_PORT);
				context.setVariable("ROUTING.target.enabled",
					target.TARGET_ENABLED);
				context.setVariable("ROUTING.ssl.ciphers",
					target.TARGET_SSL_CIPHERS);
				context.setVariable("ROUTING.target_ssl_enabled",
					target.TARGET_SSL_ENABLED);
				context.setVariable("ROUTING.target_ssl.client.auth.enabled",
					target.TARGET_SSL_CLIENT_AUTH_ENABLED);
				context.setVariable("ROUTING.target.ssl.key.store",
					target.TARGET_SSL_KEY_STORE);
				context.setVariable("ROUTING.target.ssl.key.alias",
					target.TARGET_SSL_KEY_ALIAS);
				context.setVariable("ROUTING.target.ssl.trust.store",
					target.TARGET_SSL_TRUST_STORE);
				context.setVariable("ROUTING.ssl.protocols",
					target.TARGET_SSL_PROTOCOLS);
				context.setVariable("ROUTING.ssl.ignore.validation.errors",
					target.TARGET_SSL_IGNORE_VALIDATION_ERRORS);
			}
			if (targetURL === "") {
				isTargetError = true;
			}
		} catch (e) {
			isTargetError = true;
		}
	}

	context.setVariable("isTargetError", isTargetError);

	if (isTargetError) {
		context.setVariable("errorJSON", "a42_generic_internal_config_error");
		throw isTargetError;
	}

	if (isEnvTargetError) {
		context.setVariable("errorJSON", "a42_generic_invalid_target_header");
		throw isEnvTargetError;
	}
};