try
{   
    var IncomingMethodArray = '';
	var IncomingOrigin = context.getVariable('request.header.Origin');
	var IncomingHeaders = context.getVariable('request.header.Access-Control-Request-Headers.values')+'';
	var IncomingMethod = context.getVariable('request.header.Access-Control-Request-Method.values')+'';

	var network_cors_allowed_origins = context.getVariable('network_cors_allowed_origins');
	var network_cors_allowed_headers = context.getVariable('network_cors_allowed_headers');
	var network_cors_allowed_methods = context.getVariable('network_cors_allowed_methods');
	var network_cors_max_age = context.getVariable('network_cors_max_age');
	var HeadersFlag=true;
	var MethodFlag=true;
	
	if(IncomingHeaders!='[]')
	{
        IncomingHeaders = IncomingHeaders.substr(1, IncomingHeaders.length - 2).toLowerCase();
	    var IncomingHeadersArray = IncomingHeaders.split(", ");
		for(i=0;i<IncomingHeadersArray.length;i++)
		{
			if(network_cors_allowed_headers.indexOf(IncomingHeadersArray[i]) == -1)
			{
				HeadersFlag=false;
				break;
			}
		}
	}
	
	if(IncomingMethod!='[]')
	{
	    IncomingMethod = IncomingMethod.substr(1, IncomingMethod.length - 2).toUpperCase();
		var IncomingMethodArray = IncomingMethod.split(', ');
		for(j=0;j<IncomingMethodArray.length;j++)
		{
		    context.setVariable("IncomingMethod"+j,IncomingMethodArray[j]);
		    context.setVariable("result"+j,network_cors_allowed_methods.indexOf(IncomingMethodArray[j]) == -1);
			if(network_cors_allowed_methods.indexOf(IncomingMethodArray[j]) == -1)
			{
				MethodFlag=false;
				break;
			}
		}
	}
	
	if(IncomingOrigin && IncomingHeaders!='[]' && IncomingMethod!='[]')
	{
		IncomingOrigin = IncomingOrigin.toLowerCase();
		if((network_cors_allowed_origins.indexOf(IncomingOrigin) != -1) && HeadersFlag==true && MethodFlag==true)
		{
			context.setVariable('message.header.Access-Control-Allow-Credentials','true');
			context.setVariable('message.header.Access-Control-Allow-Headers',network_cors_allowed_headers.toString());
			context.setVariable('message.header.Access-Control-Allow-Origin',IncomingOrigin);
			context.setVariable('message.header.Access-Control-Allow-Methods',network_cors_allowed_methods.toString());
			context.setVariable('message.header.Access-Control-Expose-Headers',network_cors_allowed_headers.toString());
			context.setVariable('message.header.Access-Control-Max-Age',network_cors_max_age);
		}
	}
}
catch(err){

	throw err;
}