var customizedErrorMessage='';

try {
		customizedErrorMessage={
				"statusCode": "500",
				"reasonPhrase": "Internal Server Error", 
				"errorCode": "server_error", 
				"errorDescription": "The server encountered an unexpected condition while processing your request. Please get in touch with APIX Support."
				};
}
catch (err){	
	context.setVariable("errorJSON", 'customizedErrorMessage');
	context.setVariable("customizedErrorMessage", JSON.stringify(customizedErrorMessage));
	throw "Internal Server Error";
}