AccessOutHeadersFilter = function AccessOutHeadersFilter()
{
	try
	{
		var validation_out_headers = context.getVariable('validation_out_headers');
		var HeaderList = context.getVariable('response.headers.names')+'';
		var errorJSON;
		
		if(validation_out_headers)
		{
			if(HeaderList!='[]')
			{
				validation_out_headers = validation_out_headers.toLowerCase();
				var validation_out_headersArray = validation_out_headers.split(',');
				
				validation_out_headersArray = validation_out_headersArray.map(function (el) {
				 return el.trim();
				}); 

				HeaderList = HeaderList.substr(1, HeaderList.length - 2);
				var HeaderListArray = HeaderList.split(',');

				for(i=0;i<HeaderListArray.length;i++)
				{
					var headerNameInLowerCase=HeaderListArray[i].trim().toLowerCase(); 

					if(validation_out_headersArray.indexOf(headerNameInLowerCase) == -1)
					{	
						context.removeVariable('response.header.'+headerNameInLowerCase);
					}
				}
			}
		}
		else
		{
			errorJSON = 'a42_generic_internal_config_error';
			context.setVariable('errorJSON',errorJSON);
			throw 'internalConfigError';
		}
	}
	catch(err)
	{
		throw err;
	}
}