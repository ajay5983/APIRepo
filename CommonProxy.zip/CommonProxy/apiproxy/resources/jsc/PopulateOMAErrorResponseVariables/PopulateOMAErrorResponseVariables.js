populateOMAErrorResponseVariables = function populateOMAErrorResponseVariables() { // eslint-disable-line no-undef
	try {
		var error_payload = "";
		
		var exceptionName = "serviceException";
		var errorMessage = "Internal Server Error";
		var errorDetail = "A service error occurred.Error code is %1";
		var errorCode = "500";
		var errorId = "SVC0001";
		var variables = "Server error";

		var faultName = context.getVariable("fault.name");
		var errorJSON = context.getVariable("errorJSON");
		var httpStatusCode = context.getVariable("message.status.code");
		var error_ID = "";
		var hypermedia_standard = context.getVariable("hypermedia_standard");
		var hypermediaValue = "";
		var request_param = context.getVariable("request_param");
		var request_header = context.getVariable("request_header");
		
		hypermediaValue = hypermedia_standard + "_";
		if(errorJSON!==null && errorJSON!==""){
			errorJSON = errorJSON.replace("a42", "oma");
			context.setVariable("errorJSON",errorJSON);
		}
		
		if(request_param ==="MSISDN"){
			request_param = "address";
		}

		if (errorJSON && context.getVariable(errorJSON)) {
			error_payload = JSON.parse(context.getVariable(errorJSON));

			if ((request_param) && (errorJSON === "oma_generic_missing_request_parameter")) {
				variables = request_param;
			} else if ((request_param) && (errorJSON === "oma_generic_invalid_request_parameter")) {
				variables = request_param;
			} else if ((request_header) && (errorJSON === "oma_generic_missing_request_header")) {
				variables = request_header;
			} else if ((request_header) && (errorJSON === "oma_generic_invalid_request_header")) {
				variables = request_header;
			} else {
				variables = error_payload.variables;
			}
			exceptionName = error_payload.exceptionName;
			errorMessage = error_payload.errorMessage;
			errorDetail = error_payload.errorDetail;
			errorCode = error_payload.errorCode;
			errorId = error_payload.errorId;

		} else if (faultName === "InvalidAPICallAsNoApiProductMatchFound") {
			error_ID = hypermediaValue + "oauth_unauthorized_client";
		} else if (faultName === "InvalidClientIdForGivenResource") {
			error_ID = hypermediaValue + "oauth_scope_missing_invalid";
		} else if (faultName === "invalid_access_token") {
			error_ID = hypermediaValue + "generic_invalid_access_token";
		} else if (faultName === "InvalidBasicAuthenticationSource") {
			error_ID = hypermediaValue + "generic_invalid_authorization_header";
		} else if (faultName === "access_token_expired") {
			error_ID = hypermediaValue + "generic_expired_access_token";
		} else if (faultName === "access_token_not_approved") {
			error_ID = hypermediaValue + "generic_revoked_access_token";
		} else if (faultName === "SpikeArrestViolation") {
			error_ID = hypermediaValue + "generic_spike_arrest_violation";
		} else if (faultName === "QuotaViolation") {
			error_ID = hypermediaValue + "generic_quota_limit_reached";
		} else if (faultName === "JsonPathParsingFailure") {
			error_ID = hypermediaValue + "generic_invalid_json_format";
		} else if (httpStatusCode === "502") {
			error_ID = hypermediaValue + "generic_bad_gateway";
		} else if (httpStatusCode === "503") {
			error_ID = hypermediaValue + "generic_service_unavailable";
		} else if (httpStatusCode === "504") {
			error_ID = hypermediaValue + "generic_gateway_timeout";
		} else {
			error_ID = hypermediaValue + "generic_internal_server_error";
		}

		if (error_ID && context.getVariable(error_ID)) {
			error_payload = JSON.parse(context.getVariable(error_ID));
			if (error_payload) {
				exceptionName = error_payload.exceptionName;
				errorMessage = error_payload.errorMessage;
				errorDetail = error_payload.errorDetail;
				errorCode = error_payload.errorCode;
				errorId = error_payload.errorId;
				variables = error_payload.variables;
			}
		}

		context.setVariable("exceptionName", exceptionName);
		context.setVariable("errorMessage", errorMessage);
		context.setVariable("errorDetail", errorDetail);
		context.setVariable("errorCode", errorCode);
		context.setVariable("errorId", errorId);
		context.setVariable("variables", variables);

		var dateForFault = new Date().toISOString();
		context.setVariable("dateForFault", dateForFault);

	} catch (err) {
		throw err;
	}
};
