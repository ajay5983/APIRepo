setACRRequestHeaders = function setACRRequestHeaders(){ // eslint-disable-line no-undef
var market=context.getVariable("accesstoken.market").toLowerCase();
var acrRequestPayload;
var acrCalloutTargetPath;

if("nv" === market){
	
	    localSub = context.getVariable("localSub");
		acrRequestPayload={
			    "vodafoneId": localSub,
			     "type": "static"
			};
		acrCalloutTargetPath="/acrFromVodafoneId";
	
}else{
	
	msisdn=context.getVariable("accesstoken.msisdn");
	acrRequestPayload={
		    "type": "static",
		    "msisdn": msisdn
		};
	acrCalloutTargetPath="/acr";
}

context.setVariable("acrRequestPayload",JSON.stringify(acrRequestPayload));
context.setVariable("acrCalloutTargetPath",acrCalloutTargetPath);
};