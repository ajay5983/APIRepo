ThrottlingAppScope =  function ThrottlingAppScope() {
try
{
	var scope = context.getVariable('valid_scopes')||'';
	var errorJSON;
	var exceptionName = '';
	var ValidScope = '';
	var quota;
	
	var throttling_scope_config = context.getVariable('throttling_scope_config');
	var app = context.getVariable("developer.app.id");
	
	if(throttling_scope_config)
	{
		var scopeArray = scope.split(' ');
		throttling_scope_config = JSON.parse(throttling_scope_config);
		for(i=0;i<scopeArray.length;i++)
		{
			if(typeof(throttling_scope_config[scopeArray[i]]) != 'undefined')
			{
				ValidScope = scopeArray[i];
				break;					
			}
		}
		
		if(!ValidScope)
		{
			quota = throttling_scope_config['Default'];
			context.setVariable('quota',quota);
			context.setVariable("identifier",app+"_Default");
		}
		else if(!throttling_scope_config[ValidScope])
		{
			quota = throttling_scope_config['Default'];
			context.setVariable('quota',quota);
			context.setVariable("identifier",app+"_"+ValidScope);
		}
		else
		{
			quota = throttling_scope_config[ValidScope];
			context.setVariable('quota',quota);
			context.setVariable("identifier",app+"_"+ValidScope);
		}
		
		context.setVariable("doNotApplyQuota",false);
	}
	else
	{
		context.setVariable('doNotApplyQuota',true);
	}
}
catch(err)
{
	if(!errorJSON)
	{
		context.setVariable('errorJSON','a42_generic_internal_server_error');
		throw err;
	}
	else
	{
		throw exceptionName;
	}
}
}