try
{
	ThrottlingAppScope();
}

catch(err)
{
	throw err;
}