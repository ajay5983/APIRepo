accessCountryApi = function accessCountryApi() {
	try {
		var opCoInRequest = context.getVariable('countryISO');
		var orgOpcoConfig = JSON.parse(context.getVariable('runtime_whitelisting'));
		var developerOrg = context.getVariable('developer_organization_id');
		var developer_organization_uuid;

		if (orgOpcoConfig[developerOrg]) {
			developer_organization_uuid = orgOpcoConfig[developerOrg].COUNTRIES_WHITELISTED;
			if (!opCoInRequest) {
				context.setVariable('errorJSON','a42_generic_internal_config_error');
				throw 'internalConfigError';
			} else {
				if (developer_organization_uuid) {
					developer_organization_uuid = developer_organization_uuid.split(',');
					if (developer_organization_uuid.indexOf(opCoInRequest) == -1) {
						context.setVariable('errorJSON','a42_generic_invalid_country_id');
						throw 'invalidCountryID';
					}
					else{
						return true;
					}
				}
				else{
					return true;
				}
			}
		} else {
			context.setVariable('errorJSON', 'a42_generic_invalid_country_id');
			throw 'internalConfigError';
		}
	} catch (err) {
		throw err;
	}
}