//Extracts country and jws token from Access Token and set it in context

var country_code = context.getVariable("accesstoken.country");
var ms_token = context.getVariable("accesstoken.ms-token");

if(!country_code || !ms_token){
	context.setVariable("errorJSON", "a42_generic_invalid_access_token");
	throw "invalid_access_token";
	
}else{
	context.setVariable("countryISO", country_code.toUpperCase());
	context.setVariable("jws_token", ms_token);
}