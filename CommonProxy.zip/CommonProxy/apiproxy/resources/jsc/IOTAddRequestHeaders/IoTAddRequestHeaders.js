addRequestHeaders = function addRequestHeaders(){ // eslint-disable-line no-undef
	
var acr = context.getVariable("anon_cust_ref");

if(acr){
	context.setVariable("request.header.Acr",acr);
}

var customerCountryCode = context.getVariable("msisdnCountry");

if(customerCountryCode){
	context.setVariable("request.header.Customer-Country-Code",customerCountryCode);
}
};