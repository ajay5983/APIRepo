try
{
	var VF_INT_TRACE_ID = context.getVariable('VF_INT_TRACE_ID_req');
	var vf_trace_transaction_id = context.getVariable('vf_trace_transaction_id_req');
	
	var VF_INT_TRACK_ID = context.getVariable('VF_INT_TRACK_ID_req');
	var api_name = context.getVariable('apiproxy.name');
	
	var VF_INT_CALLER_ID = context.getVariable('VF_INT_CALLER_ID_req');
	var Org_UUID = context.getVariable('app.vf_app_org_uuid') || '';
	
	var VF_EXT_TRACE_ID = context.getVariable('VF_EXT_TRACE_ID_req');
	var VF_EXT_REFERENCE_ID = context.getVariable('VF_EXT_REFERENCE_ID_req');
	var VF_EXT_BP_ID = context.getVariable('VF_EXT_BP_ID_req');
  	var VF_GIG_TRANSACTION_ID = context.getVariable("VF_GIG_TRANSACTION_ID_req");
	
	if((!VF_INT_TRACE_ID) && (!vf_trace_transaction_id))
	{
		context.setVariable('request.header.vf-trace-transaction-id',context.getVariable('vf.trace.transaction.id'));
		context.setVariable('vf_trace_transaction_id_req',context.getVariable('vf.trace.transaction.id'));
	}
	else if((VF_INT_TRACE_ID) && (!vf_trace_transaction_id))
	{
		context.setVariable('request.header.VF_INT_TRACE_ID',VF_INT_TRACE_ID);
		
		context.setVariable('request.header.vf-trace-transaction-id',VF_INT_TRACE_ID);
		context.setVariable('vf_trace_transaction_id_req',VF_INT_TRACE_ID);
	}
	else if((!VF_INT_TRACE_ID) && (vf_trace_transaction_id))
	{
		context.setVariable('request.header.vf-trace-transaction-id',vf_trace_transaction_id);
	}
	else if((VF_INT_TRACE_ID) && (vf_trace_transaction_id))
	{
		context.setVariable('request.header.VF_INT_TRACE_ID',VF_INT_TRACE_ID);
		context.setVariable('request.header.vf-trace-transaction-id',vf_trace_transaction_id);
	}

	if(VF_INT_TRACK_ID)
	{
		context.setVariable('request.header.VF_INT_TRACK_ID',VF_INT_TRACK_ID + '.' + api_name + '-apix');
		context.setVariable('VF_INT_TRACK_ID_req',VF_INT_TRACK_ID + '.' + api_name + '-apix');
	}
	else
	{
		context.setVariable('request.header.VF_INT_TRACK_ID',api_name + '-apix');
		context.setVariable('VF_INT_TRACK_ID_req',api_name + '-apix');
	}
	
	if(VF_INT_CALLER_ID)
	{
		context.setVariable('request.header.VF_INT_CALLER_ID',VF_INT_CALLER_ID);
	}
	else if(Org_UUID)
	{
		context.setVariable('request.header.VF_INT_CALLER_ID',Org_UUID);
		context.setVariable('VF_INT_CALLER_ID_req',Org_UUID);
	}
	else
	{
		context.setVariable('request.header.VF_INT_CALLER_ID','unknown');
		context.setVariable('VF_INT_CALLER_ID_req','unknown');		
	}
	
	if(VF_EXT_TRACE_ID) context.setVariable('request.header.VF_EXT_TRACE_ID',VF_EXT_TRACE_ID);
	if(VF_EXT_REFERENCE_ID) context.setVariable('request.header.VF_EXT_REFERENCE_ID',VF_EXT_REFERENCE_ID);
	if(VF_EXT_BP_ID) context.setVariable('request.header.VF_EXT_BP_ID',VF_EXT_BP_ID);
  	if(VF_GIG_TRANSACTION_ID) context.setVariable('request.header.VF_GIG_TRANSACTION_ID',VF_GIG_TRANSACTION_ID);

}
catch(err)
{
	context.setVariable('errorJSON','a42_generic_internal_server_error');
	throw err;
}
