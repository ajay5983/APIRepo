PrepareHomeDocumentResponse = function PrepareHomeDocumentResponse() {

	var homeDocRules = parseJson(context.getVariable("home_doc_rules"));
	var homeDocDefinitions = parseJson(context
			.getVariable("home_doc_definitions"));
	var homeDOCExpiryInSeconds = context
			.getVariable("home_doc_expiry_in_seconds");
	var sortedScopes = context.getVariable("sortedScopes");
	if (!(homeDocRules && homeDocDefinitions && homeDOCExpiryInSeconds)) {
		context.setVariable('errorJSON', 'a42_generic_internal_config_error');
		throw "internalConfigError";
	}
	var uniqueLinks = UniqueLinksForScopes(sortedScopes.split(','),
			homeDocRules);
	var homeDocResponse = {};
	homeDocResponse.links = getHomeDocDefinitions(uniqueLinks,
			homeDocDefinitions);
	var homeDocExpiry = getExpiryDate(homeDOCExpiryInSeconds);

	var payload = {};
	payload.LRTs = uniqueLinks;
	payload.Expiry = homeDocExpiry;

	var eTagPayload = JSON.stringify(payload);
	var eTagHeader = generateETagHeader(eTagPayload);

	var host = context.getVariable("request.header.host");

	context.setVariable("ETagPayload", eTagPayload);
	context.setVariable("cacheExpiryDate", homeDocExpiry.toString());
	context.setVariable("homeDocResponse", JSON.stringify(homeDocResponse)
			.replace(/{apix.endpoint}/g, host));
	context.setVariable("ETagHeader", eTagHeader);

	function UniqueLinksForScopes(sortedScopes, homeDocRules) {
		var uniqueDocScopes = Object.keys(homeDocRules.scopes);
		var filterDocRules = uniqueDocScopes.filter(function(element) {
			return sortedScopes.indexOf(element) > -1
		});
		var links = [];

		for (var i = 0; i < filterDocRules.length; i++) {
			var selectedScope = homeDocRules.scopes[filterDocRules[i]];
			Array.prototype.push.apply(links, selectedScope);
		}

		var uniqueLinks = [];
		for (var j = 0; j < links.length; j++) {
			if (uniqueLinks.indexOf(links[j]) == -1) {
				uniqueLinks.push(links[j]);
			}
		}
		return uniqueLinks;
	}

	function getKey(obj) {
		return Object.keys(obj)[0];
	}

	function getHomeDocDefinitions(uniqueLinks, homeDocDefinitions) {
		var obj = {};
		for (var i = 0; i < homeDocDefinitions.length; i++) {
			if (getKey(homeDocDefinitions[i]) == "self") {
				obj["self"] = homeDocDefinitions[i].self;
			} else {
				if (uniqueLinks.indexOf(getKey(homeDocDefinitions[i])) > -1) {
					obj[getKey(homeDocDefinitions[i])] = homeDocDefinitions[i][getKey(homeDocDefinitions[i])];
				}
			}
		}

		return obj;

	}

	function getExpiryDate(expiryInSeconds) {
		var currentDate = new Date();
		return new Date(currentDate.getTime() + expiryInSeconds * 1000);
	}

	function generateETagHeader(eTagData) {
		var md5Response = calcMD5(eTagData);
		return "W/" + '"' + md5Response + '"';
	}

	function parseJson(data) {
		try {
			return JSON.parse(data);
		} catch (e) {
			return false;
		}
	}
}