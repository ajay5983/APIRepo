CalculateRemainingTime = function(){
	var payload = context.getVariable("homeDocumentCachedData");
	var eTagValue = context.getVariable("request.header.If-None-Match");
	if(payload === "" || payload === null){
		context.setVariable('errorJSON','a42_generic_internal_config_error');
		throw "internalConfigError";
	}
	var jsonPayload = JSON.parse(payload);
	var cachedDate = new Date(jsonPayload.Expiry);
	var currentDate = new Date();
	var diff = cachedDate.getTime() - currentDate.getTime();
	var remainingSeconds = (Math.round(diff/1000)).toString();
	
	context.setVariable("remainingSeconds",remainingSeconds);
	context.setVariable("expiresDate", cachedDate.toString());
	context.setVariable("eTagValue", eTagValue);
}