try{
	CalculateRemainingTime();
}catch(err){
	throw err
}