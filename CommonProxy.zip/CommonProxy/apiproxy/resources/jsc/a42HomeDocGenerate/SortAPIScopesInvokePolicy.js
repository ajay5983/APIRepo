try{
	SortAPIScopes();
}catch(err){
	throw err;
}