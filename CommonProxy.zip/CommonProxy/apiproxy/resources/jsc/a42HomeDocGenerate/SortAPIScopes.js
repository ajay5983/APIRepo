 SortAPIScopes = function(){
	var scopes = context.getVariable("accesstoken.scope");
	if(scopes === "" || scopes === null){
		context.setVariable('errorJSON','a42_generic_internal_config_error');
		throw "internalConfigError";
	}
	var scopesArray = scopes.split(" ");
	var sortedScopes = scopesArray.sort();
	context.setVariable("sortedScopes", sortedScopes.toString());
}