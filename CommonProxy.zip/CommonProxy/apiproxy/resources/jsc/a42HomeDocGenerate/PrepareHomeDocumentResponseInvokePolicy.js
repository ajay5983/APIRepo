try{
	PrepareHomeDocumentResponse();
} catch(err){
	throw err;
}