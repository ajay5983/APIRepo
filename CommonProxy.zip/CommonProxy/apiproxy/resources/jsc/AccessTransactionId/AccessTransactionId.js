function generateUUID() { // eslint-disable-line no-use-before-define
	var d = new Date().getTime();
	var uuid = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,
		function(c) {
			var r = ((d + (Math.random() * 16)) % 16) | 0; // eslint-disable-line no-bitwise
			d = Math.floor(d / 16);
			return (c === "x" ? r : ((r & 0x3) | 0x8)).toString(16); // eslint-disable-line no-bitwise
		});
	return uuid;
}

/*function isValidUUID(transId){ // eslint-disable-line no-use-before-define
	var status = false;
	var pattern = new RegExp("[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[4][0-9A-Fa-f]{3}-[89ABab][0-9A-Fa-f]{3}-[0-9A-Fa-f]{12}");
	if (pattern.test(transId)){
		status = true;
	}
	return status;
}*/

AccessTransactionId = function AccessTransactionId(){ // eslint-disable-line no-undef
	var errorJSON;
	var exceptionName = "";
	try {
		var transactionId = context.getVariable("request.header.vf-trace-transaction-id") || context.getVariable("request.header.VF_INT_TRACE_ID");
		if (transactionId) {
			context.setVariable("vf.trace.transaction.id", transactionId);
			/*if (!(isValidUUID(transactionId))) {
				errorJSON = "a42_generic_invalid_uuid";
				context.setVariable("errorJSON", errorJSON);
				exceptionName = "invalidUUID";
				throw exceptionName;
			}*/
		} else {
			transactionId = generateUUID();
			context.setVariable("vf.trace.transaction.id", transactionId);
		}

	} catch (err){
		if (!errorJSON) {
			context.setVariable("errorJSON", "a42_generic_internal_server_error");
			throw err;
		} else {
			throw exceptionName;
		}
	}
};