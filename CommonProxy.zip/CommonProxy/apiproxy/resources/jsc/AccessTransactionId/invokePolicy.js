try{
    AccessTransactionId();
}

catch(err){
	throw err;
}