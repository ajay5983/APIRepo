var headers = null;
var inboundRequestUri = context.getVariable("proxy.url");
var verb = context.getVariable("request.verb");

var payload = null;
var flow = context.flow;
var timestamp = context.getVariable('system.time');
var apiName = context.getVariable('apiproxy.name');
var envName = context.getVariable('environment.name');

var transactionId = getTranscationID();

 logData = {
	"correlationID" : transactionId,
	"timestamp" : getTimeStamp(),
    "url": context.getVariable("clientRequestedURL"),
    "orgName" : context.getVariable('organization.name'),
    "envName" : context.getVariable('environment.name'),
	"apiproxy" : apiName,
    "transaction_time" :  context.getVariable('system.timestamp') - context.getVariable("client.received.end.timestamp"),
    "http_code": "",
    "backend_error": "",
    "backend_time": "",
    "error": ""
 }
 

switch (flow) {

case "PROXY_RESP_FLOW":

	logData["http_code"] = context.getVariable("response.status.code");
    logData["backend_time"]=context.getVariable('target.received.end.timestamp') - context.getVariable('target.sent.start.timestamp');
	break;

case "ERROR":
	logData["http_code"] = context.getVariable("message.status.code");

	if (context.getVariable("error.state") == "TARGET_RESP_FLOW") {
		logData["backend_error"] = context.getVariable("backendErrorPayload");
		logData["backend_time"]=context.getVariable('target.received.end.timestamp') - context.getVariable('target.sent.start.timestamp');
	}else{
		logData["error"] = context.getVariable('faultName') || context.getVariable('message.content') ;
	}
	break;

}
 
 
context.setVariable("aggregatedLogData", JSON.stringify(logData));

function addAttrbuteToLogPayload(key, value){
  if(key && value) {
  logData[key] = value;
  }
}

function generateUUID(){
    var d = new Date().getTime();
    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = (d + Math.random()*16)%16 | 0;
        d = Math.floor(d/16);
        return (c=='x' ? r : (r&0x7|0x8)).toString(16);
    });
    return uuid;
};



function getTimeStamp(){

var d=new Date();
var n=d.toTimeString();     
var timezone = "+";

n = d.getTimezoneOffset()+"";
if (n > 0){
  timezone = "-"
}
n = n.substring(1);
var hours =  ("00"+(n / 60)).slice(-2) ;
var minutes = ("00"+(n % 60)).slice(-2);
timezone +=  hours+":"+minutes;

  return ("00"+(context.getVariable("system.time.year"))).slice(-4) + "-"
  +   ("00"+(context.getVariable("system.time.month"))).slice(-2) + "-"
  +   ("00"+(context.getVariable("system.time.day"))).slice(-2) + "T"
  +   ("00"+(context.getVariable("system.time.hour"))).slice(-2) + ":"
  +   ("00"+(context.getVariable("system.time.minute"))).slice(-2) + ":"
  +   ("00"+(context.getVariable("system.time.second"))).slice(-2) + ","
  +   ("00"+(context.getVariable("system.time.millisecond"))).slice(-3) 
  + timezone;
}


function getTranscationID(){
var transactionId = context.getVariable("requestUUIDToLog");
if (!transactionId) {
     transactionId = context.getVariable("request.header.x-vf-trace-transaction-id");
	 if (!transactionId)  
		transactionId = generateUUID();
     context.setVariable("requestUUIDToLog", transactionId);
}  
return transactionId;
}
