extractUserInfoResponseForServiceEligy = function extractUserInfoResponseForServiceEligy(){ // eslint-disable-line no-undef
var userInfoResponse = context.getVariable("IoTUserInfoCalloutForServiceEligibilityCheckResponse.content");
var statusCode = context.getVariable("IoTUserInfoCalloutForServiceEligibilityCheckResponse.status.code");
var errorJSON = "";
var responseData= JSON.parse(userInfoResponse);
if (statusCode != "200"){
	errorJSON = "a42_generic_internal_server_error";
			context.setVariable("errorJSON", errorJSON);
			throw " Internal Server Error";
}	
else {
	if(responseData){
		context.setVariable("serviceEligibilityCheckUserInfoResponse",responseData);
}
}


}