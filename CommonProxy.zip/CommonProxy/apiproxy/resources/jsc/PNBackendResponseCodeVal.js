var respStatusCode = context.getVariable("ResponseCode");
var respReasonPhrase = context.getVariable("ReasonPhrase");
var respErrorC=context.getVariable("respErrorCode");
var resError=context.getVariable("respError");
var respStatus =  context.getVariable("respStatus");
var isUAError = false;
var isUAError1 = false;
var isUAError2 = false;
var sCode = 500;
var sCode1 = 400;
var rPhrase1 = "Bad Request"
var rPhrase = "Internal Server Error";
var respSCToString = respStatusCode.toString();
var respSCFirstDG = respSCToString.substring(1,0);
var faultUACalloutResponse={};
var helpLink = context.getVariable("api_help_link");
var transaction_id = context.getVariable("vf.trace.transaction.id");
var respDetails = context.getVariable("respDetails");
var detailsError = context.getVariable("detailError");
var detailsMessage = context.getVariable("detailMessage");
var uaResponse=context.getVariable("response.content");
uaResponseJson = JSON.parse((uaResponse || '{}'));
var err;
var errorMsg;
var errorDescription;
var statusCode;
var reasonPhrase;
var isError = false;
var setDetails = false;

if(respSCFirstDG == "4" && (respErrorC == undefined || respErrorC== null || respErrorC == "") ) {
	isUAError = true;
}
if(respSCFirstDG =="4" && (respErrorC != undefined || respErrorC != null || respErrorC != "") ) {
	isUAError2 = true;
}
if(respSCFirstDG =="5") {
	isUAError1 = true;
}

if(!isError && isUAError) {
	err = "invalid_request";
	errorMsg  = "invalid_request";
	errorDescription = "The request is invalid";
	statusCode = sCode1;
	reasonPhrase = rPhrase1;
	isError = true;
	setDetails =  true;
}

if(!isError && isUAError1) {	
	err = "server_error";
	errorMsg  = "server_error";
	errorDescription = "The service is currently not available. Please try again later";
	statusCode = sCode;
	reasonPhrase = rPhrase;
	isError = true;
	setDetails =  true;
}

if(!isError && isUAError2) {
	err = respErrorC;
	errorMsg  = respErrorC;
	errorDescription = resError;
	statusCode = respStatusCode;
	reasonPhrase = respReasonPhrase;
	isError = true;
	setDetails =  true;
}

if(!isError && !respStatus){
	err = respErrorCode;
	errorMsg  = respErrorCode;
	errorDescription = respError;
	statusCode = sCode;
	reasonPhrase = rPhrase;
	isError = true;
}

if(helpLink){
	faultUACalloutResponse.links={};
	faultUACalloutResponse.links.help={};
	faultUACalloutResponse.links.help.href=helpLink;
}

if(errorMsg){
	faultUACalloutResponse.message = errorMsg;
}

faultUACalloutResponse.description = errorDescription;

if(err){
	faultUACalloutResponse.error = err;
}
faultUACalloutResponse.transactionId = transaction_id;
if(uaResponseJson.details && setDetails){
  if(detailsError || detailsMessage){
	  if ( detailsError ) {
		  uaResponseJson.details.error = detailsError;
	  }
	  if ( detailsMessage ) {
		  uaResponseJson.details[0].message = detailsMessage;
	  }
faultUACalloutResponse.details =uaResponseJson.details;
}
}

context.setVariable('statusCode' ,statusCode);
context.setVariable('reasonPhrase' ,reasonPhrase);
context.setVariable("faultUACalloutResponse",JSON.stringify(faultUACalloutResponse));

