function SecurityAPIWhitelisting(){
try
{
	var IncomingIP = context.getVariable('proxy.client.ip');
	var whitelistedIPs = context.getVariable('whitelistedIPs');
	var errorJSON;
	var exceptionName='';
	
	if(whitelistedIPs)
	{
		whitelistedIPs = whitelistedIPs.replace(/\s/g,'');
		whitelistedIPsArray = whitelistedIPs.split(",");
		if(whitelistedIPsArray.indexOf(IncomingIP) == -1)
		{
			errorJSON = 'a42_generic_invalid_ip';
			context.setVariable('errorJSON',errorJSON);
			exceptionName = 'genericInvalidIP';
			throw exceptionName;
		}
	}
	else
	{
		errorJSON = 'a42_generic_internal_config_error';
		context.setVariable('errorJSON',errorJSON);
		exceptionName = 'internalConfigError';
		throw exceptionName;
	}
}
catch(err){
    if(!errorJSON)
    {
        context.setVariable('errorJSON','a42_generic_internal_config_error');
        throw err;
    }
    else
    {
        throw exceptionName;
    }
}
}