try
{
	handleCSMFaultResponse();
}
catch(err)
{
	throw err;
}