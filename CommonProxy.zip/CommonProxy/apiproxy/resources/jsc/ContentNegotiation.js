try
{
	var acceptHeader = context.getVariable('request.header.accept');
	if(acceptHeader)
	{
		var preferredMediaTypeHdrArray = context.getVariable('request.header.accept.values');
		var preferredMediaTypesKVM = context.getVariable('kvm_global_accept_header');
		var preferredMediaTypesKVMArray = preferredMediaTypesKVM.split(',');
		
		var errorJSON=null;
		var preferredMediaType;

		var accHdrStr = preferredMediaTypeHdrArray.toString();
		accHdrStr = accHdrStr.replace('[',''); accHdrStr = accHdrStr.replace(']',''); accHdrStr = accHdrStr.replace(' ','');
		
		var accHdrArray = accHdrStr.split(',');
			
		
		for(i=0;i<preferredMediaTypesKVMArray.length;i++)
		{
			if(preferredMediaType)
			{
			    break;
			}
			for(j=0;j<accHdrArray.length;j++)
			{	
				if(preferredMediaType)
			    {
			        break;
			 
			    }
				currAccHdrArray = accHdrArray[j];
				if(currAccHdrArray.contains(';'))
				{
					currAccHdrArray = currAccHdrArray.substring(0, currAccHdrArray.indexOf(';'));
				}
				
				if(preferredMediaTypesKVMArray[i] == currAccHdrArray)
				{									
					preferredMediaType = 'application/json';
					context.setVariable('preferredMediaType',preferredMediaType);
				}
			}
		}
		if(!preferredMediaType)
		{
				errorJSON = 'a42_generic_invalid_accept_header';
				context.setVariable('errorJSON',errorJSON);
				throw 'invalidAcceptHeader';
		}
	}
}
catch(err){
    if(!errorJSON)
    {
        context.setVariable('errorJSON','a42_generic_internal_config_error');
        throw err;
    }
    else
    {
        throw 'invalidAcceptHeader';
    }
}