// raise fault for invalid Authorization Header
context.setVariable("errorJSON", "a42_generic_invalid_authorization_header");
throw "invalidAuthorizationheaderError";