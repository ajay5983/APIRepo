/* This java script is used to get error to mask */

var uaResponse=context.getVariable("response.content");
uaResponseJson = JSON.parse(uaResponse);

if(uaResponseJson.details){
var detailsError = uaResponseJson.details.error;
var detailsMessage;
if(Array.isArray(uaResponseJson.details)){
detailsMessage= uaResponseJson.details[0].message;
}
if(detailsError){
context.setVariable("detailError",detailsError);
}
if(detailsMessage){
	context.setVariable("detailMessage",detailsMessage);
	}
}
