subValidation = function subValidation(){ // eslint-disable-line no-undef

var sub = context.getVariable("accesstoken.sub");
var apixAppID = context.getVariable("developer.app.id");
var customizedErrorMessage='';

var acr = context.getVariable("accesstoken.anon_cust_ref");

var tokenMsisdn = context.getVariable("accesstoken.msisdn");
context.setVariable("inputMsisdn",tokenMsisdn);	

var msisdn = "";

var timestamp = context.getVariable("accesstoken.lastInvoketime");

var userInfoThreshold = context.getVariable("UserInfo_Threshold_MilliSeconds");
if(acr){
	context.setVariable("request.header.Acr",acr);
}else{
	msisdn = context.getVariable("accesstoken.msisdn");
	context.setVariable("noACRInToken","true");	
}

if(timestamp){
	var currentTime = new Date().getTime();
	
	if((currentTime - timestamp) <  userInfoThreshold ){
		context.setVariable("validUserInfoTimeStamp", "true");
	}
	
}


if(apixAppID){
	context.setVariable("request.header.Apix-App-Id",apixAppID);
}

var customerCountryCode = context.getVariable("accesstoken.Customer-Country-Code");

if(customerCountryCode){
	context.setVariable("request.header.Customer-Country-Code",customerCountryCode);
}else{
	context.setVariable("noCCCodeInToken","true");
}

var market=context.getVariable("accesstoken.market").toLowerCase();
var localSub;

if("nv" === market){
	
	claims = context.getVariable("accesstoken.claimsFromRequest");
	claims = JSON.parse(claims);
	localSub = claims["local_sub"];
	
	if(localSub){
		context.setVariable("localSub", localSub);
	}else{
		customizedErrorMessage={
			"statusCode": "401",
			"reasonPhrase": "Unauthorized", 
			"errorCode": "invalid_token", 
			"errorDescription": "The access token is invalid",
			};
			context.setVariable("errorJSON", 'customizedErrorMessage');
			context.setVariable("customizedErrorMessage", JSON.stringify(customizedErrorMessage));
			throw "Unauthorized";	
	}
}

if(!sub || (!msisdn && !acr)){
	customizedErrorMessage={
			"statusCode": "401",
			"reasonPhrase": "Unauthorized", 
			"errorCode": "invalid_token", 
			"errorDescription": "The access token is invalid",
			};
			context.setVariable("errorJSON", 'customizedErrorMessage');
			context.setVariable("customizedErrorMessage", JSON.stringify(customizedErrorMessage));
			throw "Unauthorized";	
}else{
	context.setVariable("request.header.Customer-Id",sub);
	context.setVariable("msisdn",msisdn);
}




};