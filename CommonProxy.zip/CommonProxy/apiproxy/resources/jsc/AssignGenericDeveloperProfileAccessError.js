context.setVariable("errorJSON",'a42_generic_developerapp_profile_access_error');
throw "developerAccessError";