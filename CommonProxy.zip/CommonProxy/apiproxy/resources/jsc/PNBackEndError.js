var customizedErrorMessage='';

try {
	context.setVariable("APIXEndpoint",context.getVariable("request.header.host"));
	
		customizedErrorMessage={
				"statusCode": "400",
				"reasonPhrase": "Bad Request", 
				"errorCode": "invalid_request", 
				"errorDescription": "The Request is Invalid"
				};
		
}
 catch (err) {
	context.setVariable("errorJSON", 'a42_generic_invalid_json_format');
	throw "invalidJSON";
}
if (result) {
	context.setVariable("errorJSON", 'customizedErrorMessage');
	context.setVariable("customizedErrorMessage", JSON.stringify(customizedErrorMessage));
	throw "uaBackendError";
}