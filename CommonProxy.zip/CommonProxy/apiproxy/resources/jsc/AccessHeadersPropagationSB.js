try
{
	var status_code = context.getVariable('message.status.code');
	var api_name = context.getVariable('apiproxy.name');
	
	var VF_INT_TRACE_ID = context.getVariable('VF_INT_TRACE_ID_resp')||context.getVariable('VF_INT_TRACE_ID_req');
	var vf_trace_transaction_id = context.getVariable('vf_trace_transaction_id_resp')||context.getVariable('vf_trace_transaction_id_req');
	var VF_INT_TRACK_ID = context.getVariable('VF_INT_TRACK_ID_resp')||context.getVariable('VF_INT_TRACK_ID_req');
	var VF_INT_CALLER_ID = context.getVariable('VF_INT_CALLER_ID_resp')||context.getVariable('VF_INT_CALLER_ID_req');
	var VF_EXT_TRACE_ID = context.getVariable('VF_EXT_TRACE_ID_resp')||context.getVariable('VF_EXT_TRACE_ID_req');
	var VF_EXT_REFERENCE_ID = context.getVariable('VF_EXT_REFERENCE_ID_resp')||context.getVariable('VF_EXT_REFERENCE_ID_req');
	var VF_EXT_BP_ID = context.getVariable('VF_EXT_BP_ID_resp')||context.getVariable('VF_EXT_BP_ID_req');
	var VF_INT_STATUS_FLOW = context.getVariable('VF_INT_STATUS_FLOW_resp');
	var X_Frame_Options = context.getVariable('X_Frame_Options');
	var X_Content_Type_Options = context.getVariable('X_Content_Type_Options');
	var X_XSS_Protection = context.getVariable('X_XSS_Protection');
  	var VF_GIG_TRANSACTION_ID_REQ = context.getVariable("VF_GIG_TRANSACTION_ID_req");
	var VF_GIG_TRANSACTION_ID_RESP = context.getVariable("VF_GIG_TRANSACTION_ID_resp");

	if(VF_INT_TRACE_ID) context.setVariable('message.header.VF_INT_TRACE_ID',VF_INT_TRACE_ID);
	if(vf_trace_transaction_id) context.setVariable('message.header.vf-trace-transaction-id',vf_trace_transaction_id);
	if(VF_INT_TRACK_ID) context.setVariable('message.header.VF_INT_TRACK_ID',VF_INT_TRACK_ID + '.' + api_name + '-apix');
	if(VF_INT_CALLER_ID) context.setVariable('message.header.VF_INT_CALLER_ID',VF_INT_CALLER_ID);
	if(VF_EXT_TRACE_ID) context.setVariable('message.header.VF_EXT_TRACE_ID',VF_EXT_TRACE_ID);
	if(VF_EXT_REFERENCE_ID) context.setVariable('message.header.VF_EXT_REFERENCE_ID',VF_EXT_REFERENCE_ID);
	if(VF_EXT_BP_ID) context.setVariable('message.header.VF_EXT_BP_ID',VF_EXT_BP_ID);
	if(X_Frame_Options) context.setVariable('message.header.X-Frame-Options',X_Frame_Options);
	if(X_Content_Type_Options) context.setVariable('message.header.X-Content-Type-Options',X_Content_Type_Options);
	if(X_XSS_Protection) context.setVariable('message.header.X-XSS-Protection',X_XSS_Protection);
	if(VF_GIG_TRANSACTION_ID_REQ) context.setVariable('message.header.VF_GIG_TRANSACTION_ID',VF_GIG_TRANSACTION_ID_RESP);
	
	if(VF_INT_STATUS_FLOW)
	{
		context.setVariable('message.header.VF_INT_STATUS_FLOW',VF_INT_STATUS_FLOW);
	}
	else if((status_code >= 200) && (status_code < 400))
	{
		context.setVariable('message.header.VF_INT_STATUS_FLOW','ok');
	}
	else
	{
		context.setVariable('message.header.VF_INT_STATUS_FLOW','failure');
	}
}
catch(err)
{
	context.setVariable('errorJSON','a42_generic_internal_server_error');
	throw err;
}
