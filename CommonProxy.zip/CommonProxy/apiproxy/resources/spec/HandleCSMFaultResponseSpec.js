require('../jsc/HandleCSMFaultResponse/HandleCSMFaultResponse');

describe('HandleCSMFaultResponse Validation Suites', function() {
	
    beforeEach(function(){
      var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });
    
    it ('1: Negative: if 604 error', function() {
		context.setVariable("failureCode",null);
		context.setVariable("errorCode",null);
		context.setVariable("errorMessage",null);
		context.setVariable("Name",null);
		context.setVariable("faultCode",null);
		context.setVariable("transId",null);
		expect(handleCSMFaultResponseTest()).toBe();
        
        expect(context.getVariable("statusCode")).toBe("400");
		expect(context.getVariable("reasonPhrase")).toBe("Bad Request");
		expect(context.getVariable("errorCode")).toBe("server_error");
		expect(context.getVariable("errorDescription")).toBe("Bad Request");
		

    });
    
     it ('2: Negative: if 602 error', function() {
		context.setVariable("failureCode",null);
		context.setVariable("errorCode",null);
		context.setVariable("errorMessage",null);
		context.setVariable("Name",null);
		context.setVariable("faultCode","client");
		context.setVariable("transId",null);
		
        expect(handleCSMFaultResponseTest()).toBe();
        expect(context.getVariable("statusCode")).toBe("400");
		expect(context.getVariable("reasonPhrase")).toBe("Bad Request");
		expect(context.getVariable("errorCode")).toBe("server_error");
		expect(context.getVariable("errorDescription")).toBe("Bad Request");
		
		
    });
    it ('3: Negative: if 500 error', function() {
		context.setVariable("failureCode",602);
		context.setVariable("errorCode",null);
		context.setVariable("errorMessage",null);
		context.setVariable("Name",null);
		context.setVariable("faultCode","server");
		context.setVariable("transId",null);
		
        expect(handleCSMFaultResponseTest()).toBe();
        expect(context.getVariable("statusCode")).toBe("500");
		expect(context.getVariable("reasonPhrase")).toBe("Internal Server Error");
		expect(context.getVariable("errorCode")).toBe("multiple_subscriptions");
		expect(context.getVariable("errorDescription")).toBe("Multiple subscriptions found.");
		
		
    });
    
    it ('4: Negative: if 500 error', function() {
		context.setVariable("failureCode",402);
		context.setVariable("errorCode",null);
		context.setVariable("errorMessage",null);
		context.setVariable("Name",null);
		context.setVariable("faultCode","server");
		context.setVariable("transId",null);
		
        expect(handleCSMFaultResponseTest()).toBe();
        expect(context.getVariable("statusCode")).toBe("500");
		expect(context.getVariable("reasonPhrase")).toBe("Internal Server Error");
		expect(context.getVariable("errorCode")).toBe("server_error");
		expect(context.getVariable("errorDescription")).toBe("Internal Server Error");
		
		
    });
    
     it ('5: Negative: if 500 error', function() {
		context.setVariable("failureCode",402);
		context.setVariable("errorCode",405);
		context.setVariable("errorMessage",null);
		context.setVariable("Name",null);
		context.setVariable("faultCode",null);
		context.setVariable("transId",null);
		
        expect(handleCSMFaultResponseTest()).toBe();
        expect(context.getVariable("statusCode")).toBe("400");
		expect(context.getVariable("reasonPhrase")).toBe("Bad Request");
		expect(context.getVariable("errorCode")).toBe("server_error");
		expect(context.getVariable("errorDescription")).toBe("Bad Request");
		
		
    });
    it ('6: Negative: if 500 error', function() {
		context.setVariable("failureCode",602);
		context.setVariable("errorCode",null);
		context.setVariable("errorMessage",null);
		context.setVariable("Name",null);
		context.setVariable("faultCode","abcd");
		context.setVariable("transId",null);
		
        expect(handleCSMFaultResponseTest()).toBe();
        expect(context.getVariable("statusCode")).toBe("500");
		expect(context.getVariable("reasonPhrase")).toBe("Internal Server Error");
		expect(context.getVariable("errorCode")).toBe("server_error");
		expect(context.getVariable("errorDescription")).toBe("Internal Server Error");
		
		
    });
    
});