var validationContentTypeNew = require('../jsc/ValidationContentType/ValidationContentType');

describe('ContentType Header Validation Suites', function() {
	
    beforeEach(function(){
      var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });
    it ('1: Negative: if Content-Type header is missing for PATCH Method', function() {
		context.setVariable("request.verb","PATCH");
		context.setVariable("validation_content_type_header_patch","application/merge-patch+json,application/json");
        expect(validationContentType).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_content_type_header");
    });
	it ('2: Negative: if Content-Type header is empty for PATCH Method', function() {
	    context.setVariable("request.header.Content-Type", "");
		context.setVariable("request.verb","PATCH");
		context.setVariable("validation_content_type_header_patch","application/merge-patch+json,application/json");
        expect(validationContentType).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_content_type_header");
	});
	it ('3: Negative: if Content-Type header is invalid for PATCH Method', function() {
	    context.setVariable("request.header.Content-Type", "application/xml");
		context.setVariable("request.verb","PATCH");
		context.setVariable("validation_content_type_header_patch","application/merge-patch+json,application/json");
        expect(validationContentType).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_content_type_header");
	});
    it ('4: Negative: if Content-Type header is missing for POST Method', function() {
		context.setVariable("request.verb","POST");
		context.setVariable("validation_content_type_header","application/vnd.vodafone.a42+json,application/json");
        expect(validationContentType).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_content_type_header");
    });
	it ('5: Negative: if Content-Type header is empty for POST Method', function() {
	    context.setVariable("request.header.Content-Type", "");
		context.setVariable("request.verb","POST");
		context.setVariable("validation_content_type_header","application/vnd.vodafone.a42+json,application/json");
        expect(validationContentType).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_content_type_header");
	});
	it ('6: Negative: if Content-Type header is invalid for POST Method', function() {
	    context.setVariable("request.header.Content-Type", "application/xml");
		context.setVariable("request.verb","POST");
		context.setVariable("validation_content_type_header","application/vnd.vodafone.a42+json,application/json");
        expect(validationContentType).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_content_type_header");
	});
	it ('7: Positve: if Content-Type header is missing for GET Method', function() {
		context.setVariable("request.verb","GET");
		context.setVariable("validation_content_type_header","application/vnd.vodafone.a42+json,application/json");
        expect(validationContentType()).toBe();
		expect(context.getVariable("errorJSON")).toBe(undefined);
	});
	it ('8: Positve: if Content-Type header is empty for GET Method', function() {
		context.setVariable("request.verb","GET");
		context.setVariable("request.header.Content-Type", "");
		context.setVariable("validation_content_type_header","application/vnd.vodafone.a42+json,application/json");
        expect(validationContentType()).toBe();
		expect(context.getVariable("errorJSON")).toBe(undefined);
	});
	it ('9: Positive: if Content-Type header is invalid for GET Method', function() {
	    context.setVariable("request.header.Content-Type", "application/xml");
		context.setVariable("request.verb","GET");
		context.setVariable("validation_content_type_header","application/vnd.vodafone.a42+json,application/json");
        expect(validationContentType()).toBe();
		expect(context.getVariable("errorJSON")).toBe(undefined);
	});
	it ('10: Positive: if Content-Type Header is valid', function() {
		context.setVariable("request.header.Content-Type", "application/vnd.vodafone.a42+json");
		context.setVariable("request.verb","POST");
		context.setVariable("validation_content_type_header","application/vnd.vodafone.a42+json,application/json");
        expect(validationContentType()).toBe();
		expect(context.getVariable("errorJSON")).toBe(undefined);
	});
	it ('11: Negative: if validation_content_type_header_patch variable is missing for PATCH Method', function() {
	    context.setVariable("request.header.Content-Type", "application/xml");
		context.setVariable("request.verb","PATCH");
		expect(validationContentType).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
	});
	it ('12: Negative: if validation_content_type_header variable is missing for POST Method', function() {
		context.setVariable("request.header.Content-Type", "application/vnd.vodafone.a42+json");
		context.setVariable("request.verb","POST");
		expect(validationContentType).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
	});

});
