/**
 * 
 */
var IoTSetACRRequestDetailsVar = require('../jsc/IOTSetACRRequestHeader/IoTSetACRRequestDetails');
describe('IoTSetACRRequestDetails Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });
     
    it ('Positive case1: ACRRequestPositive', function() {
        context.setVariable("accesstoken.market","DE");
        context.setVariable("accesstoken.msisdn","351912376060");
        context.setVariable("accesstoken.sub","ea85d16c-f338-4b22-91e5-219215ea9881");
       expect(setACRRequestHeaders()).toBe();
    });
  
    it ('Positive case1: ACRRequestPositive', function() {
        context.setVariable("accesstoken.market","NV");
        context.setVariable("accesstoken.msisdn","351912376060");
        context.setVariable("accesstoken.sub","ea85d16c-f338-4b22-91e5-219215ea9881");
       expect(setACRRequestHeaders()).toBe();
       context.setVariable("accesstoken.market","NV");
       expect(setACRRequestHeaders()).toBe();
    });
  
    
});