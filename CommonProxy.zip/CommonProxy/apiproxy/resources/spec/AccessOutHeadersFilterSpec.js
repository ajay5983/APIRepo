/**
 * 
 */
var AccessOutHeadersFilterVar = require('../jsc/AccessOutHeadersFilter/AccessOutHeadersFilter');
describe('AccessOutHeadersFilter Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            },
            removeVariable: function(propertyName){
                this[propertyName] = '';
              }
        };
        context = new Context();
    });
     
    it ('Positive: RemoveFewHeaders-few invalid', function()
	{
		context.setVariable("validation_out_headers","Content-Type, Host, Access-Control-Request-Headers, Accept");
		context.setVariable("response.headers.names","[ACcept, Access-Control-Request-Headers, Access-Control-Request-Method, Content-Length]");
		// context.setVariable("response.header.ACcept","ACcept");
		// context.setVariable("response.header.Access-Control-Request-Headers","Access-Control-Request-Headers");
		// context.setVariable("response.header.Access-Control-Request-Method","Access-Control-Request-Method");
		// context.setVariable("response.header.Content-Length","Content-Length");

		expect(AccessOutHeadersFilter()).toBe();

		// expect(context.getVariable("response.header.ACcept")).toBe("ACcept");
		// expect(context.getVariable("response.header.Access-Control-Request-Headers")).toBe("Access-Control-Request-Headers");
		// expect(context.getVariable("response.header.Access-Control-Request-Method")).toBe("");
		// expect(context.getVariable("response.header.Content-Length")).toBe("");
    }
	);
	it ('Positive: DontRemoveHeaders-all valid', function()
	{
		context.setVariable("validation_out_headers","Content-Type, Host, Access-Control-Request-Headers, Accept");
		context.setVariable("response.headers.names","[ACcept, Access-Control-Request-Headers]");
		context.setVariable("response.header.ACcept","ACcept");
		context.setVariable("response.header.Access-Control-Request-Headers","Access-Control-Request-Headers");

		expect(AccessOutHeadersFilter()).toBe();

		expect(context.getVariable("response.header.ACcept")).toBe("ACcept");
		expect(context.getVariable("response.header.Access-Control-Request-Headers")).toBe("Access-Control-Request-Headers");
    }
	);
	
	it ('Negative: Novalidation_out_headers', function()
	{
		context.setVariable("response.headers.names","[content-type, HOST, LocAtIon, accept, Origin, Access-Control-Request-Headers]");

		expect(AccessOutHeadersFilter).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    }
	);
	it ('Negative: Nullvalidation_out_headers', function()
	{
		context.setVariable("validation_out_headers","");
		context.setVariable("response.headers.names","[content-type, HOST, LocAtIon, accept, Origin, Access-Control-Request-Headers]");

		expect(AccessOutHeadersFilter).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    }
	);
	
	it ('Negative: No/NullHeaderList', function()
	{
		context.setVariable("response.headers.names","[]");
		context.setVariable("validation_out_headers","Content-Type, Host, Location, Accept");
		
		expect(AccessOutHeadersFilter()).toBe();
    }
	);
	
});