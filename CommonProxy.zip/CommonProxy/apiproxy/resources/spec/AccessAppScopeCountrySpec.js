/**
 * 
 */
var AccessAppScopeCountryVar = require('../jsc/AccessAppScopeCountry/AccessAppScopeCountry');
describe('AccessAppScopeCountry Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            },
            removeVariable: function(propertyName){
                this[propertyName] = '';
              }
        };
        context = new Context();
    });
    
	it ('Positive: Valid country PK with Scope5 Scope1 Scope3', function()
	{
		context.setVariable("countryISO","PK");
		context.setVariable("valid_scopes","Scope5 Scope1 Scope3");
		context.setVariable("access_scope_country_config",'{ "Scope1": [ "DE", "GB", "ES", "NL" ], "Scope2": [ "RO", "AL" ], "Scope3": [ "IN", "NP", "PK" ] }');

		expect(AccessAppScopeCountry()).toBe();

		expect(context.getVariable("errorJSON")).toBe(undefined);
    }
	);
	
	it ('Positive: Valid country RO with Scope5 Scope1 Scope3 Scope2', function()
	{
		context.setVariable("countryISO","RO");
		context.setVariable("valid_scopes","Scope5 Scope1 Scope3 Scope2");
		context.setVariable("access_scope_country_config",'{ "Scope1": [ "DE", "GB", "ES", "NL" ], "Scope2": [ "RO", "AL" ], "Scope3": [ "IN", "NP", "PK" ] }');

		expect(AccessAppScopeCountry()).toBe();

		expect(context.getVariable("errorJSON")).toBe(undefined);
    }
	);	
	
    it ('Positive: Valid country DE with Scope1', function()
	{
		context.setVariable("countryISO","DE");
		context.setVariable("valid_scopes","Scope1");
		context.setVariable("access_scope_country_config",'{ "Scope1": [ "DE", "GB", "ES", "NL", "RO", "AL" ], "Scope2": [ "GB", "ES", "NL", "RO", "AL" ], "Scope3": [ "DE", "GB", "ES", "NL", "RO", "AL" ] }');

		expect(AccessAppScopeCountry()).toBe();

		expect(context.getVariable("errorJSON")).toBe(undefined);
    }
	);
	it ('Positive: Valid country IN with Scope2', function()
	{
		context.setVariable("countryISO","IN");
		context.setVariable("valid_scopes","Scope2");
		context.setVariable("access_scope_country_config",'{ "Scope1": [ "DE", "GB", "ES", "NL", "RO", "AL" ], "Scope2": [ "GB", "ES", "NL", "IN", "AL" ], "Scope3": [ "DE", "GB", "ES", "NL", "RO", "AL" ] }');
		
		expect(AccessAppScopeCountry()).toBe();

		expect(context.getVariable("errorJSON")).toBe(undefined);
    }
	);
	
	it ('Positive: access_scope_country_config flowVar not found: allow the call', function()
	{
		context.setVariable("countryISO","DE");
		context.setVariable("valid_scopes","Scope2");
		//context.setVariable("access_scope_country_config",'{ "Scope1": [ "DE", "GB", "ES", "NL", "RO", "AL" ], "Scope2": [ "GB", "ES", "NL", "RO", "AL" ], "Scope3": [ "DE", "GB", "ES", "NL", "RO", "AL" ] }');
		
		expect(AccessAppScopeCountry()).toBe();

		expect(context.getVariable("errorJSON")).toBe(undefined);
    }
	);
	it ('Positive: access_scope_country_config flowVar empty: allow the call', function()
	{
		context.setVariable("countryISO","DE");
		context.setVariable("valid_scopes","Scope2");
		context.setVariable("access_scope_country_config",'');
		
		expect(AccessAppScopeCountry()).toBe();

		expect(context.getVariable("errorJSON")).toBe(undefined);
    }
	);

	it ('Positive: Valid country NL with Scope1 Scope2 Scope3', function()
	{
		context.setVariable("countryISO","NL");
		context.setVariable("valid_scopes","Scope1 Scope2 Scope3");
		context.setVariable("access_scope_country_config",'{ "Scope1": [ "DE", "GB", "ES", "NL", "RO", "AL" ], "Scope2": [ "GB", "ES", "", "IN", "AL" ], "Scope3": [ "DE", "GB", "ES", "RO", "AL" ] }');
		
		expect(AccessAppScopeCountry()).toBe();

		expect(context.getVariable("errorJSON")).toBe(undefined);
    }
	);
	it ('Positive: One Valid Scope3 & Valid country RO with Scope4 Scope3', function()
	{
		context.setVariable("countryISO","RO");
		context.setVariable("valid_scopes","Scope4 Scope3");
		context.setVariable("access_scope_country_config",'{ "Scope1": [ "DE", "GB", "ES", "NL", "PK", "AL" ], "Scope2": [ "GB", "ES", "NL", "IN", "AL" ], "Scope3": [ "DE", "GB", "ES", "NL", "RO", "AL" ] }');
		
		expect(AccessAppScopeCountry()).toBe();

		expect(context.getVariable("errorJSON")).toBe(undefined);
    }
	);
	
	it ('Positive: One Valid Scope2 & Valid country IN with Scope4 Scope5 Scope3', function()
	{
		context.setVariable("countryISO","IN");
		context.setVariable("valid_scopes","Scope4 Scope5 Scope2");
		context.setVariable("access_scope_country_config",'{ "Scope1": [ "DE", "GB", "ES", "NL", "PK", "AL" ], "Scope2": [ "GB", "ES", "NL", "IN", "AL" ], "Scope3": [ "DE", "GB", "ES", "NL", "RO", "AL" ] }');
		
		expect(AccessAppScopeCountry()).toBe();

		expect(context.getVariable("errorJSON")).toBe(undefined);
    }
	);
	
	it ('Positive: all flowVars not found', function()
	{
		//context.setVariable("countryISO","DE");
		//context.setVariable("valid_scopes","Scope2");
		//context.setVariable("access_scope_country_config",'{ "Scope1": [ "DE", "GB", "ES", "NL", "RO", "AL" ], "Scope2": [ "GB", "ES", "NL", "RO", "AL" ], "Scope3": [ "DE", "GB", "ES", "NL", "RO", "AL" ] }');
		
		expect(AccessAppScopeCountry()).toBe();

		expect(context.getVariable("errorJSON")).toBe(undefined);
    }
	);
	it ('Positive: all flowVars empty', function()
	{
		context.setVariable("countryISO","");
		context.setVariable("valid_scopes","");
		context.setVariable("access_scope_country_config",'');
		
		expect(AccessAppScopeCountry()).toBe();

		expect(context.getVariable("errorJSON")).toBe(undefined);
    }
	);	
	
	it ('Negative: Invalid country IN with Scope2', function()
	{
		context.setVariable("countryISO","IN");
		context.setVariable("valid_scopes","Scope2");
		context.setVariable("access_scope_country_config",'{ "Scope1": [ "DE", "GB", "ES", "NL", "RO", "AL" ], "Scope2": [ "GB", "ES", "NL", "RO", "AL" ], "Scope3": [ "DE", "GB", "ES", "NL", "RO", "AL" ] }');
		
		expect(AccessAppScopeCountry).toThrow();

		expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_country_id");
    }
	);
	it ('Negative: Invalid country E with Scope2', function()
	{
		context.setVariable("countryISO","E");
		context.setVariable("valid_scopes","Scope2");
		context.setVariable("access_scope_country_config",'{ "Scope1": [ "DE", "GB", "ES", "NL", "RO", "AL" ], "Scope2": [ "GB", "ES", "NL", "RO", "AL" ], "Scope3": [ "DE", "GB", "ES", "NL", "RO", "AL" ] }');
		
		expect(AccessAppScopeCountry).toThrow();

		expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_country_id");
    }
	);
	it ('Negative: Invalid country XX with Scope1', function()
	{
		context.setVariable("countryISO","XX");
		context.setVariable("valid_scopes","Scope2");
		context.setVariable("access_scope_country_config",'{ "Scope1": [ "DE", "GB", "ES", "NL", "RO", "AL" ], "Scope2": [ "GB", "ES", "NL", "RO", "AL" ], "Scope3": [ "DE", "GB", "ES", "NL", "RO", "AL" ] }');
		
		expect(AccessAppScopeCountry).toThrow();

		expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_country_id");
    }
	);
	
	it ('Negative: country flowVar not found', function()
	{
		//context.setVariable("countryISO","DE");
		context.setVariable("valid_scopes","Scope2");
		context.setVariable("access_scope_country_config",'{ "Scope1": [ "DE", "GB", "ES", "NL", "RO", "AL" ], "Scope2": [ "GB", "ES", "NL", "RO", "AL" ], "Scope3": [ "DE", "GB", "ES", "NL", "RO", "AL" ] }');
		
		expect(AccessAppScopeCountry).toThrow();

		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    }
	);
	it ('Negative: country flowVar empty', function()
	{
		context.setVariable("countryISO","");
		context.setVariable("valid_scopes","Scope2");
		context.setVariable("access_scope_country_config",'{ "Scope1": [ "DE", "GB", "ES", "NL", "RO", "AL" ], "Scope2": [ "GB", "ES", "NL", "RO", "AL" ], "Scope3": [ "DE", "GB", "ES", "NL", "RO", "AL" ] }');
		
		expect(AccessAppScopeCountry).toThrow();

		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    }
	);
	
	it ('Negative: scope flowVar not found', function()
	{
		context.setVariable("countryISO","DE");
		//context.setVariable("valid_scopes","Scope2");
		context.setVariable("access_scope_country_config",'{ "Scope1": [ "DE", "GB", "ES", "NL", "RO", "AL" ], "Scope2": [ "GB", "ES", "NL", "RO", "AL" ], "Scope3": [ "DE", "GB", "ES", "NL", "RO", "AL" ] }');
		
		expect(AccessAppScopeCountry).toThrow();

		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    }
	);
	it ('Negative: scope flowVar empty', function()
	{
		context.setVariable("countryISO","");
		context.setVariable("valid_scopes","");
		context.setVariable("access_scope_country_config",'{ "Scope1": [ "DE", "GB", "ES", "NL", "RO", "AL" ], "Scope2": [ "GB", "ES", "NL", "RO", "AL" ], "Scope3": [ "DE", "GB", "ES", "NL", "RO", "AL" ] }');
		
		expect(AccessAppScopeCountry).toThrow();

		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    }
	);	

	it ('Negative: Invalid scope Scope', function()
	{
		context.setVariable("countryISO","NL");
		context.setVariable("valid_scopese","Scope");
		context.setVariable("access_scope_country_config",'{ "Scope1": [ "DE", "GB", "ES", "NL", "RO", "AL" ], "Scope2": [ "GB", "ES", "NL", "IN", "AL" ], "Scope3": [ "DE", "GB", "ES", "NL", "RO", "AL" ] }');
		
		expect(AccessAppScopeCountry).toThrow();

		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    }
	);
	it ('Negative: Invalid scope Cope1', function()
	{
		context.setVariable("countryISO","NL");
		context.setVariable("valid_scopes","Cope1");
		context.setVariable("access_scope_country_config",'{ "Scope1": [ "DE", "GB", "ES", "NL", "RO", "AL" ], "Scope2": [ "GB", "ES", "NL", "IN", "AL" ], "Scope3": [ "DE", "GB", "ES", "NL", "RO", "AL" ] }');
		
		expect(AccessAppScopeCountry).toThrow();

		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    }
	);
	
	it ('Negative: Invalid scope Scope', function()
	{
		context.setVariable("countryISO","NL");
		context.setVariable("valid_scopes","Scope");
		context.setVariable("access_scope_country_config",'{ "Scope1": [ "DE", "GB", "ES", "NL", "RO", "AL" ], "Scope2": [ "GB", "ES", "NL", "IN", "AL" ], "Scope3": [ "DE", "GB", "ES", "NL", "RO", "AL" ] }');
		
		expect(AccessAppScopeCountry).toThrow();

		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    }
	);
	it ('Negative: Invalid scope Scope4 in Scope1 Scope2 Scope3', function()
	{
		context.setVariable("countryISO","NL");
		context.setVariable("valid_scopes","Scope4");
		context.setVariable("access_scope_country_config",'{ "Scope1": [ "DE", "GB", "ES", "NL", "RO", "AL" ], "Scope2": [ "GB", "ES", "NL", "IN", "AL" ], "Scope3": [ "DE", "GB", "ES", "NL", "RO", "AL" ] }');
		
		expect(AccessAppScopeCountry).toThrow();

		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    }
	);	
});