/**
 * 
 */
var PopulateErrorResponseVariablesabc = require('../jsc/PopulateErrorResponseVariables/PopulateErrorResponseVariables');
describe('NetworkHttpStatus Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });
     
    it ('Positive1: CustomisedErrorCase', function() {
        context.setVariable("fault.name","");
        context.setVariable("vf.trace.transaction.id","\"dcsdcs");
        context.setVariable("hypermedia_standard","a42");
        
        var errorJSON = { "statusCode": "500", "reasonPhrase": "Internal Server Error", "errorCode": "server_error", "errorDescription": "The authorization server encountered an unexpected condition that prevented it from fulfilling the request"};
        context.setVariable("errorJSON","a42_generic_internal_server_error");
        context.setVariable("a42_generic_internal_server_error",JSON.stringify(errorJSON));
       expect(populateErrorResponseVariables()).toBe();
       expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_server_error");
    });
    it ('Positive2: APIGEEFaultcase1', function() {
        context.setVariable("fault.name","InvalidAPICallAsNoApiProductMatchFound");
        context.setVariable("vf.trace.transaction.id","dcsdcs");
        context.setVariable("hypermedia_standard","a42");
        
        var errorJSON = {"statusCode":"400","reasonPhrase":"Bad Request","errorCode":"invalid_client","errorDescription":"missing or invalid client_id or client_secret"};
        context.setVariable("errorJSON","");
        context.setVariable("a42_generic_unauthorized_app_for_api",JSON.stringify(errorJSON));
       expect(populateErrorResponseVariables()).toBe();
       expect(context.getVariable("reasonPhrase")).toBe("Bad Request");
       expect(context.getVariable("description")).toBe("missing or invalid client_id or client_secret");
       expect(context.getVariable("errMessage")).toBe("invalid_client");
       expect(context.getVariable("statusCode")).toBe('400');
    }); 
    it ('Positive3: APIGEEFaultcase2', function() {
        context.setVariable("fault.name","InvalidClientIdForGivenResource");
        context.setVariable("vf.trace.transaction.id","dcsdcs");
        context.setVariable("hypermedia_standard","a42");
        
        var errorJSON = {"statusCode":"400","reasonPhrase":"Bad Request","errorCode":"invalid_scope","errorDescription":"missing or invalid scope"};
        context.setVariable("errorJSON","");
        context.setVariable("a42_oauth_scope_missing_invalid",JSON.stringify(errorJSON));
       expect(populateErrorResponseVariables()).toBe();
       expect(context.getVariable("reasonPhrase")).toBe("Bad Request");
       expect(context.getVariable("description")).toBe("missing or invalid scope");
       expect(context.getVariable("errMessage")).toBe("invalid_scope");
       expect(context.getVariable("statusCode")).toBe('400');
    });
    it ('Positive4: APIGEEFaultcase4', function() {
        context.setVariable("fault.name","invalid_access_token");
        context.setVariable("vf.trace.transaction.id","dcsdcs");
        context.setVariable("hypermedia_standard","a42");
        
        var errorJSON = {"statusCode":"401","reasonPhrase":"Unauthorized","errorCode":"invalid_token","errorDescription":"The access token is invalid"};
        context.setVariable("errorJSON","");
        context.setVariable("a42_generic_invalid_access_token",JSON.stringify(errorJSON));
       expect(populateErrorResponseVariables()).toBe();
       expect(context.getVariable("reasonPhrase")).toBe("Unauthorized");
       expect(context.getVariable("description")).toBe("The access token is invalid");
       expect(context.getVariable("errMessage")).toBe("invalid_token");
       expect(context.getVariable("statusCode")).toBe('401');
    });
    it ('Positive5: APIGEEFaultcase5', function() {
        context.setVariable("fault.name","InvalidBasicAuthenticationSource");
        context.setVariable("vf.trace.transaction.id","dcsdcs");
        context.setVariable("hypermedia_standard","a42");
        
        var errorJSON = {"statusCode":"401","reasonPhrase":"Unauthorized","errorCode":"access_denied","errorDescription":"Service Error - Invalid Authorization header"};
        context.setVariable("errorJSON","");
        context.setVariable("a42_generic_invalid_authorization_header",JSON.stringify(errorJSON));
       expect(populateErrorResponseVariables()).toBe();
       expect(context.getVariable("reasonPhrase")).toBe("Unauthorized");
       expect(context.getVariable("description")).toBe("Service Error - Invalid Authorization header");
       expect(context.getVariable("errMessage")).toBe("access_denied");
       expect(context.getVariable("statusCode")).toBe('401');
    });
    it ('Positive6: APIGEEFaultcase6', function() {
        context.setVariable("fault.name","access_token_expired");
        context.setVariable("vf.trace.transaction.id","dcsdcs");
        context.setVariable("hypermedia_standard","a42");
        
        var errorJSON = {"statusCode":"401","reasonPhrase":"Unauthorized","errorCode":"invalid_token","errorDescription":"The access token expired"};
        context.setVariable("errorJSON","");
        context.setVariable("a42_generic_expired_access_token",JSON.stringify(errorJSON));
       expect(populateErrorResponseVariables()).toBe();
       expect(context.getVariable("reasonPhrase")).toBe("Unauthorized");
       expect(context.getVariable("description")).toBe("The access token expired");
       expect(context.getVariable("errMessage")).toBe("invalid_token");
       expect(context.getVariable("statusCode")).toBe('401');
    });
    it ('Positive7: APIGEEFaultcase7', function() {
        context.setVariable("fault.name","access_token_not_approved");
        context.setVariable("vf.trace.transaction.id","dcsdcs");
        context.setVariable("hypermedia_standard","a42");
        
        var errorJSON = {"statusCode":"401","reasonPhrase":"Unauthorized","errorCode":"invalid_token","errorDescription":"The access token has been revoked"};
        context.setVariable("errorJSON","");
        context.setVariable("a42_generic_revoked_access_token",JSON.stringify(errorJSON));
       expect(populateErrorResponseVariables()).toBe();
       expect(context.getVariable("reasonPhrase")).toBe("Unauthorized");
       expect(context.getVariable("description")).toBe("The access token has been revoked");
       expect(context.getVariable("errMessage")).toBe("invalid_token");
       expect(context.getVariable("statusCode")).toBe('401');
    });
    it ('Positive8: APIGEEFaultcase8', function() {
        context.setVariable("fault.name","SpikeArrestViolation");
        context.setVariable("vf.trace.transaction.id","dcsdcs");
        context.setVariable("hypermedia_standard","a42");
        
        var errorJSON = {"statusCode":"429","reasonPhrase":"Bad Request","errorCode":"Too Many Requests","errorDescription":"Spike arrest violation"};
        context.setVariable("errorJSON","");
        context.setVariable("a42_generic_spike_arrest_violation",JSON.stringify(errorJSON));
       expect(populateErrorResponseVariables()).toBe();
       expect(context.getVariable("reasonPhrase")).toBe("Bad Request");
       expect(context.getVariable("description")).toBe("Spike arrest violation");
       expect(context.getVariable("errMessage")).toBe("Too Many Requests");
       expect(context.getVariable("statusCode")).toBe('429');
    });
    it ('Positive9: APIGEEFaultcase9', function() {
        context.setVariable("fault.name","QuotaViolation");
        context.setVariable("vf.trace.transaction.id","dcsdcs");
        context.setVariable("hypermedia_standard","a42");
        
        var errorJSON = {"statusCode":"429","reasonPhrase":"Bad Request","errorCode":"Too Many Requests","errorDescription":"App Quota limit reached"};
        context.setVariable("errorJSON","");
        context.setVariable("a42_generic_quota_limit_reached",JSON.stringify(errorJSON));
       expect(populateErrorResponseVariables()).toBe();
       expect(context.getVariable("reasonPhrase")).toBe("Bad Request");
       expect(context.getVariable("description")).toBe("App Quota limit reached");
       expect(context.getVariable("errMessage")).toBe("Too Many Requests");
       expect(context.getVariable("statusCode")).toBe('429');
    });
    it ('Positive10: APIGEEFaultcase10', function() {
        context.setVariable("fault.name","JsonPathParsingFailure");
        context.setVariable("vf.trace.transaction.id","dcsdcs");
        context.setVariable("hypermedia_standard","a42");
        
        var errorJSON = {"statusCode":"400","reasonPhrase":"Bad Request","errorCode":"invalid_request","errorDescription":"The request payload is not in a valid JSON format"};
        context.setVariable("errorJSON","");
        context.setVariable("a42_generic_invalid_json_format",JSON.stringify(errorJSON));
       expect(populateErrorResponseVariables()).toBe();
       expect(context.getVariable("reasonPhrase")).toBe("Bad Request");
       expect(context.getVariable("description")).toBe("The request payload is not in a valid JSON format");
       expect(context.getVariable("errMessage")).toBe("invalid_request");
       expect(context.getVariable("statusCode")).toBe('400');
    });
    it ('Defult: Case1', function() {
        context.setVariable("fault.name","");
        context.setVariable("vf.trace.transaction.id","dcsdcs");
        context.setVariable("hypermedia_standard","a42");
        context.setVariable("errorJSON","");
       expect(populateErrorResponseVariables()).toBe();
       expect(context.getVariable("reasonPhrase")).toBe("Internal Server Error");
       expect(context.getVariable("description")).toBe("The authorization server encountered an unexpected condition that prevented it from fulfilling the request");
       expect(context.getVariable("errMessage")).toBe("server_error");
       expect(context.getVariable("statusCode")).toBe('500');
    });
    it ('Defult: Case2', function() {
        context.setVariable("fault.name","InvalidAPICallAsNoApiProductMatchFound");
        context.setVariable("vf.trace.transaction.id","dcsdcs");
        context.setVariable("hypermedia_standard","");
        context.setVariable("errorJSON","");
        context.setVariable("oauth_unauthorized_client","");
       expect(populateErrorResponseVariables()).toBe();
       expect(context.getVariable("reasonPhrase")).toBe("Internal Server Error");
       expect(context.getVariable("description")).toBe("The authorization server encountered an unexpected condition that prevented it from fulfilling the request");
       expect(context.getVariable("errMessage")).toBe("server_error");
       expect(context.getVariable("statusCode")).toBe('500');
    });
    it ('Defult: Case3', function() {
        context.setVariable("fault.name","InvalidAPICallAsNoApiProductMatchFound");
        context.setVariable("vf.trace.transaction.id","dcsdcs");
        context.setVariable("hypermedia_standard","a42");
        context.setVariable("errorJSON","");
        context.setVariable("a42_oauth_unauthorized_client","");
       expect(populateErrorResponseVariables()).toBe();
       expect(context.getVariable("reasonPhrase")).toBe("Internal Server Error");
       expect(context.getVariable("description")).toBe("The authorization server encountered an unexpected condition that prevented it from fulfilling the request");
       expect(context.getVariable("errMessage")).toBe("server_error");
       expect(context.getVariable("statusCode")).toBe('500');
    });
    it ('Defult: Case4', function() {
        context.setVariable("fault.name","");
        context.setVariable("vf.trace.transaction.id","dcsdcs");
        context.setVariable("hypermedia_standard","a42");
	    
		var errorJSON = { "statusCode": "400", "reasonPhrase": "Bad Request", "errorCode": "invalid_request", "errorDescription": "The request is missing the mandatory parameter" };		
        
        context.setVariable("errorJSON","a42_generic_missing_request_parameter");
		context.setVariable("request_param","Param1");
        context.setVariable("a42_generic_missing_request_parameter",JSON.stringify(errorJSON));
       expect(populateErrorResponseVariables()).toBe();
       expect(context.getVariable("reasonPhrase")).toBe("Bad Request");
       expect(context.getVariable("description")).toBe("The request is missing the mandatory parameter Param1");
       expect(context.getVariable("errMessage")).toBe("invalid_request");
       expect(context.getVariable("statusCode")).toBe('400');
        context.setVariable("errorJSON","a42_generic_missing_request_parameter");
    });	
    it ('Defult: Case5', function() {
        context.setVariable("fault.name","");
        context.setVariable("vf.trace.transaction.id","dcsdcs");
        context.setVariable("hypermedia_standard","a42");
	    
		var errorJSON = { "statusCode": "400", "reasonPhrase": "Bad Request", "errorCode": "invalid_request", "errorDescription": "The request parameter is invalid" };		
        
        context.setVariable("errorJSON","a42_generic_invalid_request_parameter");
		context.setVariable("request_param","Param1");
        context.setVariable("a42_generic_invalid_request_parameter",JSON.stringify(errorJSON));
       expect(populateErrorResponseVariables()).toBe();
       expect(context.getVariable("reasonPhrase")).toBe("Bad Request");
       expect(context.getVariable("description")).toBe("The request parameter Param1 is invalid");
       expect(context.getVariable("errMessage")).toBe("invalid_request");
       expect(context.getVariable("statusCode")).toBe('400');
        context.setVariable("errorJSON","a42_generic_invalid_request_parameter");
    });		
    it ('Defult: Case6', function() {
        context.setVariable("fault.name","");
        context.setVariable("vf.trace.transaction.id","dcsdcs");
        context.setVariable("hypermedia_standard","a42");
	    
		var errorJSON = { "statusCode": "400", "reasonPhrase": "Bad Request", "errorCode": "invalid_request", "errorDescription": "The request is missing the mandatory request header" };		
        
        context.setVariable("errorJSON","a42_generic_missing_request_header");
		context.setVariable("request_header","Content-Type");
        context.setVariable("a42_generic_missing_request_header",JSON.stringify(errorJSON));
       expect(populateErrorResponseVariables()).toBe();
       expect(context.getVariable("reasonPhrase")).toBe("Bad Request");
       expect(context.getVariable("description")).toBe("The request is missing the mandatory request header Content-Type");
       expect(context.getVariable("errMessage")).toBe("invalid_request");
       expect(context.getVariable("statusCode")).toBe('400');
        context.setVariable("errorJSON","a42_generic_missing_request_header");
    });	
    it ('Defult: Case7', function() {
        context.setVariable("fault.name","");
        context.setVariable("vf.trace.transaction.id","dcsdcs");
        context.setVariable("hypermedia_standard","a42");
	    
		var errorJSON = { "statusCode": "400", "reasonPhrase": "Bad Request", "errorCode": "invalid_request", "errorDescription": "The request header is invalid" };		
        
        context.setVariable("errorJSON","a42_generic_invalid_request_header");
		context.setVariable("request_header","Content-Type");
        context.setVariable("a42_generic_invalid_request_header",JSON.stringify(errorJSON));
       expect(populateErrorResponseVariables()).toBe();
       expect(context.getVariable("reasonPhrase")).toBe("Bad Request");
       expect(context.getVariable("description")).toBe("The request header Content-Type is invalid");
       expect(context.getVariable("errMessage")).toBe("invalid_request");
       expect(context.getVariable("statusCode")).toBe('400');
        context.setVariable("errorJSON","a42_generic_invalid_request_header");
    });		
    it ('Defult: Case8: CustomisedErrorCase', function() {
        context.setVariable("fault.name","");
        context.setVariable("vf.trace.transaction.id","dcsdcs");
        context.setVariable("hypermedia_standard","a42");
        
        context.setVariable("errorJSON","a42_generic_internal_server_error");
        context.setVariable("a42_generic_internal_server_error","");
       expect(populateErrorResponseVariables()).toBe();
       expect(context.getVariable("reasonPhrase")).toBe("Internal Server Error");
       expect(context.getVariable("description")).toBe("The authorization server encountered an unexpected condition that prevented it from fulfilling the request");
       expect(context.getVariable("errMessage")).toBe("server_error");
       expect(context.getVariable("statusCode")).toBe('500');
    });
	    it ('Defult:case 9: 502 error code', function() {
        context.setVariable("fault.name","");
        context.setVariable("vf.trace.transaction.id","dcsdcs");
        context.setVariable("hypermedia_standard","a42");
        context.setVariable("message.status.code",502);
		var errorJSON = { "statusCode": "502", "reasonPhrase": "Bad Gateway", "errorCode": "invalid_request", "errorDescription": "The request parameter is invalid" };		
        context.setVariable("a42_generic_bad_gateway",JSON.stringify(errorJSON));
		expect(populateErrorResponseVariables()).toBe();
		expect(context.getVariable("reasonPhrase")).toBe("Bad Gateway");
		expect(context.getVariable("description")).toBe("The request parameter is invalid");
		expect(context.getVariable("errMessage")).toBe("invalid_request");
		expect(context.getVariable("statusCode")).toBe('502');
    });
	    it ('Defult:case 10: 503 error code', function() {
        context.setVariable("fault.name","");
        context.setVariable("vf.trace.transaction.id","dcsdcs");
        context.setVariable("hypermedia_standard","a42");
        context.setVariable("message.status.code",503);
		var errorJSON = { "statusCode": "503", "reasonPhrase": "Service Unavailable", "errorCode": "invalid_request", "errorDescription": "The request parameter is invalid" };		
        context.setVariable("a42_generic_service_unavailable",JSON.stringify(errorJSON));
		expect(populateErrorResponseVariables()).toBe();
		expect(context.getVariable("reasonPhrase")).toBe("Service Unavailable");
		expect(context.getVariable("description")).toBe("The request parameter is invalid");
		expect(context.getVariable("errMessage")).toBe("invalid_request");
		expect(context.getVariable("statusCode")).toBe('503');
    });
	    it ('Defult:case 11: 504 error code', function() {
        context.setVariable("fault.name","");
        context.setVariable("vf.trace.transaction.id","dcsdcs");
        context.setVariable("hypermedia_standard","a42");
        context.setVariable("message.status.code",504);
		var errorJSON = { "statusCode": "504", "reasonPhrase": "Gateway Timeout", "errorCode": "invalid_request", "errorDescription": "The request parameter is invalid" };		
        context.setVariable("a42_generic_gateway_timeout",JSON.stringify(errorJSON));
		expect(populateErrorResponseVariables()).toBe();
		expect(context.getVariable("reasonPhrase")).toBe("Gateway Timeout");
		expect(context.getVariable("description")).toBe("The request parameter is invalid");
		expect(context.getVariable("errMessage")).toBe("invalid_request");
		expect(context.getVariable("statusCode")).toBe('504');
    });
	    it ('Defult:case 12: errorJSON not set', function() {
        context.setVariable("fault.name","");
		context.setVariable("errorJSON","");
        context.setVariable("vf.trace.transaction.id","dcsdcs");
        context.setVariable("hypermedia_standard","a42");
        context.setVariable("message.status.code",504);
		expect(populateErrorResponseVariables()).toBe();
    });
});