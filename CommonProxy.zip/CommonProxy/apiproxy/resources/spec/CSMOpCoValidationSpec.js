require('../jsc/CSMOpCoValidation/CSMOpCoValidation');
describe('CSMOpCoValidation Suite', function() {
    beforeEach(function(){
      var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
           
        };
        context = new Context();
    });


    it('Positive: Check OpCo', function () {
        context.setVariable("request.header.vf-country-code", "GB");
        expect(CSMOpCoValidationTest()).toBe();
    });
    
     it('Negative: Check shareCode', function () {
         context.setVariable("request.header.vf-country-code", "");
        expect(CSMOpCoValidationTest).toThrow();
    });
  	
});
