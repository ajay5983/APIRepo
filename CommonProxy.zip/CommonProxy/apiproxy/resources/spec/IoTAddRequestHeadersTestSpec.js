/**
 * 
 */
var accessCountryApiVar = require('../jsc/IOTAddRequestHeaders/IoTAddRequestHeaders');
describe('IoTAddRequestHeaders Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });
     
    it ('Positive case1: AddReuqestHeaders', function() {
        context.setVariable("anon_cust_ref","262002STATRSV2017-12-05T08:45:06ZIODhkxcGYGsb0F4B2JyvXEuns");
        context.setVariable("msisdnCountry","49");
        expect(addRequestHeaders()).toBe();
        expect(context.getVariable("request.header.Acr")).toBe("262002STATRSV2017-12-05T08:45:06ZIODhkxcGYGsb0F4B2JyvXEuns");
    });
    it ('Negative case1: AddReuqestHeaders', function() {
        expect(addRequestHeaders()).toBe();
        expect(context.getVariable("request.header.Acr")).toBe(undefined);
    });
});