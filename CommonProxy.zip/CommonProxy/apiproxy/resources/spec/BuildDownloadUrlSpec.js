/**
 * 
 */
var retrieve_download_url = require('../jsc/BuildDownloadUrl/BuildDownloadUrl');
describe('Build Download Url', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });
     
    it ('Positive case1: Build Download Url', function() {
        context.setVariable("APIXEndpoint","apidev.developer.vodafone.com");
		context.setVariable("sha2codeArray","815e2aacda0cbdd39898641c46b7b3cc9cafb0cfc16458015951696017ddea12,c89a148be40e6752261e3038609a4b68de22fa3bfdaf32f884edffb8480b9bbe,f6607633d460e27d6c38bc0ff4405654d04df4de2340b65d0a67f37a88fa7393");
		context.setVariable("accesstoken.scope","PAYMENT_CUSTOMER_BILL_ALL CUSTOMER_CUSTOMER_ACCOUNT_GET SUBSCRIPTION_SUBSCRIPTION_GET DOWNLOAD_ALL");
	    context.setVariable("access_token","**********");
		context.setVariable("expires_in","123456");
	
		expect(buildDownloadUrl()).toBe();
	
		expect(context.getVariable("downloadUrl")).toBe("https://apidev.developer.vodafone.com/v1/download/815e2aacda0cbdd39898641c46b7b3cc9cafb0cfc16458015951696017ddea12,https://apidev.developer.vodafone.com/v1/download/c89a148be40e6752261e3038609a4b68de22fa3bfdaf32f884edffb8480b9bbe,https://apidev.developer.vodafone.com/v1/download/f6607633d460e27d6c38bc0ff4405654d04df4de2340b65d0a67f37a88fa7393");
    });
	
	it ('Positive case2: Build Download Url, with some shacode is empty in between', function() {
        context.setVariable("APIXEndpoint","apidev.developer.vodafone.com");
		context.setVariable("sha2codeArray","815e2aacda0cbdd39898641c46b7b3cc9cafb0cfc16458015951696017ddea12,,f6607633d460e27d6c38bc0ff4405654d04df4de2340b65d0a67f37a88fa7393");
		context.setVariable("accesstoken.scope","PAYMENT_CUSTOMER_BILL_ALL CUSTOMER_CUSTOMER_ACCOUNT_GET SUBSCRIPTION_SUBSCRIPTION_GET DOWNLOAD_ALL");
	    context.setVariable("access_token","**********");
	
		expect(buildDownloadUrl()).toBe();
	
		expect(context.getVariable("downloadUrl")).toBe("https://apidev.developer.vodafone.com/v1/download/815e2aacda0cbdd39898641c46b7b3cc9cafb0cfc16458015951696017ddea12,,https://apidev.developer.vodafone.com/v1/download/f6607633d460e27d6c38bc0ff4405654d04df4de2340b65d0a67f37a88fa7393");
    });
	
	it ('Positive case3: Build Download Url', function() {
        context.setVariable("APIXEndPoint","apidev.developer.vodafone.com");
		context.setVariable("sha2codeArray","");
		context.setVariable("accesstoken.scope","PAYMENT_CUSTOMER_BILL_ALL CUSTOMER_CUSTOMER_ACCOUNT_GET SUBSCRIPTION_SUBSCRIPTION_GET");
		expect(buildDownloadUrl()).toBe();
		expect(context.getVariable("downloadUrl")).toBe("");
    });
	
    
});