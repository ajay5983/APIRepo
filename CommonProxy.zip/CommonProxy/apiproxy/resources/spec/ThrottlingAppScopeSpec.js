/**
 * 
 */
var ThrottlingAppScopeVar = require('../jsc/ThrottlingAppScope/ThrottlingAppScope');
describe('ThrottlingAppScope Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            },
            removeVariable: function(propertyName){
                this[propertyName] = '';
              }
        };
        context = new Context();
    });
     
    it ('Positive: Valid Scope Scope1', function()
	{
		context.setVariable("valid_scopes","Scope1");
		context.setVariable("throttling_scope_config",'{ "Scope1": "100", "Scope2": "200", "Scope3": "", "Default": "150" }');

		expect(ThrottlingAppScope()).toBe();

		expect(context.getVariable("quota")).toBe("100");
		expect(context.getVariable("doNotApplyQuota")).toBe(false);
    }
	);
	it ('Positive: Multiple Valid Scopes Scope2 Scope1', function()
	{
		context.setVariable("valid_scopes","Scope2 Scope1");
		context.setVariable("throttling_scope_config",'{ "Scope1": "100", "Scope2": "200", "Scope3": "", "Default": "150" }');
		
		expect(ThrottlingAppScope()).toBe();

		expect(context.getVariable("quota")).toBe("200");
		expect(context.getVariable("doNotApplyQuota")).toBe(false);
    }
	);
	it ('Positive: At-least One Valid Scope Scope5 Scope1 Scope2', function()
	{
		context.setVariable("valid_scopes","Scope5 Scope1 Scope2");
		context.setVariable("throttling_scope_config",'{ "Scope1": "100", "Scope2": "200", "Scope3": "", "Default": "150" }');
		
		expect(ThrottlingAppScope()).toBe();

		expect(context.getVariable("quota")).toBe("100");
		expect(context.getVariable("doNotApplyQuota")).toBe(false);
    }
	);
	
	it ('Positive: At-least One Valid Scope Scope3 Scope1 Scope2', function()
	{
		context.setVariable("valid_scopes","Scope3 Scope1 Scope2");
		context.setVariable("throttling_scope_config",'{ "Scope1": "100", "Scope2": "200", "Scope3": "", "Default": "150" }');
		
		expect(ThrottlingAppScope()).toBe();

		expect(context.getVariable("quota")).toBe("150");
		expect(context.getVariable("doNotApplyQuota")).toBe(false);
    }
	);
	it ('Positive: At-least One Valid Scope Scope1 Scope3', function()
	{
		context.setVariable("valid_scopes","Scope1 Scope3");
		context.setVariable("throttling_scope_config",'{ "Scope1": "100", "Scope2": "200", "Scope3": "", "Default": "150" }');
		
		expect(ThrottlingAppScope()).toBe();

		expect(context.getVariable("quota")).toBe("100");
		expect(context.getVariable("doNotApplyQuota")).toBe(false);
    }
	);
	it ('Positive: Invalid Scope Scope11 Scope 22 : Default Value to be taken', function()
	{
		context.setVariable("valid_scopes","Scope11 Scope 22");
		context.setVariable("throttling_scope_config",'{ "Scope1": "100", "Scope2": "200", "Scope3": "", "Default": "150" }');
		
		expect(ThrottlingAppScope()).toBe();

		expect(context.getVariable("quota")).toBe("150");
		expect(context.getVariable("doNotApplyQuota")).toBe(false);
    }
	);
	
	it ('Positive: scope flowVar not found: Default case', function()
	{
		
		//context.setVariable("valid_scopes","Scope2");
		context.setVariable("throttling_scope_config",'{ "Scope1": "100", "Scope2": "200", "Scope3": "", "Default": "150" }');
		
		expect(ThrottlingAppScope()).toBe();
		
		expect(context.getVariable("quota")).toBe("150");
		expect(context.getVariable("doNotApplyQuota")).toBe(false);
    }
	);
	it ('Positive: scope flowVar empty: Default case', function()
	{
		context.setVariable("valid_scopes","");
		context.setVariable("throttling_scope_config",'{ "Scope1": "100", "Scope2": "200", "Scope3": "", "Default": "150" }');
		
		expect(ThrottlingAppScope()).toBe();
		
		expect(context.getVariable("quota")).toBe("150");
		expect(context.getVariable("doNotApplyQuota")).toBe(false);
    }
	);	
	
	it ('Negative: throttling_scope_config flowVar not found : doNotApplyQuota true', function()
	{
		
		context.setVariable("valid_scopes","Scope2");
		//context.setVariable("throttling_scope_config",'{ "Scope1": "100", "Scope2": "200", "Scope3": "", "Default": "150" }');
		
		expect(ThrottlingAppScope()).toBe();

		expect(context.getVariable("quota")).toBe(undefined);
		expect(context.getVariable("doNotApplyQuota")).toBe(true);
    }
	);
	it ('Negative: throttling_scope_config flowVar empty : doNotApplyQuota true', function()
	{
		
		context.setVariable("valid_scopes","Scope2");
		context.setVariable("throttling_scope_config",'');
		
		expect(ThrottlingAppScope()).toBe();

		expect(context.getVariable("quota")).toBe(undefined);
		expect(context.getVariable("doNotApplyQuota")).toBe(true);
    }
	);
	
	it ('Negative: all flowVars not found: doNotApplyQuota true', function()
	{
		//context.setVariable("valid_scopes","Scope2");
		//context.setVariable("throttling_scope_config",'{ "Scope1": "100", "Scope2": "200", "Scope3": "", "Default": "150" }');
		
		expect(ThrottlingAppScope()).toBe();
		
		expect(context.getVariable("quota")).toBe(undefined);
		expect(context.getVariable("doNotApplyQuota")).toBe(true);
    }
	);
	it ('Negative: all flowVars empty: doNotApplyQuota: true', function()
	{
		context.setVariable("valid_scopes","");
		context.setVariable("throttling_scope_config","");
		
		expect(ThrottlingAppScope()).toBe();
		
		expect(context.getVariable("quota")).toBe(undefined);
		expect(context.getVariable("doNotApplyQuota")).toBe(true);
    }
	);	
});