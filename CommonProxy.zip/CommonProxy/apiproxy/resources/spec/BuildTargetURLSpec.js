var BuildTargetURLTest = require('../jsc/BuildTargetURL/BuildTargetURL');
describe('BuildTargetURL Suite', function() {
    beforeEach(function(){
      var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });
    it ('Positive case 1: TargetURL Verification for default Target for ES country', function() {
		context.setVariable("proxy.pathsuffix","/");
		context.setVariable("environment_targets_endpoint_properties",'{"aws-test-es":{"GetCustomerAccountList":{"TARGET_HOST":"accountservice-es-test.myvdf.aws.cps.vodafone.com","TARGET_PORT":"443","TARGET_PATH":"/es/v1/apiPath","TARGET_ENABLED":true,"TARGET_SSL_ENABLED":true,"TARGET_SSL_CIPHERS":"","TARGET_SSL_CLIENT_AUTH_ENABLED":false,"TARGET_SSL_KEY_STORE":"","TARGET_SSL_KEY_ALIAS":"","TARGET_SSL_TRUST_STORE":"","TARGET_SSL_PROTOCOLS":"","TARGET_SSL_IGNORE_VALIDATION_ERRORS":false}},"apix_aws_stubs":{"GetCustomerAccountList":{"TARGET_HOST":"apix.master.centralqa.de","TARGET_PORT":"443","TARGET_PATH":"/es/v1/apiPath","TARGET_ENABLED":true,"TARGET_SSL_ENABLED":true,"TARGET_SSL_CIPHERS":"","TARGET_SSL_CLIENT_AUTH_ENABLED":false,"TARGET_SSL_KEY_STORE":"","TARGET_SSL_KEY_ALIAS":"","TARGET_SSL_TRUST_STORE":"","TARGET_SSL_PROTOCOLS":"","TARGET_SSL_IGNORE_VALIDATION_ERRORS":false}}}');
		context.setVariable("environment.name","dev");
		context.setVariable("request.verb","GET");
		context.setVariable("env_target_valid_enviroment","dev,testing,staging,stagingref");
		context.setVariable("countryISO","ES");
		context.setVariable("currentFlowName","GetCustomerAccountList");
		context.setVariable("defaultTargetES","aws-test-es");
        expect(buildTargetUrl()).toBe();
		expect(context.getVariable("target.url")).toBe("https://accountservice-es-test.myvdf.aws.cps.vodafone.com:443/es/v1/apiPath/");
        expect(context.getVariable("errorJSON")).toBe(undefined);
    });
    it ('Positive case 2: TargetURL Verification', function() {
		context.setVariable("environment_targets_endpoint_properties",'{"aws-test-es":{"GetCustomerAccountList":{"TARGET_HOST":"accountservice-es-test.myvdf.aws.cps.vodafone.com","TARGET_PORT":"443","TARGET_PATH":"/es/v1/apiPath","TARGET_ENABLED":true,"TARGET_SSL_ENABLED":true,"TARGET_SSL_CIPHERS":"","TARGET_SSL_CLIENT_AUTH_ENABLED":false,"TARGET_SSL_KEY_STORE":"","TARGET_SSL_KEY_ALIAS":"","TARGET_SSL_TRUST_STORE":"","TARGET_SSL_PROTOCOLS":"","TARGET_SSL_IGNORE_VALIDATION_ERRORS":false}},"apix_aws_stubs":{"GetCustomerAccountList":{"TARGET_HOST":"apix.master.centralqa.de","TARGET_PORT":"443","TARGET_PATH":"/es/v1/apiPath","TARGET_ENABLED":true,"TARGET_SSL_ENABLED":true,"TARGET_SSL_CIPHERS":"","TARGET_SSL_CLIENT_AUTH_ENABLED":false,"TARGET_SSL_KEY_STORE":"","TARGET_SSL_KEY_ALIAS":"","TARGET_SSL_TRUST_STORE":"","TARGET_SSL_PROTOCOLS":"","TARGET_SSL_IGNORE_VALIDATION_ERRORS":false}}}');
		context.setVariable("environment.name","dev");
		context.setVariable("proxy.pathsuffix","/");
		context.setVariable("request.querystring","id=123");
		context.setVariable("request.header.vf-target-environment","aws-test-es");
		context.setVariable("request.verb","GET");
		context.setVariable("env_target_valid_enviroment","dev,testing,staging,stagingref");
		context.setVariable("countryISO","ES");
		context.setVariable("currentFlowName","GetCustomerAccountList");
        expect(buildTargetUrl()).toBe();
		expect(context.getVariable("target.url")).toBe("https://accountservice-es-test.myvdf.aws.cps.vodafone.com:443/es/v1/apiPath/?id=123");
    });
    it ('Negative case 3: targets_endpoint_properties is blank', function() {
		context.setVariable("a42_generic_internal_config_error","The service is currently not available. Please try again later");
		context.setVariable("env_target_valid_enviroment","dev,testing,staging,stagingref");
		context.setVariable("currentFlowName","GetCustomerAccountList");
	    expect(buildTargetUrl).toThrow();
        expect(context.getVariable("errorJSON")).toBe('a42_generic_internal_config_error');
    });
    it ('Negative case 4: catch exception', function() {
		context.setVariable("environment_targets_endpoint_properties",'{"aws-test-es":{"GetCustomerAccountList":{"TARGET_HOST":"accountservice-es-test.myvdf.aws.cps.vodafone.com","TARGET_PORT":"443","TARGET_PATH":"/es/v1/apiPath","TARGET_ENABLED":true,"TARGET_SSL_ENABLED":true,"TARGET_SSL_CIPHERS":"","TARGET_SSL_CLIENT_AUTH_ENABLED":false,"TARGET_SSL_KEY_STORE":"","TARGET_SSL_KEY_ALIAS":"","TARGET_SSL_TRUST_STORE":"","TARGET_SSL_PROTOCOLS":"","TARGET_SSL_IGNORE_VALIDATION_ERRORS":false}},"apix_aws_stubs":{"GetCustomerAccountList":{"TARGET_HOST":"apix.master.centralqa.de","TARGET_PORT":"443","TARGET_PATH":"/es/v1/apiPath","TARGET_ENABLED":true,"TARGET_SSL_ENABLED":true,"TARGET_SSL_CIPHERS":"","TARGET_SSL_CLIENT_AUTH_ENABLED":false,"TARGET_SSL_KEY_STORE":"","TARGET_SSL_KEY_ALIAS":"","TARGET_SSL_TRUST_STORE":"","TARGET_SSL_PROTOCOLS":"","TARGET_SSL_IGNORE_VALIDATION_ERRORS":false}}}');
		context.setVariable("proxy.pathsuffix","/");
		context.setVariable("countryISO","ES");
		context.setVariable("currentFlowName","GetCustomerAccountList");
        expect(buildTargetUrl).toThrow("Cannot read property 'split' of undefined");
    });
	 it ('Positive case 5: SSL enabled false and verb is POST', function() {
		context.setVariable("environment_targets_endpoint_properties",'{"aws-test-es":{"GetCustomerAccountList":{"TARGET_HOST":"accountservice-es-test.myvdf.aws.cps.vodafone.com","TARGET_PORT":"443","TARGET_PATH":"/es/v1/apiPath","TARGET_ENABLED":true,"TARGET_SSL_ENABLED":true,"TARGET_SSL_CIPHERS":"","TARGET_SSL_CLIENT_AUTH_ENABLED":false,"TARGET_SSL_KEY_STORE":"","TARGET_SSL_KEY_ALIAS":"","TARGET_SSL_TRUST_STORE":"","TARGET_SSL_PROTOCOLS":"","TARGET_SSL_IGNORE_VALIDATION_ERRORS":false}},"aws-test-gr":{"GetCustomerAccountList":{"TARGET_HOST":"accountservice-es-test.myvdf.aws.cps.vodafone.com","TARGET_PORT":"443","TARGET_PATH":"/es/v1/apiPath","TARGET_ENABLED":true,"TARGET_SSL_ENABLED":false,"TARGET_SSL_CIPHERS":"","TARGET_SSL_CLIENT_AUTH_ENABLED":false,"TARGET_SSL_KEY_STORE":"","TARGET_SSL_KEY_ALIAS":"","TARGET_SSL_TRUST_STORE":"","TARGET_SSL_PROTOCOLS":"","TARGET_SSL_IGNORE_VALIDATION_ERRORS":false}},"apix_aws_stubs":{"GetCustomerAccountList":{"TARGET_HOST":"apix.master.centralqa.de","TARGET_PORT":"443","TARGET_PATH":"/es/v1/apiPath","TARGET_ENABLED":true,"TARGET_SSL_ENABLED":true,"TARGET_SSL_CIPHERS":"","TARGET_SSL_CLIENT_AUTH_ENABLED":false,"TARGET_SSL_KEY_STORE":"","TARGET_SSL_KEY_ALIAS":"","TARGET_SSL_TRUST_STORE":"","TARGET_SSL_PROTOCOLS":"","TARGET_SSL_IGNORE_VALIDATION_ERRORS":false}}}');
		context.setVariable("proxy.pathsuffix","/");
		context.setVariable("env_target_valid_enviroment","dev,testing,staging,stagingref");
		context.setVariable("request.verb","POST");
		context.setVariable("countryISO","GR");
		context.setVariable("currentFlowName","GetCustomerAccountList");
		context.setVariable("defaultTargetGR","aws-test-gr");
        expect(buildTargetUrl()).toBe();
		expect(context.getVariable("target.url")).toBe("http://accountservice-es-test.myvdf.aws.cps.vodafone.com:443/es/v1/apiPath/");
    });
    it ('Positive case 6: Target Host and Port not present for ES', function() {
		context.setVariable("environment_targets_endpoint_properties",'{"aws-test-es":{"GetCustomerAccountList":{"TARGET_PATH":"/es/v1/apiPath","TARGET_ENABLED":true,"TARGET_SSL_ENABLED":true,"TARGET_SSL_CIPHERS":"","TARGET_SSL_CLIENT_AUTH_ENABLED":false,"TARGET_SSL_KEY_STORE":"","TARGET_SSL_KEY_ALIAS":"","TARGET_SSL_TRUST_STORE":"","TARGET_SSL_PROTOCOLS":"","TARGET_SSL_IGNORE_VALIDATION_ERRORS":false}},"apix_aws_stubs":{"GetCustomerAccountList":{"TARGET_HOST":"apix.master.centralqa.de","TARGET_PORT":"443","TARGET_PATH":"/es/v1/apiPath","TARGET_ENABLED":true,"TARGET_SSL_ENABLED":true,"TARGET_SSL_CIPHERS":"","TARGET_SSL_CLIENT_AUTH_ENABLED":false,"TARGET_SSL_KEY_STORE":"","TARGET_SSL_KEY_ALIAS":"","TARGET_SSL_TRUST_STORE":"","TARGET_SSL_PROTOCOLS":"","TARGET_SSL_IGNORE_VALIDATION_ERRORS":false}}}');
		context.setVariable("proxy.pathsuffix","/");
		context.setVariable("request.querystring","id=123");
		context.setVariable("env_target_valid_enviroment","dev,testing,staging,stagingref");
		context.setVariable("environment.name","dev");
		context.setVariable("request.verb","GET");
		context.setVariable("countryISO","ES");
		context.setVariable("defaultTargetGR","aws-test-es");
		context.setVariable("currentFlowName","GetCustomerAccountList");
        expect(buildTargetUrl).toThrow();
        expect(context.getVariable("isTargetError")).toBe(true);
		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    });
    it ('Positive case 7: envTargets entry not present for the particular Header', function() {
		context.setVariable("environment_targets_endpoint_properties",'{"aws-test-es":{"GetCustomerAccountList":{"TARGET_HOST":"accountservice-es-test.myvdf.aws.cps.vodafone.com","TARGET_PORT":"443","TARGET_PATH":"/es/v1/apiPath","TARGET_ENABLED":true,"TARGET_SSL_ENABLED":true,"TARGET_SSL_CIPHERS":"","TARGET_SSL_CLIENT_AUTH_ENABLED":false,"TARGET_SSL_KEY_STORE":"","TARGET_SSL_KEY_ALIAS":"","TARGET_SSL_TRUST_STORE":"","TARGET_SSL_PROTOCOLS":"","TARGET_SSL_IGNORE_VALIDATION_ERRORS":false}},"apix_aws_stubs":{"GetCustomerAccountList":{"TARGET_HOST":"apix.master.centralqa.de","TARGET_PORT":"443","TARGET_PATH":"/es/v1/apiPath","TARGET_ENABLED":true,"TARGET_SSL_ENABLED":true,"TARGET_SSL_CIPHERS":"","TARGET_SSL_CLIENT_AUTH_ENABLED":false,"TARGET_SSL_KEY_STORE":"","TARGET_SSL_KEY_ALIAS":"","TARGET_SSL_TRUST_STORE":"","TARGET_SSL_PROTOCOLS":"","TARGET_SSL_IGNORE_VALIDATION_ERRORS":false}}}');
		context.setVariable("request.header.vf-target-environment","APIX_AWS_STUBS1");
		context.setVariable("environment.name","dev");
		context.setVariable("request.verb","GET");
		context.setVariable("env_target_valid_enviroment","dev,testing,staging,stagingref");
		context.setVariable("countryISO","ES");
		context.setVariable("currentFlowName","GetCustomerAccountList");
        expect(buildTargetUrl).toThrow(true);
		expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_target_header");
    });
    it ('Positive case 8: envTargets not present', function() {
		context.setVariable("request.header.vf-target-environment","APIX_AWS_STUBS1");
		context.setVariable("environment.name","dev");
		context.setVariable("request.verb","GET");
		context.setVariable("env_target_valid_enviroment","dev,testing,staging,stagingref");
		context.setVariable("countryISO","ES");
		context.setVariable("currentFlowName","GetCustomerAccountList");
        expect(buildTargetUrl).toThrow(true);
		expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_target_header");
    });
    it ('Positive case 9: Target not present for the mentioned country', function() {
		context.setVariable("environment_targets_endpoint_properties",'{"aws-test-es":{"GetCustomerAccountList":{"TARGET_HOST":"accountservice-es-test.myvdf.aws.cps.vodafone.com","TARGET_PORT":"443","TARGET_PATH":"/es/v1/apiPath","TARGET_ENABLED":true,"TARGET_SSL_ENABLED":true,"TARGET_SSL_CIPHERS":"","TARGET_SSL_CLIENT_AUTH_ENABLED":false,"TARGET_SSL_KEY_STORE":"","TARGET_SSL_KEY_ALIAS":"","TARGET_SSL_TRUST_STORE":"","TARGET_SSL_PROTOCOLS":"","TARGET_SSL_IGNORE_VALIDATION_ERRORS":false}},"aws-test-gr":{"GetCustomerAccountList":{"TARGET_HOST":"accountservice-es-test.myvdf.aws.cps.vodafone.com","TARGET_PORT":"443","TARGET_PATH":"/es/v1/apiPath","TARGET_ENABLED":true,"TARGET_SSL_ENABLED":false,"TARGET_SSL_CIPHERS":"","TARGET_SSL_CLIENT_AUTH_ENABLED":false,"TARGET_SSL_KEY_STORE":"","TARGET_SSL_KEY_ALIAS":"","TARGET_SSL_TRUST_STORE":"","TARGET_SSL_PROTOCOLS":"","TARGET_SSL_IGNORE_VALIDATION_ERRORS":false}},"apix_aws_stubs":{"GetCustomerAccountList":{"TARGET_HOST":"apix.master.centralqa.de","TARGET_PORT":"443","TARGET_PATH":"/es/v1/apiPath","TARGET_ENABLED":true,"TARGET_SSL_ENABLED":true,"TARGET_SSL_CIPHERS":"","TARGET_SSL_CLIENT_AUTH_ENABLED":false,"TARGET_SSL_KEY_STORE":"","TARGET_SSL_KEY_ALIAS":"","TARGET_SSL_TRUST_STORE":"","TARGET_SSL_PROTOCOLS":"","TARGET_SSL_IGNORE_VALIDATION_ERRORS":false}}}');
		context.setVariable("proxy.pathsuffix","/");
		context.setVariable("env_target_valid_enviroment","dev,testing,staging,stagingref");
		context.setVariable("countryISO","DE");
		context.setVariable("currentFlowName","GetCustomerAccountList");
		context.setVariable("defaultTargetDE","aws-test-de");
        expect(buildTargetUrl).toThrow(true);
		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    });
    it ('Positive case 10: Host not present', function() {
		context.setVariable("environment_targets_endpoint_properties",'{"aws-test-es":{"GetCustomerAccountList":{"TARGET_PORT":"443","TARGET_PATH":"/es/v1/apiPath","TARGET_ENABLED":true,"TARGET_SSL_ENABLED":true,"TARGET_SSL_CIPHERS":"","TARGET_SSL_CLIENT_AUTH_ENABLED":false,"TARGET_SSL_KEY_STORE":"","TARGET_SSL_KEY_ALIAS":"","TARGET_SSL_TRUST_STORE":"","TARGET_SSL_PROTOCOLS":"","TARGET_SSL_IGNORE_VALIDATION_ERRORS":false}},"apix_aws_stubs":{"GetCustomerAccountList":{"TARGET_HOST":"apix.master.centralqa.de","TARGET_PORT":"443","TARGET_PATH":"/es/v1/apiPath","TARGET_ENABLED":true,"TARGET_SSL_ENABLED":true,"TARGET_SSL_CIPHERS":"","TARGET_SSL_CLIENT_AUTH_ENABLED":false,"TARGET_SSL_KEY_STORE":"","TARGET_SSL_KEY_ALIAS":"","TARGET_SSL_TRUST_STORE":"","TARGET_SSL_PROTOCOLS":"","TARGET_SSL_IGNORE_VALIDATION_ERRORS":false}}}');
		context.setVariable("proxy.pathsuffix","/");
		context.setVariable("env_target_valid_enviroment","dev,testing,staging,stagingref");
		context.setVariable("countryISO","ES");
		context.setVariable("defaultTargetES","aws-test-es");
		context.setVariable("currentFlowName","GetCustomerAccountList");
        expect(buildTargetUrl).toThrow(true);
		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    });
    it ('Positive case 11: Targets is invalid, Catch Exception', function() {
		context.setVariable("environment_targets_endpoint_properties",'{"aws-test-es":{"GetCustomerAccountList":{"TARGET_HOST":"accountservice-es-test.myvdf.aws.cps.vodafone.com","TARGET_PORT":"443","TARGET_PATH":"/es/v1/apiPath","TARGET_ENABLED":true,"TARGET_SSL_ENABLED":true,"TARGET_SSL_CIPHERS":"","TARGET_SSL_CLIENT_AUTH_ENABLED":false,"TARGET_SSL_KEY_STORE":"","TARGET_SSL_KEY_ALIAS":"","TARGET_SSL_TRUST_STORE":"","TARGET_SSL_PROTOCOLS":"","TARGET_SSL_IGNORE_VALIDATION_ERRORS":false}},"apix_aws_stubs":{"GetCustomerAccountList":{"TARGET_HOST":"apix.master.centralqa.de","TARGET_PORT":"443","TARGET_PATH":"/es/v1/apiPath","TARGET_ENABLED":true,"TARGET_SSL_ENABLED":true,"TARGET_SSL_CIPHERS":"","TARGET_SSL_CLIENT_AUTH_ENABLED":false,"TARGET_SSL_KEY_STORE":"","TARGET_SSL_KEY_ALIAS":"","TARGET_SSL_TRUST_STORE":"","TARGET_SSL_PROTOCOLS":"","TARGET_SSL_IGNORE_VALIDATION_ERRORS":false}}');
		context.setVariable("environment.name","dev");
		context.setVariable("request.verb","GET");
		context.setVariable("env_target_valid_enviroment","dev,testing,staging,stagingref");
		context.setVariable("countryISO","ES");
		context.setVariable("defaultTargetES","aws-test-es");
		context.setVariable("currentFlowName","GetCustomerAccountList");
        expect(buildTargetUrl).toThrow(true);
		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
		
    });
    it ('Positive case 12: Catch exception for Env Targets', function() {
		context.setVariable("environment_targets_endpoint_properties",'{"aws-test-es":{"GetCustomerAccountList":{"TARGET_HOST":"accountservice-es-test.myvdf.aws.cps.vodafone.com""TARGET_PORT":"443","TARGET_PATH":"/es/v1/apiPath","TARGET_ENABLED":true,"TARGET_SSL_ENABLED":true,"TARGET_SSL_CIPHERS":"","TARGET_SSL_CLIENT_AUTH_ENABLED":false,"TARGET_SSL_KEY_STORE":"","TARGET_SSL_KEY_ALIAS":"","TARGET_SSL_TRUST_STORE":"","TARGET_SSL_PROTOCOLS":"","TARGET_SSL_IGNORE_VALIDATION_ERRORS":false}},"apix_aws_stubs":{"GetCustomerAccountList":{"TARGET_HOST":"apix.master.centralqa.de","TARGET_PORT":"443","TARGET_PATH":"/es/v1/apiPath","TARGET_ENABLED":true,"TARGET_SSL_ENABLED":true,"TARGET_SSL_CIPHERS":"","TARGET_SSL_CLIENT_AUTH_ENABLED":false,"TARGET_SSL_KEY_STORE":"","TARGET_SSL_KEY_ALIAS":"","TARGET_SSL_TRUST_STORE":"","TARGET_SSL_PROTOCOLS":"","TARGET_SSL_IGNORE_VALIDATION_ERRORS":false}}}');
		context.setVariable("environment.name","dev");
		context.setVariable("proxy.pathsuffix","/");
		context.setVariable("request.querystring","id=123");
		context.setVariable("request.header.vf-target-environment","aws-test-es");
		context.setVariable("request.verb","GET");
		context.setVariable("env_target_valid_enviroment","dev,testing,staging,stagingref");
		context.setVariable("countryISO","ES");
		context.setVariable("currentFlowName","GetCustomerAccountList");
        expect(buildTargetUrl).toThrow(true);
		expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_target_header");
    });
});