var SortAPIScope = require('../jsc/a42HomeDocGenerate/SortAPIScopes');
describe('Sort API Scopes Suite', function() {
    beforeEach(function(){
      var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });

it ('Positive: Sorted scopes ', function() {
        context.setVariable("accesstoken.scope","CD GH AB");   
        expect(SortAPIScopes()).toBe();
        expect(context.getVariable("sortedScopes")).toBe("AB,CD,GH");
    });

it ('Positive: single scope ', function() {
    context.setVariable("accesstoken.scope","CD");   
    expect(SortAPIScopes()).toBe();
    expect(context.getVariable("sortedScopes")).toBe("CD");
}); 

it('Negative: Scope is empty', function() {
	context.setVariable("accesstoken.scope", "");
	expect(SortAPIScopes).toThrow();
	expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
	
});

});



