/**
 * 
 */
var CheckXSSInRequest = require('../jsc/CheckXSSInRequest/CheckXSSInRequest');
describe('CheckXSSInRequest Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();

         var xssJsonRuntime=  {
                     "security_request_xss_headers" : { "enabled" : true , "regex" : "[^$()|{}<>]" },
                     "security_request_xss_query" : { "enabled" : true , "regex" : "[^$()|{}<>]" },
                     "security_request_xss_payload" : { "enabled" : false , "regex" : ""},
                     "security_request_xml_escape" : { "enabled" : false , "xml-escape-vars" : "" }
                      };
        
        context.setVariable("security_request_xss",JSON.stringify(xssJsonRuntime));  

    });
     
    it ('Positive case: header CheckXSSInRequest ', function() {
       

        expect(context.getVariable("security_request_xss_headers")).not.toBe(null);

    });

      it ('Positive case: query CheckXSSInRequest ', function() {
        

        expect(context.getVariable("security_request_xss_headers")).not.toBe(null);
        
    });

});