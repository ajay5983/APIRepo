/**
 * 
 */
var IoTServiceEligibilityCheckVar = require('../jsc/IOTCheckServiceEligibility/IoTServiceEligibilityCheck');
describe('IoTServiceEligibilityCheck Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });
     
    it ('Positive case1: AccessTokenACR', function() {
    	var serviceEligibilityCheckUserInfoResponse={};
    	serviceEligibilityCheckUserInfoResponse.kyc={};
    	serviceEligibilityCheckUserInfoResponse.kyc.status="notverified";
    	serviceEligibilityCheckUserInfoResponse.kyc.completeness="notcomplete";
    	context.setVariable("serviceEligibilityCheckUserInfoResponse",serviceEligibilityCheckUserInfoResponse);
    	context.setVariable("accesstoken.claimsFromRequest","{\"local_sub\":\"abcd\"}");
    	context.setVariable("serviceEligibilityRequirements","KYCStatus,Completeness");
        expect(checkServiceEligibilty()).toBe();
    });
    it ('Positive case2: AccessTokenACR', function() {
    	var serviceEligibilityCheckUserInfoResponse={};
    	serviceEligibilityCheckUserInfoResponse.kyc={};
    	serviceEligibilityCheckUserInfoResponse.kyc.status="verified";
    	serviceEligibilityCheckUserInfoResponse.kyc.completeness="complete";
    	context.setVariable("serviceEligibilityCheckUserInfoResponse",serviceEligibilityCheckUserInfoResponse);
    	context.setVariable("accesstoken.claimsFromRequest","{\"localsub\":\"abcd\"}");
    	context.setVariable("serviceEligibilityRequirements","");
        expect(checkServiceEligibilty()).toBe();
    });
    
    it ('Positive case3: AccessTokenACR', function() {
    	var serviceEligibilityCheckUserInfoResponse={};
    	serviceEligibilityCheckUserInfoResponse.kyc={};
    	serviceEligibilityCheckUserInfoResponse.kyc.status1="verified";
    	serviceEligibilityCheckUserInfoResponse.kyc.completeness1="complete";
    	context.setVariable("serviceEligibilityCheckUserInfoResponse",serviceEligibilityCheckUserInfoResponse);
    	context.setVariable("accesstoken.claimsFromRequest","{\"localsub\":\"abcd\"}");
    	context.setVariable("serviceEligibilityRequirements","KYCStatus,Completeness");
        expect(checkServiceEligibilty()).toBe();
    });
});