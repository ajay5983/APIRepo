/**
 * 
 */
var ConfigurationRuntimeReadabc = require('../jsc/ConfigurationRuntimeRead/ConfigurationRuntimeRead');
describe('ConfigurationRuntimeRead Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            },
            removeVariable: function(propertyName){
                this[propertyName] = '';
              }
        };
        context = new Context();
    });
     
    it ('Positive: SetRuntimeInfo', function() {
		context.setVariable("cors_info",JSON.stringify({ "CORS_SEPA": { "CORS_ENABLED": "TRUE", "CORS_ALLOWED_ORIGINS": ["apix.developer.vodafone.com", "apiguides.developer.vodafone.com", "apiguidessit.developer.vodafone.com", "apiguidesqa.developer.vodafone.com", "apiguidesdev.developer.vodafone.com", "apixdev.developer.vodafone.com", "apixtesting.developer.vodafone.com", "apixstaging.developer.vodafone.com", "apixstagingref.developer.vodafone.com", "*.developer.vodafone.com", "developer.vodafone.com", "*.sp.vodafone.com", "specifics.apix.developer.vodafone.com"], "CORS_ALLOWED_HEADERS": ["x-vf-trace-transaction-id", "x-vf-ext-trace-id", "x-vf-ext-reference-id", "x-vf-ext-bp-id", "x-vf-trace-source"], "CORS_ALLOWED_METHODS": ["GET", "POST", "OPTIONS", "PUT", "DELETE"], "CORS_MAX_AGE": "86400" }, "CORS_AnonymousCustomerReference": { "CORS_ENABLED": "TRUE", "CORS_ALLOWED_ORIGINS": ["apix.developer.vodafone.com", "apiguides.developer.vodafone.com", "apiguidessit.developer.vodafone.com"], "CORS_ALLOWED_HEADERS": ["x-vf-trace-transaction-id", "x-vf-ext-trace-id", "x-vf-ext-reference-id"], "CORS_ALLOWED_METHODS": ["GET", "POST", "OPTIONS"], "CORS_MAX_AGE": "86400" } }));
		context.setVariable("api_name","SEPA");
        context.setVariable("country_whitelisting",JSON.stringify({ "SEPA":{ "ORGANIZATIONLIST": "788fbeda-692d-4ce6-bbc3-4d492855d8d6,988fbeda-692d-4ce6-bbc3-4d492855d8d6", "788fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES,IT" }, "988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "PT" } }, "AnonymousCustomerReference":{ "ORGANIZATIONLIST": "988fbeda-692d-4ce6-bbc3-4d492855d8d6", "988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES" } } }));
        
       expect(configurationRuntimeRead()).toBe();
	   
	   expect(context.getVariable("runtime_cors_access_enabled")).toBe("TRUE");
	   expect(JSON.stringify(context.getVariable("runtime_cors_allowed_origins"))).toBe(JSON.stringify(["apix.developer.vodafone.com", "apiguides.developer.vodafone.com", "apiguidessit.developer.vodafone.com", "apiguidesqa.developer.vodafone.com", "apiguidesdev.developer.vodafone.com", "apixdev.developer.vodafone.com", "apixtesting.developer.vodafone.com", "apixstaging.developer.vodafone.com", "apixstagingref.developer.vodafone.com", "*.developer.vodafone.com", "developer.vodafone.com", "*.sp.vodafone.com", "specifics.apix.developer.vodafone.com"]));
	   expect(JSON.stringify(context.getVariable("runtime_cors_allowed_headers"))).toBe(JSON.stringify(["x-vf-trace-transaction-id", "x-vf-ext-trace-id", "x-vf-ext-reference-id", "x-vf-ext-bp-id", "x-vf-trace-source"]));
	   expect(JSON.stringify(context.getVariable("runtime_cors_allowed_methods"))).toBe(JSON.stringify(["GET", "POST", "OPTIONS", "PUT", "DELETE"]));
	   expect(context.getVariable("runtime_cors_max_age")).toBe("86400");
	   
	   expect(context.getVariable("runtime_whitelisting")).toBe(JSON.stringify({ "ORGANIZATIONLIST": "788fbeda-692d-4ce6-bbc3-4d492855d8d6,988fbeda-692d-4ce6-bbc3-4d492855d8d6", "788fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES,IT" }, "988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "PT" } }));
	   
	   expect(context.getVariable("errorJSON")).toBe(undefined);
    });
	
    it ('Positive: No CORS Info', function() {
		context.setVariable("cors_info",);
		context.setVariable("api_name","SEPA");
        context.setVariable("country_whitelisting",JSON.stringify({ "SEPA":{ "ORGANIZATIONLIST": "788fbeda-692d-4ce6-bbc3-4d492855d8d6,988fbeda-692d-4ce6-bbc3-4d492855d8d6", "788fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES,IT" }, "988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "PT" } }, "AnonymousCustomerReference":{ "ORGANIZATIONLIST": "988fbeda-692d-4ce6-bbc3-4d492855d8d6", "988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES" } } }));
        
       expect(configurationRuntimeRead()).toBe();
	   
	   expect(context.getVariable("runtime_whitelisting")).toBe(JSON.stringify({ "ORGANIZATIONLIST": "788fbeda-692d-4ce6-bbc3-4d492855d8d6,988fbeda-692d-4ce6-bbc3-4d492855d8d6", "788fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES,IT" }, "988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "PT" } }));
	   
	   expect(context.getVariable("errorJSON")).toBe(undefined);
    });	
	
	it ('Negative: InvalidCountryWhitelistingInfo', function() {
		context.setVariable("cors_info",JSON.stringify({ "CORS_SEPA": { "CORS_ENABLED": "TRUE", "CORS_ALLOWED_ORIGINS": ["apix.developer.vodafone.com", "apiguides.developer.vodafone.com", "apiguidessit.developer.vodafone.com", "apiguidesqa.developer.vodafone.com", "apiguidesdev.developer.vodafone.com", "apixdev.developer.vodafone.com", "apixtesting.developer.vodafone.com", "apixstaging.developer.vodafone.com", "apixstagingref.developer.vodafone.com", "*.developer.vodafone.com", "developer.vodafone.com", "*.sp.vodafone.com", "specifics.apix.developer.vodafone.com"], "CORS_ALLOWED_HEADERS": ["x-vf-trace-transaction-id", "x-vf-ext-trace-id", "x-vf-ext-reference-id", "x-vf-ext-bp-id", "x-vf-trace-source"], "CORS_ALLOWED_METHODS": ["GET", "POST", "OPTIONS", "PUT", "DELETE"], "CORS_MAX_AGE": "86400" }, "CORS_AnonymousCustomerReference": { "CORS_ENABLED": "TRUE", "CORS_ALLOWED_ORIGINS": ["apix.developer.vodafone.com", "apiguides.developer.vodafone.com", "apiguidessit.developer.vodafone.com"], "CORS_ALLOWED_HEADERS": ["x-vf-trace-transaction-id", "x-vf-ext-trace-id", "x-vf-ext-reference-id"], "CORS_ALLOWED_METHODS": ["GET", "POST", "OPTIONS"], "CORS_MAX_AGE": "86400" } }));
		context.setVariable("api_name","SEPA");
        context.setVariable("country_whitelisting",JSON.stringify({"a":"abc"}));
        
        expect(configurationRuntimeRead).toThrow();
        
	   expect(context.getVariable("runtime_cors_access_enabled")).toBe("TRUE");
	   expect(JSON.stringify(context.getVariable("runtime_cors_allowed_origins"))).toBe(JSON.stringify(["apix.developer.vodafone.com", "apiguides.developer.vodafone.com", "apiguidessit.developer.vodafone.com", "apiguidesqa.developer.vodafone.com", "apiguidesdev.developer.vodafone.com", "apixdev.developer.vodafone.com", "apixtesting.developer.vodafone.com", "apixstaging.developer.vodafone.com", "apixstagingref.developer.vodafone.com", "*.developer.vodafone.com", "developer.vodafone.com", "*.sp.vodafone.com", "specifics.apix.developer.vodafone.com"]));
	   expect(JSON.stringify(context.getVariable("runtime_cors_allowed_headers"))).toBe(JSON.stringify(["x-vf-trace-transaction-id", "x-vf-ext-trace-id", "x-vf-ext-reference-id", "x-vf-ext-bp-id", "x-vf-trace-source"]));
	   expect(JSON.stringify(context.getVariable("runtime_cors_allowed_methods"))).toBe(JSON.stringify(["GET", "POST", "OPTIONS", "PUT", "DELETE"]));
	   expect(context.getVariable("runtime_cors_max_age")).toBe("86400");
	   
	   expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    });
	
	it ('Negative: NoCountryWhitelistingInfo', function() {
		context.setVariable("cors_info",JSON.stringify({ "CORS_SEPA": { "CORS_ENABLED": "TRUE", "CORS_ALLOWED_ORIGINS": ["apix.developer.vodafone.com", "apiguides.developer.vodafone.com", "apiguidessit.developer.vodafone.com", "apiguidesqa.developer.vodafone.com", "apiguidesdev.developer.vodafone.com", "apixdev.developer.vodafone.com", "apixtesting.developer.vodafone.com", "apixstaging.developer.vodafone.com", "apixstagingref.developer.vodafone.com", "*.developer.vodafone.com", "developer.vodafone.com", "*.sp.vodafone.com", "specifics.apix.developer.vodafone.com"], "CORS_ALLOWED_HEADERS": ["x-vf-trace-transaction-id", "x-vf-ext-trace-id", "x-vf-ext-reference-id", "x-vf-ext-bp-id", "x-vf-trace-source"], "CORS_ALLOWED_METHODS": ["GET", "POST", "OPTIONS", "PUT", "DELETE"], "CORS_MAX_AGE": "86400" }, "CORS_AnonymousCustomerReference": { "CORS_ENABLED": "TRUE", "CORS_ALLOWED_ORIGINS": ["apix.developer.vodafone.com", "apiguides.developer.vodafone.com", "apiguidessit.developer.vodafone.com"], "CORS_ALLOWED_HEADERS": ["x-vf-trace-transaction-id", "x-vf-ext-trace-id", "x-vf-ext-reference-id"], "CORS_ALLOWED_METHODS": ["GET", "POST", "OPTIONS"], "CORS_MAX_AGE": "86400" } }));
		context.setVariable("api_name","SEPA");
        
        expect(configurationRuntimeRead).toThrow();
    });
	
	it ('Negative: InvalidCORSInfo', function() {
		context.setVariable("cors_info",JSON.stringify({ "a": "abc"}));
        context.setVariable("api_name","SEPA");
        context.setVariable("country_whitelisting",JSON.stringify({ "SEPA":{ "ORGANIZATIONLIST": "788fbeda-692d-4ce6-bbc3-4d492855d8d6,988fbeda-692d-4ce6-bbc3-4d492855d8d6", "788fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES,IT" }, "988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "PT" } }, "AnonymousCustomerReference":{ "ORGANIZATIONLIST": "988fbeda-692d-4ce6-bbc3-4d492855d8d6", "988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES" } } }));
	    
        expect(context.getVariable("errorJSON")).toBe(undefined);
    });
	
	it ('Negative: NoCORSInfo', function() {
        context.setVariable("api_name","SEPA");
        context.setVariable("country_whitelisting",JSON.stringify({ "SEPA":{ "ORGANIZATIONLIST": "788fbeda-692d-4ce6-bbc3-4d492855d8d6,988fbeda-692d-4ce6-bbc3-4d492855d8d6", "788fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES,IT" }, "988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "PT" } }, "AnonymousCustomerReference":{ "ORGANIZATIONLIST": "988fbeda-692d-4ce6-bbc3-4d492855d8d6", "988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES" } } }));
        
        expect(context.getVariable("errorJSON")).toBe(undefined);     
   });	
    it ('Negative: NoAPI_NAME', function() {
		context.setVariable("cors_info",JSON.stringify({ "CORS_SEPA": { "CORS_ENABLED": "TRUE", "CORS_ALLOWED_ORIGINS": ["apix.developer.vodafone.com", "apiguides.developer.vodafone.com", "apiguidessit.developer.vodafone.com", "apiguidesqa.developer.vodafone.com", "apiguidesdev.developer.vodafone.com", "apixdev.developer.vodafone.com", "apixtesting.developer.vodafone.com", "apixstaging.developer.vodafone.com", "apixstagingref.developer.vodafone.com", "*.developer.vodafone.com", "developer.vodafone.com", "*.sp.vodafone.com", "specifics.apix.developer.vodafone.com"], "CORS_ALLOWED_HEADERS": ["x-vf-trace-transaction-id", "x-vf-ext-trace-id", "x-vf-ext-reference-id", "x-vf-ext-bp-id", "x-vf-trace-source"], "CORS_ALLOWED_METHODS": ["GET", "POST", "OPTIONS", "PUT", "DELETE"], "CORS_MAX_AGE": "86400" }, "CORS_AnonymousCustomerReference": { "CORS_ENABLED": "TRUE", "CORS_ALLOWED_ORIGINS": ["apix.developer.vodafone.com", "apiguides.developer.vodafone.com", "apiguidessit.developer.vodafone.com"], "CORS_ALLOWED_HEADERS": ["x-vf-trace-transaction-id", "x-vf-ext-trace-id", "x-vf-ext-reference-id"], "CORS_ALLOWED_METHODS": ["GET", "POST", "OPTIONS"], "CORS_MAX_AGE": "86400" } }));
        context.setVariable("country_whitelisting",JSON.stringify({ "SEPA":{ "ORGANIZATIONLIST": "788fbeda-692d-4ce6-bbc3-4d492855d8d6,988fbeda-692d-4ce6-bbc3-4d492855d8d6", "788fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES,IT" }, "988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "PT" } }, "AnonymousCustomerReference":{ "ORGANIZATIONLIST": "988fbeda-692d-4ce6-bbc3-4d492855d8d6", "988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES" } } }));
        
	   expect(configurationRuntimeRead).toThrow();
	   expect(context.getVariable("runtime_cors_access_enabled")).toBe(undefined);
	   expect(context.getVariable("runtime_cors_allowed_origins")).toBe(undefined);
	   expect(context.getVariable("runtime_cors_allowed_headers")).toBe(undefined);
	   expect(context.getVariable("runtime_cors_allowed_methods")).toBe(undefined);
	   expect(context.getVariable("runtime_cors_max_age")).toBe(undefined);
	   expect(context.getVariable("runtime_whitelisting")).toBe(undefined);
	   expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    });
    
    it ('Negative: WrongAPI_NAME', function() {
		context.setVariable("cors_info",JSON.stringify({ "CORS_SEPA": { "CORS_ENABLED": "TRUE", "CORS_ALLOWED_ORIGINS": ["apix.developer.vodafone.com", "apiguides.developer.vodafone.com", "apiguidessit.developer.vodafone.com", "apiguidesqa.developer.vodafone.com", "apiguidesdev.developer.vodafone.com", "apixdev.developer.vodafone.com", "apixtesting.developer.vodafone.com", "apixstaging.developer.vodafone.com", "apixstagingref.developer.vodafone.com", "*.developer.vodafone.com", "developer.vodafone.com", "*.sp.vodafone.com", "specifics.apix.developer.vodafone.com"], "CORS_ALLOWED_HEADERS": ["x-vf-trace-transaction-id", "x-vf-ext-trace-id", "x-vf-ext-reference-id", "x-vf-ext-bp-id", "x-vf-trace-source"], "CORS_ALLOWED_METHODS": ["GET", "POST", "OPTIONS", "PUT", "DELETE"], "CORS_MAX_AGE": "86400" }, "CORS_AnonymousCustomerReference": { "CORS_ENABLED": "TRUE", "CORS_ALLOWED_ORIGINS": ["apix.developer.vodafone.com", "apiguides.developer.vodafone.com", "apiguidessit.developer.vodafone.com"], "CORS_ALLOWED_HEADERS": ["x-vf-trace-transaction-id", "x-vf-ext-trace-id", "x-vf-ext-reference-id"], "CORS_ALLOWED_METHODS": ["GET", "POST", "OPTIONS"], "CORS_MAX_AGE": "86400" } }));
		context.setVariable("api_name","NoSEPA");
		context.setVariable("country_whitelisting",JSON.stringify({ "SEPA":{ "ORGANIZATIONLIST": "788fbeda-692d-4ce6-bbc3-4d492855d8d6,988fbeda-692d-4ce6-bbc3-4d492855d8d6", "788fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES,IT" }, "988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "PT" } }, "AnonymousCustomerReference":{ "ORGANIZATIONLIST": "988fbeda-692d-4ce6-bbc3-4d492855d8d6", "988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES" } } }));
        
	    expect(configurationRuntimeRead).toThrow();
	    expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    });
    
    it ('Negative: Cors enabled field as false', function() {
		context.setVariable("cors_info",JSON.stringify({ "CORS_SEPA": { "CORS_ENABLED": false, "CORS_ALLOWED_ORIGINS": ["apix.developer.vodafone.com", "apiguides.developer.vodafone.com", "apiguidessit.developer.vodafone.com", "apiguidesqa.developer.vodafone.com", "apiguidesdev.developer.vodafone.com", "apixdev.developer.vodafone.com", "apixtesting.developer.vodafone.com", "apixstaging.developer.vodafone.com", "apixstagingref.developer.vodafone.com", "*.developer.vodafone.com", "developer.vodafone.com", "*.sp.vodafone.com", "specifics.apix.developer.vodafone.com"], "CORS_ALLOWED_HEADERS": ["x-vf-trace-transaction-id", "x-vf-ext-trace-id", "x-vf-ext-reference-id", "x-vf-ext-bp-id", "x-vf-trace-source"], "CORS_ALLOWED_METHODS": ["GET", "POST", "OPTIONS", "PUT", "DELETE"], "CORS_MAX_AGE": "86400" }, "CORS_AnonymousCustomerReference": { "CORS_ENABLED": "TRUE", "CORS_ALLOWED_ORIGINS": ["apix.developer.vodafone.com", "apiguides.developer.vodafone.com", "apiguidessit.developer.vodafone.com"], "CORS_ALLOWED_HEADERS": ["x-vf-trace-transaction-id", "x-vf-ext-trace-id", "x-vf-ext-reference-id"], "CORS_ALLOWED_METHODS": ["GET", "POST", "OPTIONS"], "CORS_MAX_AGE": "86400" } }));
		context.setVariable("api_name","SEPA");
		context.setVariable("country_whitelisting",JSON.stringify({ "SEPA":{ "ORGANIZATIONLIST": "788fbeda-692d-4ce6-bbc3-4d492855d8d6,988fbeda-692d-4ce6-bbc3-4d492855d8d6", "788fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES,IT" }, "988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "PT" } }, "AnonymousCustomerReference":{ "ORGANIZATIONLIST": "988fbeda-692d-4ce6-bbc3-4d492855d8d6", "988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES" } } }));
		
		expect(configurationRuntimeRead()).toBe();
	    expect(context.getVariable("errorJSON")).toBe(undefined);
    });
    it ('Negative: Cors fields set as empty or null', function() {
		context.setVariable("cors_info",JSON.stringify({ "CORS_SEPA": { "CORS_ENABLED": false, "CORS_ALLOWED_ORIGINS":"", "CORS_ALLOWED_HEADERS": "", "CORS_ALLOWED_METHODS": "", "CORS_MAX_AGE": null }, "CORS_AnonymousCustomerReference": { "CORS_ENABLED": "TRUE", "CORS_ALLOWED_ORIGINS": ["apix.developer.vodafone.com", "apiguides.developer.vodafone.com", "apiguidessit.developer.vodafone.com"], "CORS_ALLOWED_HEADERS": ["x-vf-trace-transaction-id", "x-vf-ext-trace-id", "x-vf-ext-reference-id"], "CORS_ALLOWED_METHODS": ["GET", "POST", "OPTIONS"], "CORS_MAX_AGE": "86400" } }));
		context.setVariable("api_name","SEPA");
		context.setVariable("country_whitelisting",JSON.stringify({ "SEPA":{ "ORGANIZATIONLIST": "788fbeda-692d-4ce6-bbc3-4d492855d8d6,988fbeda-692d-4ce6-bbc3-4d492855d8d6", "788fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES,IT" }, "988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "PT" } }, "AnonymousCustomerReference":{ "ORGANIZATIONLIST": "988fbeda-692d-4ce6-bbc3-4d492855d8d6", "988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES" } } }));
        
		expect(configurationRuntimeRead()).toBe();
	    expect(context.getVariable("errorJSON")).toBe(undefined);
    });
   

});