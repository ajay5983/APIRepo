/**
 * 
 */
var verify_link = require('../jsc/ValidateDownloadLink/ValidateDownloadLink');
describe('Verifying the link', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });
     
    it ('Positive case1: verifying the link with response', function() {
       
		context.setVariable("accesstoken.msisdn","4545454241a5");
		context.setVariable("accesstoken.sub","54241a5");
		context.setVariable("accesstoken.acr","45454542");
        context.setVariable("response.header.X-JWT","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiZW1haWwiOiJqZDJAZXhtYXBsZS5jb20iLCJhZG1pbiI6dHJ1ZX0.DJZX3Nsuj7SN0B0XYgzKt5wWqkBlEefnCd_MRVxEmTA");
		context.setVariable("jws_token","**********");
		context.setVariable("ROUTING.target_ssl_enabled",true);
		context.setVariable("ROUTING.target_ssl.client.auth.enabled",false);
		context.setVariable("ROUTING.target.ssl.key.store");
		context.setVariable("ROUTING.target.ssl.key.alias");
		context.setVariable("ROUTING.target.ssl.trust.store");
		context.setVariable("ROUTING.ssl.ciphers");
		context.setVariable("ROUTING.ssl.protocols");
		context.setVariable("ROUTING.ssl.ignore.validation.errors",false);
		context.setVariable("download_links","https://billingservice-es-test.myvdf.aws.cps.vodafone.com/v1/streaming/0922730f801b7ebe,NoURL,https://billingservice-es-test.myvdf.aws.cps.vodafone.com/v1/streaming/0902730f8025fb3f");
		context.setVariable("expiry_time","1587733971,NoExpiryTime,1586005971");
		context.setVariable("file_type","pdf,NoFileType,txt");
		expect(validateDownloadLink()).toBe();
	    expect(context.getVariable("jsonArray")).toEqual([ '{"url":"https://billingservice-es-test.myvdf.aws.cps.vodafone.com/v1/streaming/0922730f801b7ebe","backendAuth":{"fieldType":"header","fieldName":"Authorization","value":"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiZW1haWwiOiJqZDJAZXhtYXBsZS5jb20iLCJhZG1pbiI6dHJ1ZX0.DJZX3Nsuj7SN0B0XYgzKt5wWqkBlEefnCd_MRVxEmTA"},"sslInfo":{"sslEnabled":true,"clientAuthEnabled":false,"ignoreValidationErrors":false},"fileType":"pdf","msisdn":"4545454241a5","sub":"54241a5","acr":"45454542","expiryTime":"1587733971"}', '{}', '{"url":"https://billingservice-es-test.myvdf.aws.cps.vodafone.com/v1/streaming/0902730f8025fb3f","backendAuth":{"fieldType":"header","fieldName":"Authorization","value":"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiZW1haWwiOiJqZDJAZXhtYXBsZS5jb20iLCJhZG1pbiI6dHJ1ZX0.DJZX3Nsuj7SN0B0XYgzKt5wWqkBlEefnCd_MRVxEmTA"},"sslInfo":{"sslEnabled":true,"clientAuthEnabled":false,"ignoreValidationErrors":false},"fileType":"txt","msisdn":"4545454241a5","sub":"54241a5","acr":"45454542","expiryTime":"1586005971"}' ]);
	});
	
	it ('Positive case2: verifying the link with empty array string', function() {
        context.setVariable("download_links",",,");
		context.setVariable("expiry_time",",,");
		context.setVariable("file_type",",,");
		context.setVariable("ROUTING.target_ssl_enabled",true);
		context.setVariable("ROUTING.target_ssl.client.auth.enabled",false);
		context.setVariable("ROUTING.target.ssl.key.store");
		context.setVariable("ROUTING.target.ssl.key.alias");
		context.setVariable("ROUTING.target.ssl.trust.store");
		context.setVariable("ROUTING.ssl.ciphers");
		context.setVariable("ROUTING.ssl.protocols");
		context.setVariable("ROUTING.ssl.ignore.validation.errors",false);
		context.setVariable("accesstoken.msisdn","4545454241a5");
		context.setVariable("accesstoken.sub","54241a5");
		context.setVariable("accesstoken.acr","45454542");
        context.setVariable("response.header.X-JWT","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiZW1haWwiOiJqZDJAZXhtYXBsZS5jb20iLCJhZG1pbiI6dHJ1ZX0.DJZX3Nsuj7SN0B0XYgzKt5wWqkBlEefnCd_MRVxEmTA");
		context.setVariable("jws_token","**********");
		expect(validateDownloadLink).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_server_error");
		
    });
	it ('Positive case3: verifying the link with wrong link', function() {
        context.setVariable("download_links","httpsgtrfg://billingservice-es-test.myvdf.aws.cps.vodafone.com/v1/streaming/0922730f801b7ebe,NoURL,https://billingservice-es-test.myvdf.aws.cps.vodafone.com/v1/streaming/0902730f8025fb3f");
		context.setVariable("expiry_time","1587733971,NoExpiryTime,1586005971");
		context.setVariable("file_type","pdf,NoFileType,txt");
		context.setVariable("accesstoken.msisdn","4545454241a5");
		context.setVariable("accesstoken.sub","54241a5");
		context.setVariable("accesstoken.acr","45454542");
        context.setVariable("response.header.X-JWT","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiZW1haWwiOiJqZDJAZXhtYXBsZS5jb20iLCJhZG1pbiI6dHJ1ZX0.DJZX3Nsuj7SN0B0XYgzKt5wWqkBlEefnCd_MRVxEmTA");
		context.setVariable("jws_token","**********");
		context.setVariable("ROUTING.target_ssl_enabled",true);
		context.setVariable("ROUTING.target_ssl.client.auth.enabled",false);
		context.setVariable("ROUTING.target.ssl.key.store");
		context.setVariable("ROUTING.target.ssl.key.alias");
		context.setVariable("ROUTING.target.ssl.trust.store");
		context.setVariable("ROUTING.ssl.ciphers");
		context.setVariable("ROUTING.ssl.protocols");
		context.setVariable("ROUTING.ssl.ignore.validation.errors",false);
		expect(validateDownloadLink).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_server_error");
    });
	
	it ('Positive case4: verifying the link expiry time less than epoch time ', function() {
         context.setVariable("download_links","https://billingservice-es-test.myvdf.aws.cps.vodafone.com/v1/streaming/0922730f801b7ebe,NoURL,https://billingservice-es-test.myvdf.aws.cps.vodafone.com/v1/streaming/0902730f8025fb3f");
		context.setVariable("expiry_time","18000,NoExpiryTime,1586005971");
		context.setVariable("file_type","pdf,NoFileType,txt");
		context.setVariable("accesstoken.msisdn","4545454241a5");
		context.setVariable("accesstoken.sub","54241a5");
		context.setVariable("accesstoken.acr","45454542");
        context.setVariable("response.header.X-JWT","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiZW1haWwiOiJqZDJAZXhtYXBsZS5jb20iLCJhZG1pbiI6dHJ1ZX0.DJZX3Nsuj7SN0B0XYgzKt5wWqkBlEefnCd_MRVxEmTA");
		context.setVariable("jws_token","**********");
		context.setVariable("ROUTING.target_ssl_enabled",true);
		context.setVariable("ROUTING.target_ssl.client.auth.enabled",false);
		context.setVariable("ROUTING.target.ssl.key.store");
		context.setVariable("ROUTING.target.ssl.key.alias");
		context.setVariable("ROUTING.target.ssl.trust.store");
		context.setVariable("ROUTING.ssl.ciphers");
		context.setVariable("ROUTING.ssl.protocols");
		context.setVariable("ROUTING.ssl.ignore.validation.errors",false);
		expect(validateDownloadLink).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_server_error");
    });
	
	it ('Positive case5: verifying the link with response, if jwt token is empty', function() {
       
		context.setVariable("accesstoken.msisdn","4545454241a5");
		context.setVariable("accesstoken.sub","54241a5");
		context.setVariable("accesstoken.acr","45454542");
        context.setVariable("response.header.X-JWT","");
		context.setVariable("jws_token","**********");
		
		context.setVariable("download_links","https://billingservice-es-test.myvdf.aws.cps.vodafone.com/v1/streaming/0922730f801b7ebe,NoURL,https://billingservice-es-test.myvdf.aws.cps.vodafone.com/v1/streaming/0902730f8025fb3f");
		context.setVariable("expiry_time","1587733971,NoExpiryTime,1586005971");
		context.setVariable("file_type","pdf,NoFileType,txt");
		context.setVariable("ROUTING.target_ssl_enabled",true);
		context.setVariable("ROUTING.target_ssl.client.auth.enabled",false);
		context.setVariable("ROUTING.target.ssl.key.store");
		context.setVariable("ROUTING.target.ssl.key.alias");
		context.setVariable("ROUTING.target.ssl.trust.store");
		context.setVariable("ROUTING.ssl.ciphers");
		context.setVariable("ROUTING.ssl.protocols");
		context.setVariable("ROUTING.ssl.ignore.validation.errors",false);
		expect(validateDownloadLink()).toBe();
	    expect(context.getVariable("jsonArray")).toEqual([ '{"url":"https://billingservice-es-test.myvdf.aws.cps.vodafone.com/v1/streaming/0922730f801b7ebe","backendAuth":{"fieldType":"header","fieldName":"Authorization","value":"Bearer **********"},"sslInfo":{"sslEnabled":true,"clientAuthEnabled":false,"ignoreValidationErrors":false},"fileType":"pdf","msisdn":"4545454241a5","sub":"54241a5","acr":"45454542","expiryTime":"1587733971"}', '{}', '{"url":"https://billingservice-es-test.myvdf.aws.cps.vodafone.com/v1/streaming/0902730f8025fb3f","backendAuth":{"fieldType":"header","fieldName":"Authorization","value":"Bearer **********"},"sslInfo":{"sslEnabled":true,"clientAuthEnabled":false,"ignoreValidationErrors":false},"fileType":"txt","msisdn":"4545454241a5","sub":"54241a5","acr":"45454542","expiryTime":"1586005971"}' ]);
	});
    it ('Positive case6: verifying the link with download_links null', function() {
        context.setVariable("download_links",null);
		context.setVariable("expiry_time",",,");
		context.setVariable("file_type",",,");
		
		context.setVariable("accesstoken.msisdn","4545454241a5");
		context.setVariable("accesstoken.sub","54241a5");
		context.setVariable("accesstoken.acr","45454542");
        context.setVariable("response.header.X-JWT","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiZW1haWwiOiJqZDJAZXhtYXBsZS5jb20iLCJhZG1pbiI6dHJ1ZX0.DJZX3Nsuj7SN0B0XYgzKt5wWqkBlEefnCd_MRVxEmTA");
		context.setVariable("jws_token","**********");
		context.setVariable("ROUTING.target_ssl_enabled",true);
		context.setVariable("ROUTING.target_ssl.client.auth.enabled",false);
		context.setVariable("ROUTING.target.ssl.key.store");
		context.setVariable("ROUTING.target.ssl.key.alias");
		context.setVariable("ROUTING.target.ssl.trust.store");
		context.setVariable("ROUTING.ssl.ciphers");
		context.setVariable("ROUTING.ssl.protocols");
		context.setVariable("ROUTING.ssl.ignore.validation.errors",false);
		expect(validateDownloadLink()).toBe();
		expect(context.getVariable("jsonArray")).toEqual([]);
		
    });
	
	it ('Positive case7: verifying the link with NoURL,NoFileType,NoExpiry', function() {
       
		context.setVariable("accesstoken.msisdn","4545454241a5");
		context.setVariable("accesstoken.sub","54241a5");
		context.setVariable("accesstoken.acr","45454542");
        context.setVariable("response.header.X-JWT","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiZW1haWwiOiJqZDJAZXhtYXBsZS5jb20iLCJhZG1pbiI6dHJ1ZX0.DJZX3Nsuj7SN0B0XYgzKt5wWqkBlEefnCd_MRVxEmTA");
		context.setVariable("jws_token","**********");
		
		context.setVariable("download_links","NoURL");
		context.setVariable("expiry_time","NoExpiryTime");
		context.setVariable("file_type","NoFileType");
		context.setVariable("ROUTING.target_ssl_enabled",true);
		context.setVariable("ROUTING.target_ssl.client.auth.enabled",false);
		context.setVariable("ROUTING.target.ssl.key.store");
		context.setVariable("ROUTING.target.ssl.key.alias");
		context.setVariable("ROUTING.target.ssl.trust.store");
		context.setVariable("ROUTING.ssl.ciphers");
		context.setVariable("ROUTING.ssl.protocols");
		context.setVariable("ROUTING.ssl.ignore.validation.errors",false);
		expect(validateDownloadLink()).toBe();
	    expect(context.getVariable("jsonArray")).toEqual(['{}']);
	});
	
	it ('Positive case8: verifying the link with no expiry time ', function() {
       
		context.setVariable("accesstoken.msisdn","4545454241a5");
		context.setVariable("accesstoken.sub","54241a5");
		context.setVariable("accesstoken.acr","45454542");
        context.setVariable("response.header.X-JWT","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiZW1haWwiOiJqZDJAZXhtYXBsZS5jb20iLCJhZG1pbiI6dHJ1ZX0.DJZX3Nsuj7SN0B0XYgzKt5wWqkBlEefnCd_MRVxEmTA");
		context.setVariable("jws_token","**********");
		
		context.setVariable("download_links","https://billingservice-es-test.myvdf.aws.cps.vodafone.com/v1/streaming/0922730f801b7ebe");
		context.setVariable("expiry_time","");
		context.setVariable("file_type","pdf");
		context.setVariable("ROUTING.target_ssl_enabled",true);
		context.setVariable("ROUTING.target_ssl.client.auth.enabled",false);
		context.setVariable("ROUTING.target.ssl.key.store");
		context.setVariable("ROUTING.target.ssl.key.alias");
		context.setVariable("ROUTING.target.ssl.trust.store");
		context.setVariable("ROUTING.ssl.ciphers");
		context.setVariable("ROUTING.ssl.protocols");
		context.setVariable("ROUTING.ssl.ignore.validation.errors",false);
		expect(validateDownloadLink()).toBe();
	    expect(context.getVariable("jsonArray")).toEqual([ '{"url":"https://billingservice-es-test.myvdf.aws.cps.vodafone.com/v1/streaming/0922730f801b7ebe","backendAuth":{"fieldType":"header","fieldName":"Authorization","value":"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiZW1haWwiOiJqZDJAZXhtYXBsZS5jb20iLCJhZG1pbiI6dHJ1ZX0.DJZX3Nsuj7SN0B0XYgzKt5wWqkBlEefnCd_MRVxEmTA"},"sslInfo":{"sslEnabled":true,"clientAuthEnabled":false,"ignoreValidationErrors":false},"fileType":"pdf","msisdn":"4545454241a5","sub":"54241a5","acr":"45454542"}' ]);
	});
	
	it ('Positive case9: verifying the link with no filetype ', function() {
       
		context.setVariable("accesstoken.msisdn","");
		context.setVariable("accesstoken.sub","");
		context.setVariable("accesstoken.acr","");
        context.setVariable("response.header.X-JWT","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiZW1haWwiOiJqZDJAZXhtYXBsZS5jb20iLCJhZG1pbiI6dHJ1ZX0.DJZX3Nsuj7SN0B0XYgzKt5wWqkBlEefnCd_MRVxEmTA");
		context.setVariable("jws_token","**********");
		
		context.setVariable("download_links","https://billingservice-es-test.myvdf.aws.cps.vodafone.com/v1/streaming/0922730f801b7ebe");
		context.setVariable("expiry_time","");
		context.setVariable("file_type","");
		context.setVariable("ROUTING.target_ssl_enabled",true);
		context.setVariable("ROUTING.target_ssl.client.auth.enabled",false);
		context.setVariable("ROUTING.target.ssl.key.store");
		context.setVariable("ROUTING.target.ssl.key.alias");
		context.setVariable("ROUTING.target.ssl.trust.store");
		context.setVariable("ROUTING.ssl.ciphers");
		context.setVariable("ROUTING.ssl.protocols");
		context.setVariable("ROUTING.ssl.ignore.validation.errors",false);
		expect(validateDownloadLink()).toBe();
	    expect(context.getVariable("jsonArray")).toEqual([ '{"url":"https://billingservice-es-test.myvdf.aws.cps.vodafone.com/v1/streaming/0922730f801b7ebe","backendAuth":{"fieldType":"header","fieldName":"Authorization","value":"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiZW1haWwiOiJqZDJAZXhtYXBsZS5jb20iLCJhZG1pbiI6dHJ1ZX0.DJZX3Nsuj7SN0B0XYgzKt5wWqkBlEefnCd_MRVxEmTA"},"sslInfo":{"sslEnabled":true,"clientAuthEnabled":false,"ignoreValidationErrors":false}}' ]);
	});
	
	it ('Positive case10: verifying the link if flag is true ', function() {
       
		context.setVariable("accesstoken.msisdn","");
		context.setVariable("accesstoken.sub","");
		context.setVariable("accesstoken.acr","");
        context.setVariable("response.header.X-JWT","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiZW1haWwiOiJqZDJAZXhtYXBsZS5jb20iLCJhZG1pbiI6dHJ1ZX0.DJZX3Nsuj7SN0B0XYgzKt5wWqkBlEefnCd_MRVxEmTA");
		context.setVariable("jws_token","**********");
		context.setVariable("flag",true);
		context.setVariable("download_links","https://billingservice-es-test.myvdf.aws.cps.vodafone.com/v1/streaming/0922730f801b7ebe");
		context.setVariable("expiry_time","");
		context.setVariable("file_type","");
		context.setVariable("ROUTING.target_ssl_enabled",true);
		context.setVariable("ROUTING.target_ssl.client.auth.enabled",false);
		context.setVariable("ROUTING.target.ssl.key.store");
		context.setVariable("ROUTING.target.ssl.key.alias");
		context.setVariable("ROUTING.target.ssl.trust.store");
		context.setVariable("ROUTING.ssl.ciphers");
		context.setVariable("ROUTING.ssl.protocols");
		context.setVariable("ROUTING.ssl.ignore.validation.errors",false);
		expect(validateDownloadLink()).toBe();
	    expect(context.getVariable("jsonArray")).toEqual([ '{"url":"https://billingservice-es-test.myvdf.aws.cps.vodafone.com/v1/streaming/0922730f801b7ebe","backendAuth":{"fieldType":"header","fieldName":"Authorization","value":"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiZW1haWwiOiJqZDJAZXhtYXBsZS5jb20iLCJhZG1pbiI6dHJ1ZX0.DJZX3Nsuj7SN0B0XYgzKt5wWqkBlEefnCd_MRVxEmTA"},"sslInfo":{"sslEnabled":true,"clientAuthEnabled":false,"ignoreValidationErrors":false}}' ]);
	});
});