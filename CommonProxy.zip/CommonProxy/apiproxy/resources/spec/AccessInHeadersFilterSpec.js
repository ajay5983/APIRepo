/**
 * 
 */
var AccessInHeadersFilterVar = require('../jsc/AccessInHeadersFilter/AccessInHeadersFilter');
describe('AccessInHeadersFilter Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            },
            removeVariable: function(propertyName){
                this[propertyName] = '';
              }
        };
        context = new Context();
    });

    var validationInHeaders= {
							"authorization": {},
							"accept": {
								"validate": true,
								"format": "ACCEPT_HEADER",
							},
							"content-type": {
								"validate": true,
								"format": "ACCEPT_HEADER"
							},
							"vf-trace-transaction-id": {},
							"orderby": {
								"validate": true,
								"format": "DATE_TIME"
							},
							"msisdn": {
								"validate": true,
								"type": "number"
							},
							"content-type": {
								"validate": false,
								"format": "ACCEPT_HEADER"
							},
							"invalid": {
								"validate": true,
								"format": "ALPHA_NUMERIC"
							},
							"invalidtype": {
								"validate": true,
								"type": "string",
							},
							"invalidnumber": {
								"validate": true,
								"type": "number",
							},
							"invaliddate": {
								"validate": true,
								"type": "dateTime",
							},
							"notnumber": {
								"validate": true,
								"format": "NUMERIC",
							},
							"nitesh1234": {
								"validate": true,
								"format": "ALPHA_NUMERIC",
							},
							"in": {
								"validate": true,
								"format": "COUNTRY_CODE",
							}

					};  
     
    it ('Positive:1 AccessInHeadersFilter-String', function(){

		context.setVariable("validation_in_headers"," If-None-Match, Authorization, Accept-Language, vf-trace-transaction-id, orderby, User-Agent, Accept, Content-Type, vf_int_caller_id, vf_ext_trace_id, vf_ext_reference_id, vf_ext_bp_id, vf-target-stub, If-Match, If-Modified-Since, If-Unmodified-Since, If-Range, language-code, MSISDN ");
		context.setVariable("request.headers.names","[ Accept, Access-Control-Request-Headers, Access-Control-Request-Method, Content-Length, orderby, MSISDN , Content-Type, Invalid]");

		expect(AccessInHeadersFilter()).toBe();

		// expect(context.getVariable("request.header.Accept")).toBe("ACcept");
		
    });

    it ('Positive:2 AccessInHeadersFilter-JSON', function(){

		context.setVariable("validation_in_headers", validationInHeaders);
		context.setVariable("request.headers.names","[ Accept, Access-Control-Request-Headers, Access-Control-Request-Method, Content-Length]");

		expect(AccessInHeadersFilter()).toBe();

		// expect(context.getVariable("request.header.Accept")).toBe("ACcept");
		
    });


      it ('Positive:3 AccessInHeadersFilter-Headers not array', function(){

		context.setVariable("validation_in_headers", validationInHeaders);
		context.setVariable("request.headers.names", "[]");

		expect(AccessInHeadersFilter()).toBe();

		// expect(context.getVariable("request.header.Accept")).toBe("ACcept");
		
    });

      it ('Positive:4 AccessInHeadersFilter-Headers not array', function(){

		context.setVariable("validation_in_headers", validationInHeaders);
		context.setVariable("request.headers.names", "");

		expect(AccessInHeadersFilter()).toBe();

		// expect(context.getVariable("request.header.Accept")).toBe("ACcept");
		
    });

       it ('Positive:5 AccessInHeadersFilter-Headers not array', function(){

		context.setVariable("validation_in_headers", validationInHeaders);
		context.setVariable("request.headers.names", "<script/>");

		expect(AccessInHeadersFilter()).toBe();

		// expect(context.getVariable("request.header.Accept")).toBe("ACcept");
		
    });

      it ('Positive:6 AccessInHeadersFilter- Cover formats', function(){

		context.setVariable("validation_in_headers", validationInHeaders);
		context.setVariable("request.headers.names", "[ Accept, nitesh@vf.com, nitesh1234 , IN ] ");

		expect(AccessInHeadersFilter()).toBe();

		// expect(context.getVariable("request.header.Accept")).toBe("ACcept");
		
    });

      

     it ('Nigative:1 AccessInHeadersFilter-No values', function(){

		context.setVariable("validation_in_headers", "");
		context.setVariable("request.headers.names","[Accept, Access-Control-Request-Headers, Access-Control-Request-Method, Content-Length]");

		expect(AccessInHeadersFilter).toThrow();

		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
		
    });

      it ('Nigative:2 AccessInHeadersFilter-Not a JSON', function(){

		context.setVariable("validation_in_headers", JSON.stringify(validationInHeaders));
		context.setVariable("request.headers.names","[Accept, Access-Control-Request-Headers, Access-Control-Request-Method, Content-Length]");

		expect(AccessInHeadersFilter()).toBe();

		// expect(context.getVariable("request.header.Accept")).toBe("ACcept");
		
    });

   it ('Negative:3 AccessInHeadersFilter-JSON - Invalid String ', function(){

		context.setVariable("validation_in_headers", validationInHeaders);
		context.setVariable("request.headers.names","[ Accept, Access-Control-Request-Headers, Access-Control-Request-Method, Content-Length, InvalidType ]");

		expect(AccessInHeadersFilter).toThrow();

		expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_request_parameter");
		
    });

     it ('Negative:4 AccessInHeadersFilter-JSON - Invalid Number', function(){

		context.setVariable("validation_in_headers", validationInHeaders);
		context.setVariable("request.headers.names","[ Accept, Access-Control-Request-Headers, Access-Control-Request-Method, Content-Length, InvalidNumber ]");

		expect(AccessInHeadersFilter).toThrow();

		expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_request_parameter");
		
    });

       it ('Negative:5 AccessInHeadersFilter-JSON -Invalid dateTime ', function(){

		context.setVariable("validation_in_headers", validationInHeaders);
		context.setVariable("request.headers.names","[ Accept, Access-Control-Request-Headers, Access-Control-Request-Method, Content-Length , InvalidDate ]");

		expect(AccessInHeadersFilter).toThrow();

		expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_request_header_date_format");
		
    });

     it ('Negative:5 AccessInHeadersFilter- Invalid regex ', function(){

		context.setVariable("validation_in_headers", validationInHeaders);
		context.setVariable("request.headers.names", "[ Accept, Access-Control-Request-Headers, Access-Control-Request-Method, Content-Length , notnumber ]");

		expect(AccessInHeadersFilter).toThrow();

		expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_request_parameter");
		
    });
   
   	  it ('Negative:6 AccessInHeadersFilter- Headers as string', function(){

		context.setVariable("validation_in_headers", validationInHeaders);
		context.setVariable("request.headers.names", "Accept, nitesh@vf.com, nitesh1234 , IN ");

		expect(AccessInHeadersFilter).toThrow();

		expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_request_parameter");
		
    });
	
});