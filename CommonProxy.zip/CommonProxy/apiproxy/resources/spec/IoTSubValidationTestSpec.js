/**
 * 
 */
var IoTSubValidationVar = require('../jsc/IOTSubValidation/IoTSubValidation');
describe('IoTSubValidation Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });
     
    it ('Positive case1: AccessTokenACR', function() {
    	context.setVariable("accesstoken.sub","262002STATRSV");
    	context.setVariable("developer.app.id","ed0ea8c5-f812-46ce-a706-686f00ae5df2");
        context.setVariable("accesstoken.anon_cust_ref","262002STATRSV2017-12-05T08:45:06ZIODhkxcGYGsb0F4B2JyvXEuns");
        context.setVariable("accesstoken.msisdn","491622897075");
        context.setVariable("accesstoken.lastInvoketime","262002STATRSV");
        context.setVariable("UserInfo_Threshold_MilliSeconds","262002STATRSV");
        context.setVariable("accesstoken.Customer-Country-Code","DE");
        expect(subValidation()).toBe();
        expect(context.getVariable("request.header.Acr")).toBe("262002STATRSV2017-12-05T08:45:06ZIODhkxcGYGsb0F4B2JyvXEuns");
        expect(context.getVariable("request.header.Apix-App-Id")).toBe("ed0ea8c5-f812-46ce-a706-686f00ae5df2");
        expect(context.getVariable("request.header.Customer-Country-Code")).toBe("DE");
        expect(context.getVariable("inputMsisdn")).toBe("491622897075");
    });
    it ('Positive case2: AccessTokenACR', function() {
    	context.setVariable("accesstoken.sub","262002STATRSV");
    	context.setVariable("developer.app.id","ed0ea8c5-f812-46ce-a706-686f00ae5df2");
        context.setVariable("accesstoken.msisdn","491622897075");
        context.setVariable("accesstoken.lastInvoketime","262002STATRSV");
        context.setVariable("UserInfo_Threshold_MilliSeconds","262002STATRSV");
        context.setVariable("accesstoken.Customer-Country-Code","DE");
        expect(subValidation()).toBe();
        expect(context.getVariable("noACRInToken")).toBe("true");
    });
    
    it ('Positive case3: EmptyMSISDN', function() {
        context.setVariable("accesstoken.sub","262002STATRSV");
        context.setVariable("accesstoken.msisdn","");
        context.setVariable("accesstoken.anon_cust_ref","262002STATRSV2017-12-05T08:45:06ZIODhkxcGYGsb0F4B2JyvXEuns");
        expect(subValidation()).toBe();
    });
 
    it ('Positive case4: EmptyMSISDN', function() {
    	 context.setVariable("accesstoken.anon_cust_ref","");
         context.setVariable("accesstoken.msisdn","491622897075");
         expect(subValidation).toThrow();
         expect(context.getVariable("inputMsisdn")).toBe("491622897075");
         expect(context.getVariable("noACRInToken")).toBe("true");
    });
    
    it ('Positive case5: EmptyMSISDN', function() {
    	context.setVariable("accesstoken.anon_cust_ref", null);
        context.setVariable("accesstoken.msisdn",null);
        context.setVariable("accesstoken.sub","");
        expect(subValidation).toThrow();
   });
   
});