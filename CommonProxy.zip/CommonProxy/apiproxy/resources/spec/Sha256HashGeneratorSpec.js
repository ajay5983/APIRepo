/**
 * 
 */
var sha256_hash_generator = require('../jsc/Sha256HashGenerator/Sha256HashGenerator');
describe('Sha256 Hash Generator', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });
     
    it ('Positive case1: Sha256 Hash Generator', function() {
		 
		 var modJson1 = '{"url":"https://billingservice-es-test.myvdf.aws.cps.vodafone.com/v1/streaming/0922730f801b7ebe","backendAuth":{"fieldType":"header","fieldName":"Authorization","value":"Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiIwMTkyMjU3MldAbnVldm9taXZmLmVzIiwidXNyIjoiOHhXNXAya0N4SkJXYXN2RFBSWWFNRVNMSEh4cVNkMyyyyyyyyyùyyyyyyyyyEQiLCJzZWMiOiJ6dm1zKzFnUXNPZWdYYytjMHZWT1dBPT0iLCJyb2xlcyI6WyJST0xFX1VTRVIiLCJST0xFX0NPTlNVTUVSIiwiUk9MRV9DT01QTEVURSJdLCJleHAiOjE1MjAzODU4OTYsInVzZXJQcm9maWxlIjp7ImlkIjoiNjY2OTc4NzIwIiwidXNlck5hbWUiOiIwMTkyMjU3MldAbnVldm9taXZmLmVzIiwiZW1haWwiOiIwMTkyMjU3MldAbnVldm9taXZmLmVzIiwibXNpc2RuIjoiNjY2OTc4NzIwIiwiZG9jdW1lbnQiOnsiaWQiOiIwMTkyMjU3MlciLCJ0eXBlIjoiTklGIn0sImN1c3RvbWVyVHlwZSI6IkNPTlNVTUVSIiwicHJvZmlsZVR5cGUiOiJDT01QTEVURSIsImxhc3RQYXNzQ2hhbmdlRGF0ZSI6MTUxNzc1NjMzMywic2l0ZXMiOlt7ImlkIjoiMTA3OTIzNTUxIiwic3RhdHVzIjoiQWN0aXZvIiwib3ZlcmR1ZSI6ZmFsc2V9XX19.dQfQn6nrQQXB9EsnykKE2H3t2padOvFtKbETmK52nCHIbNVv0vGwWL9J9J8IwT4TX-mscCZnc0ueBnjs_cFawicNA6MMJMfjETuMESi9LcYOEuFYti6YzCrDvZHo6PScVXkhb5KppZyFKhX8mD9PlbyaHAOvIsSwDVO5D_z1PSqB2FSBdg7I6mW510bHxJv9jZ-MSJwgjNHZna12KnzvwcZVGqMMVkhivY3XzUbhEqgXrBheaHhU_lSD_-V8f8YeAAfo_u_Wt2_vxx4Kd4uKbGG-RJOODhrGIZsin2O6jqfu1ns9h5zZ5DbSqRueakYp3ZXrl-DvrmfaDf4QBrirUA"},"fileType":"pdf","method":"GET","expiryTime":"1519335000"}';
		 var modJson2 = "{}";
		 var modJson3 = '{"url":"https://billingservice-es-test.myvdf.aws.cps.vodafone.com/v1/streaming/0902730f8025fb3f","backendAuth":{"fieldType":"header","fieldName":"Authorization","value":"Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiIwMTkyMjU3MldAbnVldm9taXZmLmVzIiwidXNyIjoiOHhXNXAya0N4SkJXYXN2RFBSWWFNRVNMSEh4cVNkMEQiLCJzZWMiOiJ6dm1zKzFnUXNPZWdYYytjMHZWT1dBPT0iLCJyb2xlcyI6WyJST0xFX1VTRVIiLCJST0xFX0NPTlNVTUVSIiwiUk9MRV9DT01QTEVURSJdLCJleHAiOjE1MjAzODU4OTYsInVzZXJQcm9maWxlIjp7ImlkIjoiNjY2OTc4NzIwIiwidXNlck5hbWUiOiIwMTkyMjU3MldAbnVldm9taXZmLmVzIiwiZW1haWwiOiIwMTkyMjU3MldAbnVldm9taXZmLmVzIiwibXNpc2RuIjoiNjY2OTc4NzIwIiwiZG9jdW1lbnQiOnsiaWQiOiIwMTkyMjU3MlciLCJ0eXBlIjoiTklGIn0sImN1c3RvbWVyVHlwZSI6IkNPTlNVTUVSIiwicHJvZmlsZVR5cGUiOiJDT01QTEVURSIsImxhc3RQYXNzQ2hhbmdlRGF0ZSI6MTUxNzc1NjMzMywic2l0ZXMiOlt7ImlkIjoiMTA3OTIzNTUxIiwic3RhdHVzIjoiQWN0aXZvIiwib3ZlcmR1ZSI6ZmFsc2V9XX19.dQfQn6nrQQXB9EsnykKE2H3t2padOvFtKbETmK52nCHIbNVv0vGwWL9J9J8IwT4TX-mscCZnc0ueBnjs_cFawicNA6MMJMfjETuMESi9LcYOEuFYti6YzCrDvZHo6PScVXkhb5KppZyFKhX8mD9PlbyaHAOvIsSwDVO5D_z1PSqB2FSBdg7I6mW510bHxJv9jZ-MSJwgjNHZna12KnzvwcZVGqMMVkhivY3XzUbhEqgXrBheaHhU_lSD_-V8f8YeAAfo_u_Wt2_vxx4Kd4uKbGG-RJOODhrGIZsin2O6jqfu1ns9h5zZ5DbSqRueakYp3ZXrl-DvrmfaDf4QBrirUA"},"fileType":"txt","method":"GET","expiryTime":"1519507800"}';
		 var modJson4 = "{\"url\":\"https:\/\/www.google.co.in\/search?q=url+which+satisfies+the+all+conditions+of+sha2+code+generation&rlz=1C1GCEA_enIN760IN760&oq=url+which+satisfies+the+all+conditions+of+sha2+code+generation&aqÑ//s=chrome..69i57.31038j0j7&sourceid=chrome&ie=UTF-8\",\"backendAuth\":{\"fieldType\":\"header\",\"fieldName\":\"Authorization\",\"value\":\"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiZW1haWwiOiJqZDJAZXhtYXBsZS5jb20iLCJhZG1pbiI6dHJ1ZX0.DJZX3Nsuj7SN0B0XYgzKt5wWqkBlEefnCd_MRVxEmTA\"},\"fileType\":\"application\/pdf\",\"msisdn\":\"4545454241a5\",\"sub\":\"54241a5\",\"acr\":\"45454542\",\"expiryTime\": 1512132000}";
		 var modJson5 = "{\"url\":\"https:\/\/www.google.co.in\/search?q=url+which+satisfies+the+all+conditions+of+sha2+code+generation&rlz=1C1GCEA_enIN760IN760&oq=url+which+satisfies+the+all+conditions+of+sha2+code+generation&aqࠁ//s=chrome..69i57.31038j0j7&sourceid=chrome&ie=UTF-8\",\"backendAuth\":{\"fieldType\":\"header\",\"fieldName\":\"Authorization\",\"value\":\"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiZW1haWwiOiJqZDJAZXhtYXBsZS5jb20iLCJhZG1pbiI6dHJ1ZX0.DJZX3Nsuj7SN0B0XYgzKt5wWqkBlEefnCd_MRVxEmTA\"},\"fileType\":\"application\/pdf\",\"msisdn\":\"4545454241a5\",\"sub\":\"54241a5\",\"acr\":\"45454542\",\"expiryTime\": 1512132000}"
		 
		 var arrayJson = [];
		 arrayJson.push(JSON.stringify(modJson1));
		 arrayJson.push(JSON.stringify(modJson2));
		 arrayJson.push(JSON.stringify(modJson3));
		 arrayJson.push(JSON.stringify(modJson4));
		 arrayJson.push(JSON.stringify(modJson5));
		 
		context.setVariable("jsonArray",arrayJson);
		context.setVariable("cacheExpiryTime","1349100,,1521900");
		expect(sha256HashGenerator()).toBe();
		expect(context.getVariable("sha2codeArray")).toBe("dfd563d26f6f1ba799ee1ab42ffaf4e94bc8b10277a01f488712b590e024c1c9,c89a148be40e6752261e3038609a4b68de22fa3bfdaf32f884edffb8480b9bbe,f6607633d460e27d6c38bc0ff4405654d04df4de2340b65d0a67f37a88fa7393,ec4e52938ea8724974be492680ba8f2077546d2f3f492b215e27ef15ef421519,b7c799d70d8363acb15436c74de153f728e1535ceb85b8250ce3ccfaeeceeaf1");
		expect(context.getVariable("cacheExpiryTime")).toBe('1349100,,1521900');		
    });
	
	it ('Positive case2: Sha256 Hash Generator', function() {
		 
		 
		var modJson2 = {};
		var arrayJson = [];
		 
		arrayJson.push(JSON.stringify(modJson2));
		context.setVariable("jsonArray",arrayJson);
		context.setVariable("cacheExpiryTime"," ");
		expect(sha256HashGenerator()).toBe();
		expect(context.getVariable("sha2codeArray")).toBe('');
		expect(context.getVariable("cacheExpiryTime")).toBe(' ');		
    });
	
	it ('Positive case3: Sha256 Hash Generator, if jsonArray is empty', function() {
		 
		var arrayJson = [];
		context.setVariable("jsonArray",arrayJson);
		context.setVariable("cacheExpiryTime","1349100,,1521900");
		expect(sha256HashGenerator()).toBe();
		expect(context.getVariable("sha2codeArray")).toBe("");
		expect(context.getVariable("cacheExpiryTime")).toBe('1349100,,1521900');		
    });
	
	it ('Positive case4: Sha256 Hash Generator, if json array is empty', function() {
		 
		var arrayJson = '';
		 
		context.setVariable("jsonArray",arrayJson);
		context.setVariable("cacheExpiryTime"," ");
		expect(sha256HashGenerator()).toBe();
		expect(context.getVariable("sha2codeArray")).toBe('');
		expect(context.getVariable("cacheExpiryTime")).toBe(' ');		
    });
    
});