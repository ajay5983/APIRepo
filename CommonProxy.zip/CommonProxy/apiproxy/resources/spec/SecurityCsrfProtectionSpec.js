var SecurityCsrfProtectionNew = require('../jsc/SecurityCsrfProtection/SecurityCsrfProtection');

describe('CSRF Validation Suites', function() {
	
    beforeEach(function(){
      var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });
    it ('1: Positive: if csrf header is same as Cookie: 2 cookies', function() {
		context.setVariable("request.header.vf-csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		context.setVariable("request.header.Cookie","refresh-token=gHD21krxrUnXwWWHkBe69cLUZReoKDJc;csrf-token=aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		context.setVariable("request.header.Authorization","Bearer VJyxR1DdZes4nSRXDlojCugRPYq6");
		context.setVariable("accesstoken.csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
        expect(securityCsrfProtection()).toBe();
		expect(context.getVariable("errorJSON")).toBe(undefined);
    });
    it ('2: Positive: if csrf header is same as Cookie: 2 cookies, csrf-token as 1st one', function() {
		context.setVariable("request.header.vf-csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		context.setVariable("request.header.Cookie","csrf-token=aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4; refresh-token=gHD21krxrUnXwWWHkBe69cLUZReoKDJc");
		context.setVariable("request.header.Authorization","Bearer VJyxR1DdZes4nSRXDlojCugRPYq6");
		context.setVariable("accesstoken.csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
        expect(securityCsrfProtection()).toBe();
		expect(context.getVariable("errorJSON")).toBe(undefined);
    });
    it ('3: Positive: if csrf header is same as Cookie: 3 cookies', function() {
		context.setVariable("request.header.vf-csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		context.setVariable("request.header.Cookie","refresh-token=gHD21krxrUnXwWWHkBe69cLUZReoKDJc; csrf-token=aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4; some-token=123456qwsedr");
		context.setVariable("request.header.Authorization","Bearer VJyxR1DdZes4nSRXDlojCugRPYq6");
		context.setVariable("accesstoken.csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
        expect(securityCsrfProtection()).toBe();
		expect(context.getVariable("errorJSON")).toBe(undefined);
    });
    it ('4: Positive: if csrf header is same as Cookie: 2 cookies with tab/space', function() {
		context.setVariable("request.header.vf-csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		context.setVariable("request.header.Cookie","refresh-token=			gHD21krxrUnXwWWHkBe69cLUZReoKDJc;some-token=123456qwsedr;  csrf-token=aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		context.setVariable("request.header.Authorization","Bearer VJyxR1DdZes4nSRXDlojCugRPYq6");
		context.setVariable("accesstoken.csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
        expect(securityCsrfProtection()).toBe();
		expect(context.getVariable("errorJSON")).toBe(undefined);
    });
    it ('5: Positive: if csrf header is same as Cookie: 3 cookies with multiple spaces', function() {
		context.setVariable("request.header.vf-csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		context.setVariable("request.header.Cookie","refresh-token=gHD21krxrUnXwWWHkBe69cLUZReoKDJc; some-token=123456qwsedr;                                                         csrf-token=aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4;some-token2=wdefghgfthj");
		context.setVariable("request.header.Authorization","Bearer VJyxR1DdZes4nSRXDlojCugRPYq6");
		context.setVariable("accesstoken.csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
        expect(securityCsrfProtection()).toBe();
		expect(context.getVariable("errorJSON")).toBe(undefined);
    });
    it ('6: Positive: if csrf header is same as Cookie: 3 cookies with no spaces', function() {
		context.setVariable("request.header.vf-csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		context.setVariable("request.header.Cookie","refresh-token=gHD21krxrUnXwWWHkBe69cLUZReoKDJc;csrf-token=aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4;some-token=123456qwsedr");
		context.setVariable("request.header.Authorization","Bearer VJyxR1DdZes4nSRXDlojCugRPYq6");
		context.setVariable("accesstoken.csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
        expect(securityCsrfProtection()).toBe();
		expect(context.getVariable("errorJSON")).toBe(undefined);
    });
    it ('7: Positive: if csrf header is same as Cookie: 1 cookie', function() {
		context.setVariable("request.header.vf-csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		context.setVariable("request.header.Cookie","csrf-token=aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		context.setVariable("request.header.Authorization","Bearer VJyxR1DdZes4nSRXDlojCugRPYq6");
		context.setVariable("accesstoken.csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
        expect(securityCsrfProtection()).toBe();
		expect(context.getVariable("errorJSON")).toBe(undefined);
    });
    it ('8: Negative: No cookie, no vf-csrf-token', function() {
		//context.setVariable("request.header.vf-csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		//context.setVariable("request.header.Cookie","csrf-token=aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		context.setVariable("request.header.Authorization","Bearer VJyxR1DdZes4nSRXDlojCugRPYq6");
		context.setVariable("accesstoken.csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
        expect(securityCsrfProtection()).toBe();
		expect(context.getVariable("errorJSON")).toBe(undefined);
    });
    it ('9: Negative: if Cookie not present but vf-csrf-token is present', function() {
		context.setVariable("request.header.vf-csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		//context.setVariable("request.header.Cookie","csrf-token=aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		context.setVariable("request.header.Authorization","Bearer VJyxR1DdZes4nSRXDlojCugRPYq6");
		context.setVariable("accesstoken.csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
        expect(securityCsrfProtection).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_forbidden_error");
    });
    it ('10: Negative: if vf-csrf-token is not present but Cookie is present', function() {
		context.setVariable("request.header.vf-csrf-token","");
		context.setVariable("request.header.Cookie","csrf-token=aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		context.setVariable("request.header.Authorization","Bearer VJyxR1DdZes4nSRXDlojCugRPYq6");
		context.setVariable("accesstoken.csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
        expect(securityCsrfProtection).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_forbidden_error");
    });
    it ('11: Positive: if vf-csrf-token not present & Cookie are present but no csrf-token cookie', function() {
		//context.setVariable("request.header.vf-csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		context.setVariable("request.header.Cookie","refresh-token=aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		context.setVariable("request.header.Authorization","Bearer VJyxR1DdZes4nSRXDlojCugRPYq6");
		context.setVariable("accesstoken.csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
        expect(securityCsrfProtection()).toBe();
		expect(context.getVariable("errorJSON")).toBe(undefined);
    });
    it ('12: Positive: Auth header not present', function() {
		//context.setVariable("request.header.vf-csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		context.setVariable("request.header.Cookie","refresh-token=aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		//context.setVariable("request.header.Authorization","Bearer VJyxR1DdZes4nSRXDlojCugRPYq6");
		context.setVariable("accesstoken.csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
        expect(securityCsrfProtection()).toBe();
		expect(context.getVariable("errorJSON")).toBe(undefined);
    });	
    it ('13: Negative: if vf-csrf-token is missing', function() {
		context.setVariable("request.header.Cookie","refresh-token=gHD21krxrUnXwWWHkBe69cLUZReoKDJc; csrf-token=aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
        expect(securityCsrfProtection).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_forbidden_error");
    });
    it ('14: Negative: if csrf header is same as Cookie: access tokens csrf-token different', function() {
		context.setVariable("request.header.vf-csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		context.setVariable("request.header.Cookie","refresh-token=gHD21krxrUnXwWWHkBe69cLUZReoKDJc; csrf-token=aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
        context.setVariable("request.header.Authorization","Bearer VJyxR1DdZes4nSRXDlojCugRPYq6");
		context.setVariable("accesstoken.csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4123");
		expect(securityCsrfProtection).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_forbidden_error");
    });
	it ('15: Negative: if csrf header is not same as Cookie', function() {
		context.setVariable("request.header.vf-csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		context.setVariable("request.header.Cookie","refresh-token=gHD21krxrUnXwWWHkBe69cLUZReoKDJc; csrf-token=123aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		context.setVariable("request.header.Authorization","Bearer VJyxR1DdZes4nSRXDlojCugRPYq6");
		context.setVariable("accesstoken.csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
        expect(securityCsrfProtection).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_forbidden_error");
    });
	it ('16: Negative: if csrf header and csrfTokenCookie is empty', function() {
		context.setVariable("request.header.vf-csrf-token","");
		context.setVariable("request.header.Cookie","refresh-token=gHD21krxrUnXwWWHkBe69cLUZReoKDJc; ");
		context.setVariable("request.header.Authorization","Bearer VJyxR1DdZes4nSRXDlojCugRPYq6");
		context.setVariable("accesstoken.csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
        expect(securityCsrfProtection()).toBe();
		expect(context.getVariable("errorJSON")).toBe(undefined);
    });
	  it ('17: Negative: if auth token is null', function() {
		context.setVariable("request.header.vf-csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		context.setVariable("request.header.Cookie","refresh-token=gHD21krxrUnXwWWHkBe69cLUZReoKDJc; csrf-token=aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4");
		context.setVariable("request.header.Authorization","");
		context.setVariable("accesstoken.csrf-token","aoxHXAWS-OEOfkYWaxfdzWNtgqBFQkPOx1e4123");
        expect(securityCsrfProtection()).toBe();
		expect(context.getVariable("errorJSON")).toBe(undefined);
    });
	 
});