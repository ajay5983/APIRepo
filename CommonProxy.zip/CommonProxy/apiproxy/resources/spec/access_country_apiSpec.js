/**
 * 
 */
var accessCountryApiVar = require('../jsc/accessCountryApi/access_country_api');
describe('access_country_api Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });
     
    it ('Positive case1: validwhitelsitedCountry', function() {
        context.setVariable("countryISO","DE");
        var runtime_whitelisting ={"988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES" } };
        context.setVariable("runtime_whitelisting",JSON.stringify(runtime_whitelisting));
        context.setVariable("developer_organization_id","988fbeda-692d-4ce6-bbc3-4d492855d8d6");
       expect(accessCountryApi()).toBe(true);
       expect(context.getVariable("errorJSON")).toBe(undefined);
    });
    it ('Positive case2: emptywhiteListedCountry', function() {
        context.setVariable("countryISO","DE");
        var runtime_whitelisting ={"988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "" } };
        context.setVariable("runtime_whitelisting",JSON.stringify(runtime_whitelisting));
        context.setVariable("developer_organization_id","988fbeda-692d-4ce6-bbc3-4d492855d8d6");
       expect(accessCountryApi()).toBe(true);
       expect(context.getVariable("errorJSON")).toBe(undefined);
    });
    it ('Negative Case1: InvalidCountry', function() {
        context.setVariable("countryISO","IT");
        var runtime_whitelisting ={"988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES" } };
        context.setVariable("runtime_whitelisting",JSON.stringify(runtime_whitelisting));
        context.setVariable("developer_organization_id","988fbeda-692d-4ce6-bbc3-4d492855d8d6");
       expect(accessCountryApi).toThrow();
       expect(context.getVariable("errorJSON")).toBe('a42_generic_invalid_country_id');
    });
    it ('Negative Case2: InvalidOrgID', function() {
        context.setVariable("countryISO","DE");
        var runtime_whitelisting ={"988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES" } };
        context.setVariable("runtime_whitelisting",JSON.stringify(runtime_whitelisting));
        context.setVariable("developer_organization_id","988fbeda-692d-4ce6-bbc3-4d492855d8d7");
       expect(accessCountryApi).toThrow();
       expect(context.getVariable("errorJSON")).toBe('a42_generic_internal_config_error');
    });
    it ('Negative Case3: emptyCountryCode', function() {
        context.setVariable("countryISO","");
        var runtime_whitelisting ={"988fbeda-692d-4ce6-bbc3-4d492855d8d6": { "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES" } };
        context.setVariable("runtime_whitelisting",JSON.stringify(runtime_whitelisting));
        context.setVariable("developer_organization_id","988fbeda-692d-4ce6-bbc3-4d492855d8d6");
       expect(accessCountryApi).toThrow();
       expect(context.getVariable("errorJSON")).toBe('a42_generic_internal_config_error');
    });
    it ('Negative Case4: invalidKVMJson', function() {
        context.setVariable("countryISO","DE");
        var runtime_whitelisting ='{"988fbeda-692d-4ce6-bbc3-4d492855d8d6":  "COUNTRIES_BLACKLISTED": "", "COUNTRIES_WHITELISTED": "DE,ES" } }';
        context.setVariable("runtime_whitelisting",runtime_whitelisting);
        context.setVariable("developer_organization_id","988fbeda-692d-4ce6-bbc3-4d492855d8d6");
       expect(accessCountryApi).toThrow();;
    });
});