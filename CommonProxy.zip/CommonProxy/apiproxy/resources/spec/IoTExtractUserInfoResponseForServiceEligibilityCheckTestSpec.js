/**
 * 
 */
var IoTExtractUserInfoResponseVar = require('../jsc/IOTExtractUserInfoResForServiceEligibility/IoTExtractUserInfoResponseForServiceEligibilityCheck');
describe('IoTExtractUserInfoResponseForServiceEligibilityCheck Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });
     
   it ('Positive case1: BackendResponse', function() {
        var userInfoResponse = {"jwe": "eyJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiQTI1NktXIn0.KqZvd0D70Hj6mZcCKfz-J7BXqDes3kvotnG"};
        context.setVariable("IoTUserInfoCalloutForServiceEligibilityCheckResponse.content",JSON.stringify(userInfoResponse));
        context.setVariable("IoTUserInfoCalloutForServiceEligibilityCheckResponse.status.code","200");
        context.setVariable("IoTUserInfoCalloutForServiceEligibilityCheckResponse.reason.phrase","200");
        context.setVariable("IoTUserInfoCalloutForServiceEligibilityCheckResponse.header.Cache-Control","no-cache");
        context.setVariable("IoTUserInfoCalloutForServiceEligibilityCheckResponse.header.Pragma","no-store");
        expect(extractUserInfoResponseForServiceEligy()).toBe();
    });
     
     
     it ('Positive case2: BackEnd Response', function() {
    	 var userInfoResponse ={"jwe": "eyJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiQTI1NktXIn0.KqZvd0D70Hj6mZcCKfz-J7BXqDes3kvotnG"};
    	 context.setVariable("IoTUserInfoCalloutForServiceEligibilityCheckResponse.content",JSON.stringify(userInfoResponse));
         context.setVariable("IoTUserInfoCalloutForServiceEligibilityCheckResponse.status.code","500");
         expect(extractUserInfoResponseForServiceEligy()).toBe();
     });
     
     it ('Positive case3: BackEnd Response', function() {
    	 var userInfoResponse =null;
    	 context.setVariable("IoTUserInfoCalloutForServiceEligibilityCheckResponse.content",JSON.stringify(userInfoResponse));
    	 context.setVariable("IoTUserInfoCalloutForServiceEligibilityCheckResponse.status.code","200");
         expect(extractUserInfoResponseForServiceEligy()).toBe();
     });
     
   
});