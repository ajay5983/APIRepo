require('../jsc/a42HomeDocGenerate/PrepareHomeDocumentResponse');

describe('Home Document Generation Test Suites', function() {
	
    beforeEach(function(){
      var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });

 /*it ('Positive: Home Doc response with proper values', function() {
	context.setVariable("home_doc_rules", "{\"scopes\":{\"AB\":[\"http://a42.vodafone.com/rels/pushnotification-templates/create-template\",\"http://a42.vodafone.com/rels/pushnotification-templates/template-push\"],\"CD\":[\"http://a42.vodafone.com/rels/pushnotification-templates/update-template\",\"http://a42.vodafone.com/rels/pushnotification-templates/template-push\"]}}");
	context.setVariable("home_doc_definitions", "[{\"self\": {\"href\": \"https://{apix.endpoint}/v1/pushnotification-templates/\"}},{\"http://a42.vodafone.com/rels/pushnotification-templates/create-template\": {\"href\": \"https://{apix.endpoint}/v1/pushnotification-templates/templates\",\"title\": \"Create a new template\",\"method\": \"POST\"}},{\"http://a42.vodafone.com/rels/pushnotification-templates/template-push\": {\"href\": \"https://{apix.endpoint}/v1/pushnotification-templates/push\",\"title\": \"Send push notifications using a template\",\"method\": \"POST\"}}]");
	context.setVariable("home_doc_expiry_in_seconds", "84600");
	context.setVariable("request.header.host", "apidev.developer.vodafone.com");
	context.setVariable("sortedScopes", "AB,BC,CD");
	var resp = "{\"links\":{\"self\":{\"href\":\"https://{apix.endpoint}/v1/pushnotification-templates/\"},\"http://a42.vodafone.com/rels/pushnotification-templates/create-template\":{\"href\":\"https://{apix.endpoint}/v1/pushnotification-templates/templates\",\"title\":\"Create a new template\",\"method\":\"POST\"},\"http://a42.vodafone.com/rels/pushnotification-templates/template-push\":{\"href\":\"https://{apix.endpoint}/v1/pushnotification-templates/push\",\"title\":\"Send push notifications using a template\",\"method\":\"POST\"}}}"
	var validResp = resp.replace(/{apix.endpoint}/g, "apidev.developer.vodafone");
        expect(PrepareHomeDocumentResponse()).toBe();
       
        expect(context.getVariable("homeDocResponse")).toBe(validResp);
    });*/

it ('Negative: If Home_Doc_Rule is empty', function() {
    context.setVariable("home_doc_rules", ""); 
	expect(PrepareHomeDocumentResponse).toThrow();
        expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    });
it ('Negative: If Home_Doc_Rule is null', function() {
    context.setVariable("home_doc_rules", null);  
	expect(PrepareHomeDocumentResponse).toThrow();
        expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    });
it ('Negative: If Home_Doc_Definition is empty', function() {
    context.setVariable("home_doc_rules", "{\"AB\":\"CD\"}"); 
    context.setVariable("home_doc_definitions", ""); 
	expect(PrepareHomeDocumentResponse).toThrow();
        expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    });
it ('Negative: If Home_Doc_Rule and Home_Doc_Definition json is invalid', function() {
    context.setVariable("home_doc_rules", "AB"); 
    context.setVariable("home_doc_definitions", "BC"); 
    context.setVariable("home_doc_expiry_in_seconds", "1234"); 
    context.setVariable("sortedScopes", "AB BC"); 
	expect(PrepareHomeDocumentResponse).toThrow();
        expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    });
it ('Negative: Home_Doc_expiry is empty', function() {
    context.setVariable("home_doc_rules", "{\"AB\":\"CD\"}"); 
    context.setVariable("home_doc_definitions", "{\"ABS\":\"PQR\"}"); 
    context.setVariable("home_doc_expiry_in_seconds", "");
	expect(PrepareHomeDocumentResponse).toThrow();
        expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    });
it ('Positive: All values are correct', function() {
    context.setVariable("home_doc_rules", "{\"AB\":\"CD\"}"); 
    context.setVariable("home_doc_definitions", "{\"ABS\":\"PQR\"}"); 
    context.setVariable("home_doc_expiry_in_seconds", "1234");
	expect(PrepareHomeDocumentResponse).toThrow();
        expect(context.getVariable("errorJSON")).toBe(undefined);
    });
it ('Negative: Home Doc paramters are null', function() {
    context.setVariable("home_doc_rules", null); 
    context.setVariable("home_doc_definitions", null); 
    context.setVariable("home_doc_expiry_in_seconds", null);
	expect(PrepareHomeDocumentResponse).toThrow();
        expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    });
it ('Negative: Home Doc paramters are undefined', function() {
    context.setVariable("home_doc_rules", undefined); 
    context.setVariable("home_doc_definitions", undefined); 
    context.setVariable("home_doc_expiry_in_seconds", "1234");
	expect(PrepareHomeDocumentResponse).toThrow();
        expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
    });
});
