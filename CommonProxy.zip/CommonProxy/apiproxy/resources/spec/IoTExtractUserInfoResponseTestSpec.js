/**
 * 
 */
var IoTExtractUserInfoResponseVar = require('../jsc/IOTExtractUserInfoResponse/IoTExtractUserInfoResponse');
describe('IoTExtractUserInfoResponse Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });
     
    it ('Positive case1: BackendResponse', function() {
        var userInfoResponse = {"jwe": "eyJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiQTI1NktXIn0.KqZvd0D70Hj6mZcCKfz-J7BXqDes3kvotnG"};
        context.setVariable("IoTUserInfoCalloutResponse.content",JSON.stringify(userInfoResponse));
        context.setVariable("IoTUserInfoCalloutResponse.status.code","200");
        context.setVariable("IoTUserInfoCalloutResponse.reason.phrase","200");
        context.setVariable("IoTUserInfoCalloutResponse.header.Cache-Control","no-cache");
        context.setVariable("IoTUserInfoCalloutResponse.header.Pragma","no-store");
        expect(extractUserInfoResponse()).toBe();
    });
     
     
     it ('Positive case1: BackEnd Response', function() {
    	 var userInfoResponse ={"jwe": "eyJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiQTI1NktXIn0.KqZvd0D70Hj6mZcCKfz-J7BXqDes3kvotnG"};
    	 context.setVariable("IoTUserInfoCalloutResponse.content",JSON.stringify(userInfoResponse));
         context.setVariable("IoTUserInfoCalloutResponse.status.code","500");
         expect(extractUserInfoResponse).toThrow("InternalUserInforError");
     });
     
     it ('Positive case1: BackEnd Response', function() {
    	 var userInfoResponse = {"jwe": ""};;
    	 context.setVariable("IoTUserInfoCalloutResponse.content",JSON.stringify(userInfoResponse));
         context.setVariable("IoTUserInfoCalloutResponse.status.code","200");
         expect(extractUserInfoResponse()).toBe();
     });
     
   
});