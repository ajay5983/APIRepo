require('../jsc/ProcessNetworkCorsPreflightRequest/Process.Network.Cors.Preflight.Request');

describe('Cors Preflight Request Test Suites', function() {
	
    beforeEach(function(){
      var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });

it ('1: Positive: All Cors Parameters (Origin, method, header) are valid', function() {
    context.setVariable("request.header.Origin", "https://apixstaging.developer.vodafone.com");
    context.setVariable("cors_allowed_origins_common", "apixstaging.developer.vodafone.com,apixstagingref.developer.vodafone.com,developer.vodafone.com,confluence.sp.vodafone.com");
    context.setVariable("cors_allowed_origins", "domain1.com");
    context.setVariable("request.header.Access-Control-Request-Method", "GET");
    context.setVariable("cors_allowed_methods", "GET,POST");
    context.setVariable("request.header.Access-Control-Request-Headers", "vf-trace-transaction-id");
    context.setVariable("request.header.Access-Control-Request-Headers.values", "[vf-trace-transaction-id,x-vf-ext-trace-id]");
    context.setVariable("cors_allowed_headers", "vf-trace-transaction-id,x-vf-ext-trace-id,x-vf-ext-reference-id,authorization,content-type,accept");

    expect(corsPreflightRequest()).toBe();
	expect(context.getVariable("origin")).toBe("https://apixstaging.developer.vodafone.com");
	expect(context.getVariable("accessControlAllowMethod")).toBe("GET"); 
	expect(context.getVariable("accessControlAllowHeaders")).toBe("vf-trace-transaction-id,x-vf-ext-trace-id"); 
	
    expect(context.getVariable("isValidPreflightRequest")).toBe(true);
});
it ('2: Negative: Requested Origin is not valid', function() {
    context.setVariable("request.header.Origin", "https://abc.developer.vodafone.com");
    context.setVariable("cors_allowed_origins_common", "apixstaging.developer.vodafone.com,apixstagingref.developer.vodafone.com,developer.vodafone.com,confluence.sp.vodafone.com");
    context.setVariable("cors_allowed_origins", "domain1.com");
    context.setVariable("request.header.Access-Control-Request-Method", "GET");
    context.setVariable("cors_allowed_methods", "GET,POST");
    context.setVariable("request.header.Access-Control-Request-Headers", "vf-trace-transaction-id");
    context.setVariable("request.header.Access-Control-Request-Headers.values", "[vf-trace-transaction-id,x-vf-ext-trace-id]");
    context.setVariable("cors_allowed_headers", "vf-trace-transaction-id,x-vf-ext-trace-id,x-vf-ext-reference-id,authorization,content-type,accept");
    
	expect(corsPreflightRequest()).toBe();
	expect(context.getVariable("origin")).toBe(undefined);
	expect(context.getVariable("accessControlAllowMethod")).toBe("GET"); 
	expect(context.getVariable("accessControlAllowHeaders")).toBe("vf-trace-transaction-id,x-vf-ext-trace-id"); 
    expect(context.getVariable("isValidPreflightRequest")).toBe(false);
});
it ('3: Negative: Requested Method is not valid', function() {
    context.setVariable("request.header.Origin", "https://apixstaging.developer.vodafone.com");
    context.setVariable("cors_allowed_origins_common", "apixstaging.developer.vodafone.com,apixstagingref.developer.vodafone.com,developer.vodafone.com,confluence.sp.vodafone.com");
    context.setVariable("cors_allowed_origins", "domain1.com");
    context.setVariable("request.header.Access-Control-Request-Method", "PUT");
    context.setVariable("cors_allowed_methods", "GET,POST");
    context.setVariable("request.header.Access-Control-Request-Headers", "vf-trace-transaction-id");
    context.setVariable("request.header.Access-Control-Request-Headers.values", "[vf-trace-transaction-id,x-vf-ext-trace-id]");
    context.setVariable("cors_allowed_headers", "vf-trace-transaction-id,x-vf-ext-trace-id,x-vf-ext-reference-id,authorization,content-type,accept");
    
	expect(corsPreflightRequest()).toBe();
	expect(context.getVariable("origin")).toBe("https://apixstaging.developer.vodafone.com");
	expect(context.getVariable("accessControlAllowMethod")).toBe(undefined); 
	expect(context.getVariable("accessControlAllowHeaders")).toBe("vf-trace-transaction-id,x-vf-ext-trace-id"); 
    expect(context.getVariable("isValidPreflightRequest")).toBe(false);
});
it ('4: Negative: Requested Header is not valid', function() {
    context.setVariable("request.header.Origin", "https://apixstaging.developer.vodafone.com");
    context.setVariable("cors_allowed_origins_common", "apixstaging.developer.vodafone.com,apixstagingref.developer.vodafone.com,developer.vodafone.com,confluence.sp.vodafone.com");
    context.setVariable("cors_allowed_origins", "domain1.com");
    context.setVariable("request.header.Access-Control-Request-Method", "GET");
    context.setVariable("cors_allowed_methods", "GET,POST");
    context.setVariable("request.header.Access-Control-Request-Headers", "vf-trace-transaction-id");
    context.setVariable("request.header.Access-Control-Request-Headers.values", "[vf-trace-transaction-id,x-vf-ext-trace-id,abc]");
    context.setVariable("cors_allowed_headers", "vf-trace-transaction-id,x-vf-ext-trace-id,x-vf-ext-reference-id,authorization,content-type,accept");
    
	expect(corsPreflightRequest()).toBe();
	expect(context.getVariable("origin")).toBe("https://apixstaging.developer.vodafone.com");
	expect(context.getVariable("accessControlAllowMethod")).toBe("GET"); 
	expect(context.getVariable("accessControlAllowHeaders")).toBe(undefined); 
    expect(context.getVariable("isValidPreflightRequest")).toBe(false);
});
it ('5: Negative: If Origin is missing', function() {
    context.setVariable("request.header.Origin", "");
    context.setVariable("cors_allowed_origins_common", "apixstaging.developer.vodafone.com,apixstagingref.developer.vodafone.com,developer.vodafone.com,confluence.sp.vodafone.com");
    context.setVariable("cors_allowed_origins", "domain1.com");
    context.setVariable("request.header.Access-Control-Request-Method", "GET");
    context.setVariable("cors_allowed_methods", "GET,POST");
    context.setVariable("request.header.Access-Control-Request-Headers", "vf-trace-transaction-id");
    context.setVariable("request.header.Access-Control-Request-Headers.values", "[vf-trace-transaction-id,x-vf-ext-trace-id]");
    context.setVariable("cors_allowed_headers", "vf-trace-transaction-id,x-vf-ext-trace-id,x-vf-ext-reference-id,authorization,content-type,accept");
    
	expect(corsPreflightRequest()).toBe();
	expect(context.getVariable("origin")).toBe(undefined);
	expect(context.getVariable("accessControlAllowMethod")).toBe("GET"); 
	expect(context.getVariable("accessControlAllowHeaders")).not.toBe(undefined); 
    expect(context.getVariable("isValidPreflightRequest")).toBe(false);
});
it ('6: Negative: If All cors request params empty or missing', function() {
    context.setVariable("request.header.Origin", "");
    context.setVariable("cors_allowed_origins_common", "apixstaging.developer.vodafone.com,apixstagingref.developer.vodafone.com,developer.vodafone.com,confluence.sp.vodafone.com");
    context.setVariable("cors_allowed_origins", "domain1.com");
    context.setVariable("cors_allowed_methods", "GET,POST");
    context.setVariable("request.header.Access-Control-Request-Headers", "");
    context.setVariable("request.header.Access-Control-Request-Headers.values", "");
    context.setVariable("cors_allowed_headers", "vf-trace-transaction-id,x-vf-ext-trace-id,x-vf-ext-reference-id,authorization,content-type,accept");
    
	expect(corsPreflightRequest()).toBe();
	expect(context.getVariable("origin")).toBe(undefined);
	expect(context.getVariable("accessControlAllowMethod")).toBe(undefined); 
	expect(context.getVariable("accessControlAllowHeaders")).toBe(undefined); 
	expect(context.getVariable("isValidPreflightRequest")).toBe(false);
});
it ('7: Negative: If Global origin is not present ', function() {
    context.setVariable("request.header.Origin", "https://domain1.com");
    context.setVariable("cors_allowed_origins", "domain1.com,domain1.com");
    context.setVariable("cors_allowed_methods", "GET,POST");
    context.setVariable("request.header.Access-Control-Request-Method", "GET");
    context.setVariable("request.header.Access-Control-Request-Headers", "vf-trace-transaction-id");
    context.setVariable("request.header.Access-Control-Request-Headers.values", "[vf-trace-transaction-id]");
    context.setVariable("cors_allowed_headers", "vf-trace-transaction-id,x-vf-ext-trace-id,x-vf-ext-reference-id,authorization,content-type,accept");
    
	expect(corsPreflightRequest()).toBe();
	expect(context.getVariable("origin")).toBe("https://domain1.com");
	expect(context.getVariable("accessControlAllowMethod")).toBe("GET"); 
	expect(context.getVariable("accessControlAllowHeaders")).toBe("vf-trace-transaction-id"); 
	expect(context.getVariable("isValidPreflightRequest")).toBe(true);
});
it ('8: Negative: If API specific origins are not present ', function() {
    context.setVariable("request.header.Origin", "apixstaging.developer.vodafone.com");
    context.setVariable("cors_allowed_origins_common", "apixstaging.developer.vodafone.com,apixstagingref.developer.vodafone.com,developer.vodafone.com,confluence.sp.vodafone.com");
    context.setVariable("cors_allowed_origins", null);
    context.setVariable("cors_allowed_methods", "GET,POST");
    context.setVariable("request.header.Access-Control-Request-Method", "GET");
    context.setVariable("request.header.Access-Control-Request-Headers", "vf-trace-transaction-id");
    context.setVariable("request.header.Access-Control-Request-Headers.values", "[vf-trace-transaction-id]");
    context.setVariable("cors_allowed_headers", "vf-trace-transaction-id,x-vf-ext-trace-id,x-vf-ext-reference-id,authorization,content-type,accept");
    
	expect(corsPreflightRequest()).toBe();
	expect(context.getVariable("origin")).toBe("apixstaging.developer.vodafone.com");
	expect(context.getVariable("accessControlAllowMethod")).toBe("GET"); 
	expect(context.getVariable("accessControlAllowHeaders")).toBe("vf-trace-transaction-id"); 
	expect(context.getVariable("isValidPreflightRequest")).toBe(true);
});
it ('9: Negative: If API specific origins and common origins are not present/null ', function() {
    context.setVariable("request.header.Origin", "apixstaging.developer.vodafone.com");
    context.setVariable("cors_allowed_origins_common", null);
    context.setVariable("cors_allowed_origins", "");
    context.setVariable("cors_allowed_methods", "GET,POST");
    context.setVariable("request.header.Access-Control-Request-Method", "GET");
    context.setVariable("request.header.Access-Control-Request-Headers", "vf-trace-transaction-id");
    context.setVariable("request.header.Access-Control-Request-Headers.values", "[vf-trace-transaction-id]");
    context.setVariable("cors_allowed_headers", "vf-trace-transaction-id,x-vf-ext-trace-id,x-vf-ext-reference-id,authorization,content-type,accept");
    
	expect(corsPreflightRequest()).toBe();
	expect(context.getVariable("origin")).toBe(undefined);
	expect(context.getVariable("accessControlAllowMethod")).toBe("GET"); 
	expect(context.getVariable("accessControlAllowHeaders")).toBe("vf-trace-transaction-id"); 
	expect(context.getVariable("isValidPreflightRequest")).toBe(false);
});
it ('10: Negative: Requested Header value is empty', function() {
    context.setVariable("request.header.Origin", "https://apixstaging.developer.vodafone.com");
    context.setVariable("cors_allowed_origins_common", "apixstaging.developer.vodafone.com,apixstagingref.developer.vodafone.com,developer.vodafone.com,confluence.sp.vodafone.com");
    context.setVariable("cors_allowed_origins", "domain1.com");
    context.setVariable("request.header.Access-Control-Request-Method", "GET");
    context.setVariable("cors_allowed_methods", "GET,POST");
    context.setVariable("request.header.Access-Control-Request-Headers", "vf-trace-transaction-id");
    context.setVariable("request.header.Access-Control-Request-Headers.values", "");
    context.setVariable("cors_allowed_headers", "vf-trace-transaction-id,x-vf-ext-trace-id,x-vf-ext-reference-id,authorization,content-type,accept");
    
	expect(corsPreflightRequest()).toBe();
	expect(context.getVariable("origin")).toBe("https://apixstaging.developer.vodafone.com");
	expect(context.getVariable("accessControlAllowMethod")).toBe("GET"); 
	expect(context.getVariable("accessControlAllowHeaders")).toBe(undefined); 
    expect(context.getVariable("isValidPreflightRequest")).toBe(false);
});
});
