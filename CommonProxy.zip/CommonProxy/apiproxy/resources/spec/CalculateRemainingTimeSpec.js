var CalculateTime = require('../jsc/a42HomeDocGenerate/CalculateRemainingExpiryTime');
describe('Calculate Remaining Time ', function() {
    beforeEach(function(){
      var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });

	it ('Positive: With correct values ', function() {
		var payload = {};
		var cDate = new Date();
		payload.LRTs =["ABC", "PQR"];
		payload.Expiry = new Date(cDate.getTime() + 84600*1000);
		context.setVariable("homeDocumentCachedData", JSON.stringify(payload));
	    expect(CalculateRemainingTime()).toBe();
	    expect(context.getVariable("remainingSeconds")).toBeGreaterThan(0);
	 });
	it('Negative: JSON payload is empty', function(){
		context.setVariable("homeDocumentCachedData", "");
		expect(CalculateRemainingTime).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
	});

});
