/**
 * 
 */
var IoTAddUserInfoRequestHeaders = require('../jsc/IOTAddUserInfoRequestHeaders/IoTAddUserInfoRequestHeaders');
describe('IoTAddUserInfoRequestHeaders Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });
    
    it ('Positive case1: AddReuqestHeaders', function() {
    	context.setVariable("userInfoJWEToken","ehjhuijsndsdsdkjskdjksjdkjsd");
        expect(adduserInfoRequestHeaders()).toBe();
        expect(context.getVariable("request.header.UserInfoToken")).toBe("ehjhuijsndsdsdkjskdjksjdkjsd");
    });
   
    it ('Positive case1: AddReuqestHeaders', function() {
    	 context.setVariable("msisdnCountry","DE");
         context.setVariable("request.header.Customer-Country-Code","DE");
        expect(adduserInfoRequestHeaders()).toBe();
        expect(context.getVariable("request.header.Customer-Country-Code")).toBe("DE");
    });
    
    it ('Positive case1: AddReuqestHeaders', function() {
   	 context.setVariable("msisdnCountry","GR");
        context.setVariable("request.header.Customer-Country-Code","");
       expect(adduserInfoRequestHeaders()).toBe();
       expect(context.getVariable("request.header.Customer-Country-Code")).toBe("GR");
   });
   
});