/**
 * 
 */
var IoTSubValidationVar = require('../jsc/IOTCheckServiceEligibilityForCountry/IoTCheckServiceEligibilityForCountry');
describe('IoTCheckServiceEligibilityForCountry Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });
     
    it ('Positive case1: checkServiceEligibility', function() {
    	context.setVariable("ServiceEligibilityConfiguration","{\"DE\":\"KYCStatus,Completeness\",\"ES\" : \"KYCStatus,Completeness\",\"GB\":\"Completeness\",\"IT\":\"KYCStatus,Completeness\"}");
        context.setVariable("accesstoken.Customer-Country-Code","");
    	 context.setVariable("msisdnCountry","DE");
        expect(checkServiceEligibiltyForCountry()).toBe();
        expect(context.getVariable("accesstoken.Customer-Country-Code")).toBe("");
    });
    
    it ('Positive case2: checkServiceEligibility', function() {
    	context.setVariable("ServiceEligibilityConfiguration","{\"DE\":\"\"KYCStatus,Completeness\",\"ES\" : \"KYCStatus,Completeness\",\"GB\":\"Completeness\",\"IT\":\"KYCStatus,Completeness\"}");
        context.setVariable("accesstoken.Customer-Country-Code","");
    	 context.setVariable("msisdnCountry","DE");
        expect(checkServiceEligibiltyForCountry()).toBe();
    });
    
    it ('Positive case3: checkServiceEligibility', function() {
    	context.setVariable("ServiceEligibilityConfiguration","{\"DE\":\"\"KYCStatus,Completeness\",\"ES\" : \"KYCStatus,Completeness\",\"GB\":\"Completeness\",\"IT\":\"KYCStatus,Completeness\"}");
        context.setVariable("accesstoken.Customer-Country-Code","DE");
    	 context.setVariable("msisdnCountry","");
        expect(checkServiceEligibiltyForCountry()).toBe();
    });
    
    
  
   
 
   
   
});