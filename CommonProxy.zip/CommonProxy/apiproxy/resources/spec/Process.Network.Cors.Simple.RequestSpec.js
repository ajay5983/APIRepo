require('../jsc/ProcessNetworkCorsSimpleRequest/Process.Network.Cors.Simple.Request');

describe('Cors Simple Request Test Suites', function() {
	
    beforeEach(function(){
      var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });
    it ('1: Negative: If Origin header is not present', function() {
        context.setVariable("request.header.Origin", "");
        expect(corsSimpleRequest()).toBe();
    	expect(context.getVariable("isValidOriginPresent")).toBe(false);
    	expect(context.getVariable("errorJSON")).toBe(undefined);
    });
	it ('2: Negative: Global and API allowed origin are not present', function() {
	    context.setVariable("request.header.Origin", "https://apixstaging.developer.vodafone.com");
	    context.setVariable("request.verb", "GET");
	    context.setVariable("cors_allowed_methods", "GET,POST");
	    expect(corsSimpleRequest).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
	});
	it ('3: Negative: Global allowed origin are present but allowed methods empty', function() {
	    context.setVariable("request.header.Origin", "https://apixstaging.developer.vodafone.com");
	    context.setVariable("cors_allowed_origins_common", "apixstaging.developer.vodafone.com,apixstagingref.developer.vodafone.com,developer.vodafone.com,confluence.sp.vodafone.com");
	    context.setVariable("request.verb", "GET");
	    context.setVariable("cors_allow_credentials", "true");
	    context.setVariable("cors_expose_headers", "accept");
	    expect(corsSimpleRequest).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
	});
	it ('4: Negative: API allowed origin is present', function() {
	    context.setVariable("request.header.Origin", "domain2.com");
	    context.setVariable("cors_allowed_origins", "domain1.com,domain2.com,domain3.com");
	    context.setVariable("request.verb", "GET");
	    context.setVariable("cors_allowed_methods", "GET,POST");
	    context.setVariable("cors_allow_credentials", "true");
	    context.setVariable("cors_expose_headers", "accept");
		expect(corsSimpleRequest()).toBe();
		expect(context.getVariable("isValidOriginPresent")).toBe(true);
	});
	it ('5: Negative: API and Global allowed origin are present', function() {
	    context.setVariable("request.header.Origin", "domain2.com");
	    context.setVariable("cors_allowed_origins_common", "apixstaging.developer.vodafone.com,apixstagingref.developer.vodafone.com,developer.vodafone.com,confluence.sp.vodafone.com");
	    context.setVariable("cors_allowed_origins", "domain1.com,domain2.com,domain3.com");
	    context.setVariable("request.verb", "GET");
	    context.setVariable("cors_allow_credentials", "true");
	    context.setVariable("cors_expose_headers", "accept");
	    context.setVariable("cors_allowed_methods", "GET,POST");
	    
		expect(corsSimpleRequest()).toBe();
		expect(context.getVariable("isValidOriginPresent")).toBe(true);
	});
	it ('6: Negative: Origin is not valid', function() {
	    context.setVariable("request.header.Origin", "domain4.com");
	    context.setVariable("cors_allowed_origins_common", "apixstaging.developer.vodafone.com,apixstagingref.developer.vodafone.com,developer.vodafone.com,confluence.sp.vodafone.com");
	    context.setVariable("cors_allowed_origins", "domain1.com,domain2.com,domain3.com");
	    context.setVariable("request.verb", "GET");
	    context.setVariable("cors_allowed_methods", "GET,POST");
	    context.setVariable("cors_allow_credentials", "true");
	    context.setVariable("cors_expose_headers", "accept");
		expect(corsSimpleRequest).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_origin");
	});
	it ('7: Negative: Requested method is not valid', function() {
	    context.setVariable("request.header.Origin", "domain2.com");
	    context.setVariable("cors_allowed_origins_common", "apixstaging.developer.vodafone.com,apixstagingref.developer.vodafone.com,developer.vodafone.com,confluence.sp.vodafone.com");
	    context.setVariable("cors_allowed_origins", "domain1.com,domain2.com,domain3.com");
	    context.setVariable("request.verb", "DELETE");
	    context.setVariable("cors_allowed_methods", "GET,POST");
	    context.setVariable("cors_allow_credentials", "true");
	    context.setVariable("cors_expose_headers", "accept");
		expect(corsSimpleRequest).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_method");
	});
	it ('8: Negative: If accessControlAllowCredentials value not present', function() {
	    context.setVariable("request.header.Origin", "domain4.com");
	    context.setVariable("cors_allowed_origins_common", "apixstaging.developer.vodafone.com,apixstagingref.developer.vodafone.com,developer.vodafone.com,confluence.sp.vodafone.com");
	    context.setVariable("cors_allowed_origins", "domain1.com,domain2.com,domain3.com");
	    context.setVariable("request.verb", "GET");
	    context.setVariable("cors_allowed_methods", "GET,POST");
	    context.setVariable("cors_allow_credentials", "");
		expect(corsSimpleRequest).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
	});
	it ('9: Negative: If accessControlExposeHeaders value not present', function() {
	    context.setVariable("request.header.Origin", "domain4.com");
	    context.setVariable("cors_allowed_origins_common", "apixstaging.developer.vodafone.com,apixstagingref.developer.vodafone.com,developer.vodafone.com,confluence.sp.vodafone.com");
	    context.setVariable("cors_allowed_origins", "domain1.com,domain2.com,domain3.com");
	    context.setVariable("request.verb", "GET");
	    context.setVariable("cors_allowed_methods", "GET,POST");
	    context.setVariable("cors_expose_headers", null);
		expect(corsSimpleRequest).toThrow();
		expect(context.getVariable("errorJSON")).toBe("a42_generic_internal_config_error");
	});
	it ('10: Negative: Invalid method with valid origin', function() {
	    context.setVariable("request.header.Origin", "domain3.com");
	    context.setVariable("cors_allowed_origins_common", "apixstaging.developer.vodafone.com,apixstagingref.developer.vodafone.com,developer.vodafone.com,confluence.sp.vodafone.com");
	    context.setVariable("cors_allowed_origins", "domain1.com,domain2.com,domain3.com");
	    context.setVariable("request.verb", "DELETE");
	    context.setVariable("cors_allowed_methods", "GET,POST");
	    context.setVariable("cors_expose_headers", null);
	    context.setVariable("cors_allow_credentials", "true");
	    context.setVariable("cors_expose_headers", "accept");
		expect(corsSimpleRequest).toThrow();
		expect(context.getVariable("cors_allow_credentials")).toBe("true");
		expect(context.getVariable("cors_expose_headers")).toBe("accept");
		expect(context.getVariable("origin")).toBe("domain3.com");
		expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_method");
	});

});