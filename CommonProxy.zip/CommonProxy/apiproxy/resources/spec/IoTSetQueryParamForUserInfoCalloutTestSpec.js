/**
 * 
 */
var IoTSetQueryParamForUserInfoCalloutVar = require('../jsc/IOTSetQueryParamForUserInfoRequest/IoTSetQueryParamForUserInfoCallout');
describe('IoTSetQueryParamForUserInfoCallout Suite', function() {
    beforeEach(function(){
        var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });
     
    it ('Positive case1: validwhitelsitedCountry', function() {
        context.setVariable("accesstoken.sub","ea85d16c-f338-4b22-91e5-219215ea9881");
        context.setVariable("request.header.Apix-App-Id","ea85d16c-f338-4b22-91e5-219215ea9881");
        context.setVariable("IoT-Backend-Password","IoT-Backend-Password");
        context.setVariable("IoT-Backend-Password","IoT-Backend-Password");
        context.setVariable("accesstoken.scopeFromRequest","openid phone IOT_IMAGES_UPLOAD IOT_DEVICES_PRODUCT_READ OPENID_MARKET");
        context.setVariable("accesstoken.whitelisted","true");
        context.setVariable("UserInfoEncrypt","jwe-password");
       expect(queryParamForUserInfo()).toBe(undefined);
    });
   
});