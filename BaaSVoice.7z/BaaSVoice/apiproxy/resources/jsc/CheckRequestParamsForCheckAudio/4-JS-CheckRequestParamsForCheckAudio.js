/* global context*/
checkRequestParamsForCheckAudio = function checkRequestParamsForCheckAudio(){ // eslint-disable-line no-undef

	var reqSubjectRegion = context.getVariable("request.header.vf-trace-subject-region");
	var reqAccept = context.getVariable("request.header.Accept");
	var reqSourceApp = context.getVariable("request.header.vf-trace-source-app");
	var reqServiceId = context.getVariable("request.header.vf-trace-source-service-id");
	var reqServiceVersion = context.getVariable("request.header.vf-trace-source-service-version");
	var sourceAppValue = context.getVariable("sourceAppValue");
	var serviceIdValue = context.getVariable("serviceIdValue");
	var serviceVersionValue = context.getVariable("serviceVersionValue");
	var reqTimeStamp = context.getVariable("request.header.vf-trace-source-timestamp");
	var reqUserId = context.getVariable("request.header.vf-trace-source-user-id");
	var reqWorkstationId = context.getVariable("request.header.vf-trace-source-workstation-id");
	var acceptEncoding = context.getVariable("acceptEncoding");
	var acceptLanguage = context.getVariable("acceptLanguage");
	var acceptJson = context.getVariable("acceptJson");

	if (reqTimeStamp) {
		context.setVariable("request.header.x-vf-trace-source-timestamp", reqTimeStamp);
	}
	if (reqUserId) {
		context.setVariable("request.header.x-vf-trace-source-user-id", reqUserId);
	}
	if (reqWorkstationId) {
		context.setVariable("request.header.x-vf-trace-source-workstation-id", reqWorkstationId);
	}

	if (reqSourceApp) {
		sourceAppValue = reqSourceApp;
	}
	context.setVariable("request.header.x-vf-trace-source-app", sourceAppValue);

	if (reqServiceId) {
		serviceIdValue = reqServiceId;
	}
	context.setVariable("request.header.x-vf-trace-source-service-id", serviceIdValue);

	if (reqServiceVersion) {
		serviceVersionValue = reqServiceVersion;
	}
	context.setVariable("request.header.x-vf-trace-source-service-version", serviceVersionValue);

	if (reqSubjectRegion) {
		reqSubjectRegion = reqSubjectRegion.toUpperCase();
		context.setVariable("request.header.x-vf-trace-subject-region", reqSubjectRegion);
	}

	context.setVariable("request.header.Accept-Language", acceptLanguage);
	context.setVariable("request.header.Accept-Encoding", acceptEncoding);

	if (reqAccept) {
		acceptJson = reqAccept;
	}
	context.setVariable("request.header.Accept", acceptJson);

	if (!reqSubjectRegion) {
		context.setVariable("request_param", "vf-trace-subject-region");
		context.setVariable("errorJSON", "a42_generic_missing_request_parameter");
		throw "serviceException";
	}

};
