/* global context*/
// raise fault for invalid Authorization Header
invalidAuthorizationHeader = function invalidAuthorizationHeader(){ // eslint-disable-line no-undef
	context.setVariable("errorJSON", "a42_generic_invalid_authorization_header");
	throw "invalidAuthorizationheaderError";
};