/* global context*/
scopeValidation = function scopeValidation(){ // eslint-disable-line no-undef
	// This is used to check and validate scope and set Flow Name
	var tokenscopes = context.getVariable("accesstoken.scope");
	tokenscopes = tokenscopes.split(" ");

	var apiScopes = context.getVariable("apiScopes");
	var validApiScopes = false;

	// API level scope Validation
	if (apiScopes) {
		apiScopes = apiScopes.split(",");
		for (var i = 0; tokenscopes.length > i; i++) {
			if (apiScopes.indexOf(tokenscopes[i]) > -1) {
				validApiScopes = true;
				break;
			}
		}
	}

	if (!validApiScopes) {
		context.setVariable("errorJSON", "a42_generic_invalid_scope_for_api");
		throw "insufficientScopeError";
	}

	// Resource Level Scope Validation
	var flowName = context.getVariable("current.flow.name");
	context.setVariable("currentFlowName", flowName);

	var validResourceScopes = false;

	var allowedScopes = context.getVariable("allowedScopes");
	var flowScopes;

	allowedScopes = JSON.parse(allowedScopes);

	for (var j = 0; allowedScopes.length > j; j++) {
		if (allowedScopes[j].flowName === flowName) {
			flowScopes = allowedScopes[j].allowedScopesList;
			break;
		}
	}

	if (flowScopes) {
		flowScopes = flowScopes.split(",");
		for (var k = 0; flowScopes.length > k; k++) {
			if (tokenscopes.indexOf(flowScopes[k]) > -1) {
				validResourceScopes = true;
				break;
			}
		}
	}

	if (!validResourceScopes) {
		context.setVariable("errorJSON", "a42_generic_insufficient_scope");
		throw "insufficientScopeError";
	}
};