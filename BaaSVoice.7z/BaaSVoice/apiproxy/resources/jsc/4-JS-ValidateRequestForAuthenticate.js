/* global context*/


var ctype = context.getVariable("request.header.content-type");
var re1 = new RegExp("^multipart/form-data; *boundary=(.+)$");
var match = re1.exec(ctype);
if (!match){
	context.setVariable("errorJSON", "a42_generic_invalid_content_type_header");
	throw "invalidHeaderException";
}
var boundary = match[1];
boundary = boundary.replace("; charset=US-ASCII", "");
context.setVariable("boundary", boundary);
var blength = boundary.length;
var body = context.getVariable("request.content");
var re2 = new RegExp("^--" + boundary + "$", "gm");
var re3 = new RegExp("^Content-Disposition: form-data; name=\"(.+)\"$[\r\n]+(.+)$", "m"); // eslint-disable-line no-control-regex
var section;
var payload = {};

while ((section = re2.exec(body)) !== null) {
	var start = section.index + blength + 1;
	var blob = body.substring(start, section.lastIndex);
	match = re3.exec(blob);
	if (match) {
		context.setVariable(match[1], match[2]);
		payload[match[1]] = match[2];
	}
}
var reqPayload = JSON.stringify(payload, null, 2);
context.setVariable("reqPayload", reqPayload);
var utteranceFlag = false;
if (reqPayload){
	reqPayload = JSON.parse(reqPayload);
	for (var key in reqPayload) { // eslint-disable-line guard-for-in
		context.setVariable("Key: " + key, key);
		var keyEncoded = key.split(";");
		if (keyEncoded){
			var i = 0;
			context.setVariable("keyEncoded" + i, keyEncoded[0]);

			var txt = "utterance\"";

			if (keyEncoded[0].includes(txt)){
				utteranceFlag = true;
				var fileContentType = reqPayload[key];
				var validContentType = context.getVariable("fileType");
				context.setVariable("fileContentType", fileContentType);
				fileContentType = fileContentType.replace("Content-Type: ", "");
				context.setVariable("fileContentTypeWithoutSpace", fileContentType);
				context.setVariable("validContentType", validContentType);
				var validContentTypeArray = validContentType.split(",");
				if (validContentTypeArray.indexOf(fileContentType) === -1) {
					context.setVariable("request_param", "utterance");
					context.setVariable("errorJSON", "a42_generic_invalid_request_parameter");
					throw "serviceException";
				}

				break;
			}

			i++;
		}
		context.setVariable("Value: ", reqPayload[key]);

	}

	if (!utteranceFlag){
		context.setVariable("request_param", "utterance");
		context.setVariable("errorJSON", "a42_generic_missing_request_parameter");
		throw "serviceException";
	}
}
