try {
	checkRequestParamsForDelete(); // eslint-disable-line no-undef
} catch (err){
	throw err;
}