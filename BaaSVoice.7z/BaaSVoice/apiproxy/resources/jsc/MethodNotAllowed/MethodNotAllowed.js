/* global context*/
methodNotAllowed = function methodNotAllowed() { // eslint-disable-line no-undef
	context.setVariable("errorJSON", "a42_generic_invalid_method");
	throw "invalidMethodError";
};