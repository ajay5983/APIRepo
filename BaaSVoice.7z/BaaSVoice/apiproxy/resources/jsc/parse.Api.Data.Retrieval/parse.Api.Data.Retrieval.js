/* global context*/
parseApiDataRetrieval = function parseApiDataRetrieval() { // eslint-disable-line no-undef

	function parseJson(data) {
		try {
			return JSON.parse(data);
		} catch (e) {
			return false;
		}
	}
	var infoAPI = parseJson(context.getVariable("info_api"));
	var validationMaxValues = parseJson(context.getVariable("validation_max_values"));
	var validation = parseJson(context.getVariable("validation"));
	var throttlingSpikeArrest = parseJson(context.getVariable("throttling_spike_arrest"));
	var throttlingQuotaApi = parseJson(context.getVariable("throttling_quota_api"));
	var loggingUlffEnabled = context.getVariable("logging_ulff_enabled");
	var loggingUlffMasking = parseJson(context.getVariable("logging_ulff_masking"));
	var httpStatusApi = parseJson(context.getVariable("http_status_api"));
	var countryResources = parseJson(context.getVariable("resources"));

	var flagSpikeArrest = false;
	var flagApiQuota1MIN = false;
	var errorFlag = false;
	if (infoAPI) {
		if (infoAPI.API_DISPLAY_NAME) {
			context.setVariable("api_display_name", infoAPI.API_DISPLAY_NAME);
		}
		if (infoAPI.API_DESCRIPTION) {
			context.setVariable("api_description", infoAPI.API_DESCRIPTION);
		}
		if (infoAPI.API_VERSION) {
			context.setVariable("api_version", infoAPI.API_VERSION);
		}
		if (infoAPI.API_CONSUMED_RESOURCES) {
			context.setVariable("api_consumed_resources", infoAPI.API_CONSUMED_RESOURCES);
		}
		if (infoAPI.API_NAME) {
			context.setVariable("api_name", infoAPI.API_NAME);
		}
		context.removeVariable("info_api");
	}

	function populatedThrottlingValues(apiConsumedResources, resources) {
		for (var j = 0; j < apiConsumedResources.length; j++) {
			var currResource = apiConsumedResources[j];

			if (resources[currResource + "_RESOURCE"].INFO_RESOURCE) {
				var currInfoResource = resources[currResource + "_RESOURCE"].INFO_RESOURCE;
				var currThrottlingQuotaResource = resources[currResource
					+ "_RESOURCE"].THROTTLING_QUOTA_RESOURCE;

				if (currInfoResource.RESOURCE_NAME) {
					context.setVariable(currResource + "_resource_name",
						currInfoResource.RESOURCE_NAME);
				}
				if (currThrottlingQuotaResource.THROTTLING_QUOTA_RESOURCE_ENABLED) {
					context
						.setVariable(currResource
						+ "_throttling_quota_resource_enabled",
						currThrottlingQuotaResource.THROTTLING_QUOTA_RESOURCE_ENABLED);
				}
				if (currThrottlingQuotaResource.THROTTLING_QUOTA_RESOURCE_COUNT) {
					context
						.setVariable(currResource
						+ "_throttling_quota_resource_count",
						currThrottlingQuotaResource.THROTTLING_QUOTA_RESOURCE_COUNT);
				}
			}

		}
	}

	if (countryResources) {
		var consumedResources = context.getVariable("api_consumed_resources").split(",");
		populatedThrottlingValues(consumedResources, countryResources);
	}
	if (validationMaxValues) {
		if (validationMaxValues.MAX_HEADER_SIZE) {
			context.setVariable("max_header_size", validationMaxValues.MAX_HEADER_SIZE);
		}
		if (validationMaxValues.MAX_CONTENT_SIZE) {
			context.setVariable("max_content_size", validationMaxValues.MAX_CONTENT_SIZE);
		}
		if (validationMaxValues.MAX_REQUEST_URI_SIZE) {
			context.setVariable("max_request_uri_size", validationMaxValues.MAX_REQUEST_URI_SIZE);
		}
		context.removeVariable("validation_max_values");
	}
	if (httpStatusApi) {
		if (httpStatusApi.API_HELP_LINK) {
			context.setVariable("api_help_link", httpStatusApi.API_HELP_LINK);
		}
		context.removeVariable("http_status_api");
	}
	if (validation) {
		if (validation.VALIDATION_CONTENT_TYPE_HEADER) {
			context.setVariable("validation_content_type_header", validation.VALIDATION_CONTENT_TYPE_HEADER);
		}
		if (validation.VALIDATION_ACCEPT_HEADER) {
			context.setVariable("kvm_global_accept_header", validation.VALIDATION_ACCEPT_HEADER);
		}
		if (validation.VALIDATION_ACCEPT_CHARSET_HEADER) {
			context.setVariable("validation_accept_charset_header", validation.VALIDATION_ACCEPT_CHARSET_HEADER);
		}
		if (validation.VALIDATION_IN_HEADERS) {
			context.setVariable("validation_in_headers", validation.VALIDATION_IN_HEADERS);
		}
		if (validation.VALIDATION_OUT_HEADERS) {
			context.setVariable("validation_out_headers", validation.VALIDATION_OUT_HEADERS);
		}
		context.removeVariable("validation");
	}
	if (throttlingSpikeArrest) {
		if (throttlingSpikeArrest.THROTTLING_SPIKE_ARREST_ENABLED) {
			flagSpikeArrest = throttlingSpikeArrest.THROTTLING_SPIKE_ARREST_ENABLED;
			context.setVariable("throttling_spike_arrest_enabled", flagSpikeArrest);
		}
		if (flagSpikeArrest && throttlingSpikeArrest.THROTTLING_SPIKE_ARREST_RATE) {
			context.setVariable("throttling_spike_arrest_rate", throttlingSpikeArrest.THROTTLING_SPIKE_ARREST_RATE);
		}
		context.removeVariable("throttling_spike_arrest");
	}
	if (throttlingQuotaApi) {
		if (throttlingQuotaApi.THROTTLING_QUOTA_API_ENABLED) {
			flagApiQuota1MIN = (throttlingQuotaApi.THROTTLING_QUOTA_API_ENABLED);
			context.setVariable("throttling_quota_api_enabled", flagApiQuota1MIN);
			if (flagApiQuota1MIN && throttlingQuotaApi.THROTTLING_QUOTA_API_COUNT) {
				context.setVariable("throttling_quota_api_count", throttlingQuotaApi.THROTTLING_QUOTA_API_COUNT);
			}
		}
		context.removeVariable("throttling_quota_api");
	}
	if (loggingUlffEnabled !== "true" && loggingUlffEnabled !== "false") {
		context.setVariable("api_data_retrieval_error", true);
		errorFlag = true;
	}
	if (loggingUlffMasking) {
		if (loggingUlffMasking.MASKING_HEADERS_ENABLED) {
			var flagMaskingHeaders = loggingUlffMasking.MASKING_HEADERS_ENABLED;
			context.setVariable("masking_headers_enabled", flagMaskingHeaders);
			if (flagMaskingHeaders && loggingUlffMasking.MASKING_HEADERS) {
				context.setVariable("masking_headers", loggingUlffMasking.MASKING_HEADERS);
			}
		}
		if (loggingUlffMasking.MASKING_BODY_ENABLED) {
			context.setVariable("masking_body_enabled", loggingUlffMasking.MASKING_BODY_ENABLED);
		}
		if (loggingUlffMasking.MASKING_QUERY_PARAMS_ENABLED) {
			var flagMaskingQuery = loggingUlffMasking.MASKING_QUERY_PARAMS_ENABLED;
			context.setVariable("masking_query_params_enabled", flagMaskingQuery);
			if (flagMaskingQuery && loggingUlffMasking.MASKING_QUERY_PARAMS) {
				context.setVariable("masking_query_params", loggingUlffMasking.MASKING_QUERY_PARAMS);
			}
		}
		if (loggingUlffMasking.LOGGING_PAYLOAD_ENABLED) {
			context.setVariable("logging_payload_enabled", loggingUlffMasking.LOGGING_PAYLOAD_ENABLED);
		}
		context.removeVariable("logging_ulff_masking");
	}
	if (errorFlag) {
		throw "parseAPIDataRetrieval";
	}
};