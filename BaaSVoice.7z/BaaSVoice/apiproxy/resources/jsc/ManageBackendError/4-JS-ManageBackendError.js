manageBackendError = function manageBackendError(){ // eslint-disable-line no-undef


	var reasonPhrase;
	var description;
	var errMessage;
	var statusCode;
	var errorFlag = false;

	var faultName = context.getVariable("fault.name");
	try {
		if (faultName === "ErrorResponseCode") {
			var backendError = context.getVariable("response.content");
			context.setVariable("backendError", backendError);
			var jsonError = JSON.parse(backendError);

			if (jsonError.errorMessage) {
				description = jsonError.errorMessage;
				errorFlag = true;
			}
			if (jsonError.errorCode) {
				errMessage = jsonError.errorCode;
			}
			reasonPhrase = context.getVariable("response.reason.phrase");
			statusCode = context.getVariable("response.status.code");
			if (!errorFlag) {
				reasonPhrase = "Internal Server Error";
				description = "The authorization server encountered an unexpected condition that prevented it from fulfilling the request";
				errMessage = "server_error";
				statusCode = "500";
			}

		}
	} catch (e) {
		reasonPhrase = "Internal Server Error";
		description = "The authorization server encountered an unexpected condition that prevented it from fulfilling the request";
		errMessage = "server_error";
		statusCode = "500";
	} finally {
		context.setVariable("reasonPhrase", reasonPhrase);
		context.setVariable("description", description);
		context.setVariable("errMessage", errMessage);
		context.setVariable("statusCode", statusCode);

		context.setVariable("flow.error.message", errMessage);
		context.setVariable("flow.error.status", statusCode);

		var dateForFault = new Date().toISOString();
		context.setVariable("dateForFault", dateForFault);
	}
};