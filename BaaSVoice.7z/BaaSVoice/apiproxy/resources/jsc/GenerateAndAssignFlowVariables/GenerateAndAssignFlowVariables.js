/* global context*/
generateAndAssignFlowVariables = function generateAndAssignFlowVariables(){ // eslint-disable-line no-undef

	context.setVariable("APIXEndpoint", context.getVariable("request.header.host"));
	var date = new Date();
	var dateForFault = date.toISOString();
	context.setVariable("dateForFault", dateForFault);
	context.setVariable("timestampIn", dateForFault);
};