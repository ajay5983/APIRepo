/* global context*/
resourceNotFound = function resourceNotFound(){ // eslint-disable-line no-undef
	context.setVariable("errorJSON", "a42_generic_resource_not_found");
	throw "NotFoundException";
};