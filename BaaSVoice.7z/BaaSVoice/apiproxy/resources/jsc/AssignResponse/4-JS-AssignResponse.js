/* global context*/
assignResponse = function assignResponse() { // eslint-disable-line no-undef

	var responseContent = context.getVariable("response.content");
	var updatedResponse = responseContent.slice(1, -1);
	context.setVariable("responseContent", updatedResponse);
};