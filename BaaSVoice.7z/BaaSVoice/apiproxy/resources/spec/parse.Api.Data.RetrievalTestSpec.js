var ParseApiDataRetrievalTest = require('../jsc/parse.Api.Data.Retrieval/parse.Api.Data.Retrieval');
describe('ParseApiDataRetrieval Suite', function () {
    beforeEach(function () {
        var Context = function () {
        };
        Context.prototype = {
            setVariable: function (propertyName, propertyValue) {
                this[propertyName] = propertyValue;
            },
            getVariable: function (propertyName) {
                return this[propertyName];
            },
            removeVariable: function (propertyName) {
                return this[propertyName];
            }
        };
        context = new Context();
    });


    it('Positive case1: ParseApiDataRetrieval', function () {
        context.setVariable("info_api", "{\"API_DISPLAY_NAME\": \"PushNotificationTemplates\",\"API_DESCRIPTION\": \"PushNotification API\",\"API_VERSION\": \"2-0-0\",\"API_CONSUMED_RESOURCES\": \"DE\",\"API_NAME\": \"PushNotificationTemplates\"}");
        context.setVariable("http_status_api", "{\"API_HELP_LINK\": \"https://apixdev.developer.vodafone.com/api_catalog\"}");
        context.setVariable("validation", "{\"VALIDATION_CONTENT_TYPE_HEADER\": \"application/json,application/vnd.vodafone.a42+json\",\"VALIDATION_ACCEPT_CHARSET_HEADER\": \"UTF-8\",\"VALIDATION_IN_HEADERS\": \"Content-Type\",\"VALIDATION_OUT_HEADERS\": \"Content-Type\",\"VALIDATION_ACCEPT_HEADER\": \"*/*,application/*,application/json,application/vnd.vodafone.a42+json\"}");
        context.setVariable("throttling_spike_arrest", "{\"THROTTLING_SPIKE_ARREST_ENABLED\": true,\"THROTTLING_SPIKE_ARREST_RATE\": \"9999ps\"}");
        context.setVariable("throttling_quota_api", "{\"THROTTLING_QUOTA_API_ENABLED\":true,\"THROTTLING_QUOTA_API_COUNT\":999999}");
        context.setVariable("logging_ulff_enabled", 'true');
        context.setVariable("logging_ulff_masking", '{\"MASKING_BODY_ENABLED\":true,\"LOGGING_PAYLOAD_ENABLED\":true,\"MASKING_HEADERS_ENABLED\":true,\"MASKING_QUERY_PARAMS_ENABLED\":true,\"MASKING_QUERY_PARAMS\":"ID"}');
        context.setVariable('resources', '{\"DE_RESOURCE\":{\"INFO_RESOURCE\":{\"RESOURCE_DISPLAY_NAME\":\"DE - Enterprise Release\",\"RESOURCE_DESCRIPTION\":\"This is DE - Enterprise Release\",\"RESOURCE_VERSION\":\"2.0.0\",\"RESOURCE_NAME\":\"DE\"},\"THROTTLING_QUOTA_RESOURCE\":{\"THROTTLING_QUOTA_RESOURCE_ENABLED\":\"true\",\"THROTTLING_QUOTA_RESOURCE_COUNT\":\"600\"}},\"ES_RESOURCE\":{\"INFO_RESOURCE\":{\"RESOURCE_DISPLAY_NAME\":\"ES - Enterprise Release\",\"RESOURCE_DESCRIPTION\":\"This is ES - Enterprise Release\",\"RESOURCE_VERSION\":\"2.0.0\",\"RESOURCE_NAME\":\"ES\"},\"THROTTLING_QUOTA_RESOURCE\":{\"THROTTLING_QUOTA_RESOURCE_ENABLED\":\"true\",\"THROTTLING_QUOTA_RESOURCE_COUNT\":\"600\"}},\"GR_RESOURCE\":{\"INFO_RESOURCE\":{\"RESOURCE_DISPLAY_NAME\":\"GR - Enterprise Release\",\"RESOURCE_DESCRIPTION\":\"This is GR - Enterprise Release\",\"RESOURCE_VERSION\":\"2.0.0\",\"RESOURCE_NAME\":\"GR\"},\"THROTTLING_QUOTA_RESOURCE\":{\"THROTTLING_QUOTA_RESOURCE_ENABLED\":\"true\",\"THROTTLING_QUOTA_RESOURCE_COUNT\":\"600\"}},\"NL_RESOURCE\":{\"INFO_RESOURCE\":{\"RESOURCE_DISPLAY_NAME\":\"NL - Enterprise Release\",\"RESOURCE_DESCRIPTION\":\"This is NL - Enterprise Release\",\"RESOURCE_VERSION\":\"2.0.0\",\"RESOURCE_NAME\":\"NL\"},\"THROTTLING_QUOTA_RESOURCE\":{\"THROTTLING_QUOTA_RESOURCE_ENABLED\":\"true\",\"THROTTLING_QUOTA_RESOURCE_COUNT\":\"600\"}},\"IT_RESOURCE\":{\"INFO_RESOURCE\":{\"RESOURCE_DISPLAY_NAME\":\"IT - Enterprise Release\",\"RESOURCE_DESCRIPTION\":\"This is IT - Enterprise Release\",\"RESOURCE_VERSION\":\"2.0.0\",\"RESOURCE_NAME\":\"IT\"},\"THROTTLING_QUOTA_RESOURCE\":{\"THROTTLING_QUOTA_RESOURCE_ENABLED\":\"true\",\"THROTTLING_QUOTA_RESOURCE_COUNT\":\"600\"}},\"GB_RESOURCE\":{\"INFO_RESOURCE\":{\"RESOURCE_DISPLAY_NAME\":\"GB - Enterprise Release\",\"RESOURCE_DESCRIPTION\":\"This is GB - Enterprise Release\",\"RESOURCE_VERSION\":\"2.0.0\",\"RESOURCE_NAME\":\"GB\"},\"THROTTLING_QUOTA_RESOURCE\":{\"THROTTLING_QUOTA_RESOURCE_ENABLED\":\"true\",\"THROTTLING_QUOTA_RESOURCE_COUNT\":\"600\"}},\"PT_RESOURCE\":{\"INFO_RESOURCE\":{\"RESOURCE_DISPLAY_NAME\":\"PT - Enterprise Release\",\"RESOURCE_DESCRIPTION\":\"This is PT - Enterprise Release\",\"RESOURCE_VERSION\":\"2.0.0\",\"RESOURCE_NAME\":\"PT\"},\"THROTTLING_QUOTA_RESOURCE\":{\"THROTTLING_QUOTA_RESOURCE_ENABLED\":\"true\",\"THROTTLING_QUOTA_RESOURCE_COUNT\":\"600\"}},\"IE_RESOURCE\":{\"INFO_RESOURCE\":{\"RESOURCE_DISPLAY_NAME\":\"IE - Enterprise Release\",\"RESOURCE_DESCRIPTION\":\"This is IE - Enterprise Release\",\"RESOURCE_VERSION\":\"2.0.0\",\"RESOURCE_NAME\":\"IE\"},\"THROTTLING_QUOTA_RESOURCE\":{\"THROTTLING_QUOTA_RESOURCE_ENABLED\":\"true\",\"THROTTLING_QUOTA_RESOURCE_COUNT\":\"600\"}},\"RO_RESOURCE\":{\"INFO_RESOURCE\":{\"RESOURCE_DISPLAY_NAME\":\"RO - Enterprise Release\",\"RESOURCE_DESCRIPTION\":\"This is RO - Enterprise Release\",\"RESOURCE_VERSION\":\"2.0.0\",\"RESOURCE_NAME\":\"RO\"},\"THROTTLING_QUOTA_RESOURCE\":{\"THROTTLING_QUOTA_RESOURCE_ENABLED\":\"true\",\"THROTTLING_QUOTA_RESOURCE_COUNT\":\"600\"}},\"AL_RESOURCE\":{\"INFO_RESOURCE\":{\"RESOURCE_DISPLAY_NAME\":\"AL - Enterprise Release\",\"RESOURCE_DESCRIPTION\":\"This is AL - Enterprise Release\",\"RESOURCE_VERSION\":\"2.0.0\",\"RESOURCE_NAME\":\"AL\"},\"THROTTLING_QUOTA_RESOURCE\":{\"THROTTLING_QUOTA_RESOURCE_ENABLED\":\"true\",\"THROTTLING_QUOTA_RESOURCE_COUNT\":\"600\"}},\"IS_RESOURCE\":{\"INFO_RESOURCE\":{\"RESOURCE_DISPLAY_NAME\":\"IS - Enterprise Release\",\"RESOURCE_DESCRIPTION\":\"This is IS - Enterprise Release\",\"RESOURCE_VERSION\":\"2.0.0\",\"RESOURCE_NAME\":\"IS\"},\"THROTTLING_QUOTA_RESOURCE\":{\"THROTTLING_QUOTA_RESOURCE_ENABLED\":\"true\",\"THROTTLING_QUOTA_RESOURCE_COUNT\":\"600\"}},\"NZ_RESOURCE\":{\"INFO_RESOURCE\":{\"RESOURCE_DISPLAY_NAME\":\"NZ - Enterprise Release\",\"RESOURCE_DESCRIPTION\":\"This is NZ - Enterprise Release\",\"RESOURCE_VERSION\":\"2.0.0\",\"RESOURCE_NAME\":\"NZ\"},\"THROTTLING_QUOTA_RESOURCE\":{\"THROTTLING_QUOTA_RESOURCE_ENABLED\":\"true\",\"THROTTLING_QUOTA_RESOURCE_COUNT\":\"600\"}},\"TR_RESOURCE\":{\"INFO_RESOURCE\":{\"RESOURCE_DISPLAY_NAME\":\"TR - Enterprise Release\",\"RESOURCE_DESCRIPTION\":\"This is TR - Enterprise Release\",\"RESOURCE_VERSION\":\"2.0.0\",\"RESOURCE_NAME\":\"TR\"},\"THROTTLING_QUOTA_RESOURCE\":{\"THROTTLING_QUOTA_RESOURCE_ENABLED\":\"true\",\"THROTTLING_QUOTA_RESOURCE_COUNT\":\"600\"}},\"IN_RESOURCE\":{\"INFO_RESOURCE\":{\"RESOURCE_DISPLAY_NAME\":\"IN - Enterprise Release\",\"RESOURCE_DESCRIPTION\":\"This is IN - Enterprise Release\",\"RESOURCE_VERSION\":\"2.0.0\",\"RESOURCE_NAME\":\"IN\"},\"THROTTLING_QUOTA_RESOURCE\":{\"THROTTLING_QUOTA_RESOURCE_ENABLED\":\"true\",\"THROTTLING_QUOTA_RESOURCE_COUNT\":\"600\"}},\"AT_RESOURCE\":{\"INFO_RESOURCE\":{\"RESOURCE_DISPLAY_NAME\":\"AT - Enterprise Release\",\"RESOURCE_DESCRIPTION\":\"This is AT - Enterprise Release\",\"RESOURCE_VERSION\":\"2.0.0\",\"RESOURCE_NAME\":\"AT\"},\"THROTTLING_QUOTA_RESOURCE\":{\"THROTTLING_QUOTA_RESOURCE_ENABLED\":\"true\",\"THROTTLING_QUOTA_RESOURCE_COUNT\":\"600\"}},\"BG_RESOURCE\":{\"INFO_RESOURCE\":{\"RESOURCE_DISPLAY_NAME\":\"BG - Enterprise Release\",\"RESOURCE_DESCRIPTION\":\"This is BG - Enterprise Release\",\"RESOURCE_VERSION\":\"2.0.0\",\"RESOURCE_NAME\":\"BG\"},\"THROTTLING_QUOTA_RESOURCE\":{\"THROTTLING_QUOTA_RESOURCE_ENABLED\":\"true\",\"THROTTLING_QUOTA_RESOURCE_COUNT\":\"600\"}},\"HR_RESOURCE\":{\"INFO_RESOURCE\":{\"RESOURCE_DISPLAY_NAME\":\"HR - Enterprise Release\",\"RESOURCE_DESCRIPTION\":\"This is HR - Enterprise Release\",\"RESOURCE_VERSION\":\"2.0.0\",\"RESOURCE_NAME\":\"HR\"},\"THROTTLING_QUOTA_RESOURCE\":{\"THROTTLING_QUOTA_RESOURCE_ENABLED\":\"true\",\"THROTTLING_QUOTA_RESOURCE_COUNT\":\"600\"}},\"HU_RESOURCE\":{\"INFO_RESOURCE\":{\"RESOURCE_DISPLAY_NAME\":\"HU - Enterprise Release\",\"RESOURCE_DESCRIPTION\":\"This is HU - Enterprise Release\",\"RESOURCE_VERSION\":\"2.0.0\",\"RESOURCE_NAME\":\"HU\"},\"THROTTLING_QUOTA_RESOURCE\":{\"THROTTLING_QUOTA_RESOURCE_ENABLED\":\"true\",\"THROTTLING_QUOTA_RESOURCE_COUNT\":\"600\"}},\"MT_RESOURCE\":{\"INFO_RESOURCE\":{\"RESOURCE_DISPLAY_NAME\":\"MT - Enterprise Release\",\"RESOURCE_DESCRIPTION\":\"This is MT - Enterprise Release\",\"RESOURCE_VERSION\":\"2.0.0\",\"RESOURCE_NAME\":\"MT\"},\"THROTTLING_QUOTA_RESOURCE\":{\"THROTTLING_QUOTA_RESOURCE_ENABLED\":\"true\",\"THROTTLING_QUOTA_RESOURCE_COUNT\":\"600\"}},\"CZ_RESOURCE\":{\"INFO_RESOURCE\":{\"RESOURCE_DISPLAY_NAME\":\"CZ - Enterprise Release\",\"RESOURCE_DESCRIPTION\":\"This is CZ - Enterprise Release\",\"RESOURCE_VERSION\":\"2.0.0\",\"RESOURCE_NAME\":\"CZ\"},\"THROTTLING_QUOTA_RESOURCE\":{\"THROTTLING_QUOTA_RESOURCE_ENABLED\":\"true\",\"THROTTLING_QUOTA_RESOURCE_COUNT\":\"600\"}}}')
        expect(parseApiDataRetrieval()).toBe();
        expect(context.getVariable("parseAPIDataRetrieval")).toBe(undefined);
        expect(context.getVariable("api_display_name")).toBe("PushNotificationTemplates");
        expect(context.getVariable("api_description")).toBe("PushNotification API");
        expect(context.getVariable("api_version")).toBe("2-0-0");
        expect(context.getVariable("api_help_link")).toBe("https://apixdev.developer.vodafone.com/api_catalog");
        expect(context.getVariable("validation_content_type_header")).toBe("application/json,application/vnd.vodafone.a42+json");
        expect(context.getVariable("api_data_retrieval_error")).toBe(undefined);
        expect(context.getVariable("throttling_spike_arrest_enabled")).toBe(true);
        expect(context.getVariable("throttling_spike_arrest_rate")).toBe("9999ps");
        expect(context.getVariable("throttling_quota_api_enabled")).toBe(true);        
    });

    it('Positive: Case 2: api_description ', function () {
        context.setVariable("info_api", "{\"API_DISPLAY_NAME\": \"PushNotificationTemplates\",\"API_VERSION\": \"1-0-0\"}");
        context.setVariable("logging_ulff_enabled", 'true');
        expect(parseApiDataRetrieval()).toBe();
        expect(context.getVariable("api_description")).toBe(undefined);

    });


    it('Positive: case3: Some fields not defined in json', function () {
        context.setVariable("info_api", "{\"API_DESCRIPTION\": \"PushNotification API\",\"API_VERSION\": \"2-0-0\"}");
        context.setVariable("http_status_api", "{\"API_HELP_LINK\": \"\"}");
        context.setVariable("validation", "{\"VALIDATION_CONTENT_TYPE_HEADER\": \"\",\"VALIDATION_ACCEPT_CHARSET_HEADER\": \"\",\"VALIDATION_IN_HEADERS\": \"\",   \"VALIDATION_OUT_HEDERS\": \"\",\"VALIDATION_ACCEPT_HEADER\": \"\"}");
        context.setVariable("throttling_spike_arrest", "{\"THROTTLING_SPIKE_ARREST_ENABLED\": true ,\"THROTTLING_SPIKE_ARREST_RATE\": \"\"}");
        context.setVariable("throttling_quota_api", "{\"THROTTLING_QUOTA_API_ENABLED\": true ,\"THROTTLING_QUOTA_1MIN_COUNT\": \"\"}");
        context.setVariable("logging_ulff_enabled", 'true');
        context.setVariable("logging_ulff_masking", '{\"MASKING_BODY_ENABLED\":\"\",\"LOGGING_PAYLOAD_ENABLED\":true}');
        expect(parseApiDataRetrieval()).toBe();

        expect(context.getVariable("api_description")).toBe("PushNotification API");
        expect(context.getVariable("api_display_name")).toBe(undefined);
        expect(context.getVariable("api_help_link")).toBe(undefined);
        expect(context.getVariable("validation_content_type_header")).toBe(undefined);
        expect(context.getVariable("kvm_global_accept_header")).toBe(undefined);
        expect(context.getVariable("validation_accept_charset_header")).toBe(undefined);
        expect(context.getVariable("validation_in_headers")).toBe(undefined);
        expect(context.getVariable("validation_out_headers")).toBe(undefined);
        expect(context.getVariable("throttling_spike_arrest_rate")).toBe(undefined);
        expect(context.getVariable("throttling_spike_arrest_enabled")).toBe(true);
        expect(context.getVariable("throttling_quota_api_enabled")).toBe(true);


    });
    it('Positive: case4 : api_version undefined', function () {
        context.setVariable("info_api", "{\"API_DISPLAY_NAME\": \"PushNotificationTemplates\",\"API_DESCRIPTION\": \"PushNotification API\"}");
        context.setVariable("logging_ulff_enabled", 'false');
        expect(parseApiDataRetrieval()).toBe();
        expect(context.getVariable("api_display_name")).toBe("PushNotificationTemplates");
        expect(context.getVariable("api_description")).toBe("PushNotification API");
        expect(context.getVariable("api_version")).toBe(undefined);

    });


    it('Positive: Case 5: api_description ', function () {
        context.setVariable("info_api", "{\"API_DISPLAY_NAME\": \"PushNotificationTemplates\",\"API_VERSION\": \"1-0-0\"}");
        context.setVariable("validation_max_values", "{\"MAX_HEADER_SIZE\": 8192,\"MAX_CONTENT_SIZE\": 2097152,\"MAX_REQUEST_URI_SIZE\": 2048}");
        context.setVariable("logging_ulff_enabled", 'false');
        expect(parseApiDataRetrieval()).toBe();
        expect(context.getVariable("api_description")).toBe(undefined);

    });

    it('Positive: Case 6: api_description ', function () {
        context.setVariable("info_api", "{\"API_DISPLAY_NAME\": \"PushNotificationTemplates\",\"API_VERSION\": \"1-0-0\"}");
        context.setVariable("validation_max_values", "{\"MAX_CONTENT_SIZE\": 2097152,\"MAX_REQUEST_URI_SIZE\": 2048}");
        context.setVariable("logging_ulff_enabled", 'false');
        expect(parseApiDataRetrieval()).toBe();
        expect(context.getVariable("max_header_size")).toBe(undefined);

    });

    it('Positive: Case 7: api_description ', function () {
        context.setVariable("info_api", "{\"API_DISPLAY_NAME\": \"PushNotificationTemplates\",\"API_VERSION\": \"1-0-0\"}");
        context.setVariable("validation_max_values", "{\"MAX_HEADER_SIZE\": 8192,\"MAX_REQUEST_URI_SIZE\": 2048}");
        context.setVariable("logging_ulff_enabled", 'false');
        expect(parseApiDataRetrieval()).toBe();
        expect(context.getVariable("max_content_size")).toBe(undefined);

    });

    it('Positive: Case 8: api_description ', function () {
        context.setVariable("info_api", "{\"API_DISPLAY_NAME\": \"PushNotificationTemplates\",\"API_VERSION\": \"1-0-0\"}");
        context.setVariable("validation_max_values", "{\"MAX_HEADER_SIZE\": 8192,\"MAX_CONTENT_SIZE\": 2097152}");
        context.setVariable("logging_ulff_enabled", 'false');
        expect(parseApiDataRetrieval()).toBe();
        expect(context.getVariable("max_request_uri_size")).toBe(undefined);

    });

    it('Positive: case 9: THROTTLING_SPIKE_ARREST_ENABLED not defined in json', function () {
        context.setVariable("info_api", "{\"API_DESCRIPTION\": \"PushNotification API\",\"API_VERSION\": \"2-0-0\"}");
        context.setVariable("http_status_api", "{\"API_HELP_LINK\": \"\"}");
        context.setVariable("validation", "{\"VALIDATION_CONTENT_TYPE_HEADER\": \"\",\"VALIDATION_ACCEPT_CHARSET_HEADER\": \"\",\"VALIDATION_IN_HEADERS\": \"\",   \"VALIDATION_OUT_HEDERS\": \"\",\"VALIDATION_ACCEPT_HEADER\": \"\"}");
        context.setVariable("throttling_spike_arrest", "{\"THROTTLING_SPIKE_ARREST_RATE\": \"\"}");
        context.setVariable("throttling_quota_api", "{\"THROTTLING_QUOTA_API_ENABLED\": true ,\"THROTTLING_QUOTA_API_COUNT\": \"\"}");
        context.setVariable("logging_ulff_enabled", 'true');
        context.setVariable("logging_ulff_masking", '{\"MASKING_BODY_ENABLED\":\"\",\"LOGGING_PAYLOAD_ENABLED\":true}');
        expect(parseApiDataRetrieval()).toBe();

        expect(context.getVariable("api_description")).toBe("PushNotification API");
        expect(context.getVariable("api_display_name")).toBe(undefined);
        expect(context.getVariable("api_help_link")).toBe(undefined);
        expect(context.getVariable("validation_content_type_header")).toBe(undefined);
        expect(context.getVariable("kvm_global_accept_header")).toBe(undefined);
        expect(context.getVariable("validation_accept_charset_header")).toBe(undefined);
        expect(context.getVariable("validation_in_headers")).toBe(undefined);
        expect(context.getVariable("validation_out_headers")).toBe(undefined);
        expect(context.getVariable("throttling_spike_arrest_rate")).toBe(undefined);
        expect(context.getVariable("throttling_spike_arrest_enabled")).toBe(undefined);
        expect(context.getVariable("throttling_quota_api_enabled")).toBe(true);


    });

    it('Negative case1:api_data_retrieval_error is null', function () {
        context.setVariable("logging_ulff_enabled", 'null');
        expect(parseApiDataRetrieval).toThrow();
        expect(context.getVariable("api_data_retrieval_error")).toBe(true);
    });

});