var GenerateAndAssignFlowVariablesTest = require('../jsc/GenerateAndAssignFlowVariables/GenerateAndAssignFlowVariables');
describe('GenerateAndAssignFlowVariables Suite', function() {
    beforeEach(function(){
      var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });
    
     it ('Positive: Time Stamp ', function() {        
        expect(generateAndAssignFlowVariables()).toBe();         
        expect(context.getVariable("dateInRequiredFormat")).not.toBe(":+5.30");	
        expect(context.getVariable("timestampIn")).not.toBe(":+5.30");	
    });
    
});

