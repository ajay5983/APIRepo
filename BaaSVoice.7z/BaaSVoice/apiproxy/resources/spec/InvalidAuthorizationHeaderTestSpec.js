var InvalidAuthorizationHeaderTest = require('../jsc/InvalidAuthorizationHeader/InvalidAuthorizationHeader');
describe('InvalidAuthorizationHeader Suite', function() {
    beforeEach(function(){
      var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });

    it ('Negative: Invalid Authorization Header ', function() {
        context.setVariable("errorJSON","a42_generic_invalid_authorization_header");
        expect(invalidAuthorizationHeader).toThrow();         
        expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_authorization_header");	
    }); 
 
});
