var CheckRequestParamsTest = require('../jsc/CheckRequestParams/CheckRequestParams');
describe('CheckRequestParams Suite', function() {
    beforeEach(function(){
      var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            },
            generateTimeStamp : function(){
              return this;
            }
        };
        context = new Context();
    });

    it ('Positive 1: Set values  ', function() {       
        context.setVariable("request.header.vf-trace-subject-region","SECURE_FAMILY");
        context.setVariable("request.header.Accept","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-app","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-version","SECURE_FAMILY");
        context.setVariable("action","SECURE_FAMILY");
        context.setVariable("actionValues","SECURE_FAMILY,ABC,abc");  
        context.setVariable("sourceAppValue","SECURE_FAMILY");
        context.setVariable("serviceVersionValue","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-timestamp","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-user-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-workstation-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-person-id","SECURE_FAMILY");
        context.setVariable("acceptEncoding","SECURE_FAMILY");
        context.setVariable("acceptLanguage","SECURE_FAMILY");
        context.setVariable("personId","SECURE_FAMILY");
        context.setVariable("acceptJson","SECURE_FAMILY");                  
        expect(checkRequestParams()).toBe();        
     }); 
             
    it ('Negative 2 : Incoming blank values  ', function() {                   		   	          
        context.setVariable("request.header.vf-trace-subject-region","SECURE_FAMILY");
        context.setVariable("request.header.Accept","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-app","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-version","SECURE_FAMILY");
        context.setVariable("action","SECURE_FAMILY");
        context.setVariable("actionValues","SECURE_FAMILY,ABC,abc");  
        context.setVariable("sourceAppValue","SECURE_FAMILY");
        context.setVariable("serviceVersionValue","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-timestamp","");
        context.setVariable("request.header.vf-trace-source-user-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-workstation-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-person-id","SECURE_FAMILY");
        context.setVariable("acceptEncoding","SECURE_FAMILY");
        context.setVariable("acceptLanguage","SECURE_FAMILY");
        context.setVariable("personId","SECURE_FAMILY");
        context.setVariable("acceptJson","SECURE_FAMILY");                             
	    expect(checkRequestParams()).toBe();     
    });
    
       it ('Negative 3 : Incoming blank values ', function() {                   		   	          
        context.setVariable("request.header.vf-trace-subject-region","SECURE_FAMILY");
        context.setVariable("request.header.Accept","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-app","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-version","SECURE_FAMILY");
        context.setVariable("action","SECURE_FAMILY");
        context.setVariable("actionValues","SECURE_FAMILY,ABC,abc");  
        context.setVariable("sourceAppValue","SECURE_FAMILY");
        context.setVariable("serviceVersionValue","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-timestamp","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-user-id","");
        context.setVariable("request.header.vf-trace-source-workstation-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-person-id","SECURE_FAMILY");
        context.setVariable("acceptEncoding","SECURE_FAMILY");
        context.setVariable("acceptLanguage","SECURE_FAMILY");
        context.setVariable("personId","SECURE_FAMILY");
        context.setVariable("acceptJson","SECURE_FAMILY");                             
	    expect(checkRequestParams()).toBe();     
    });
    
         it ('Negative 4 : Incoming blank values ', function() {                   		   	          
        context.setVariable("request.header.vf-trace-subject-region","SECURE_FAMILY");
        context.setVariable("request.header.Accept","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-app","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-version","SECURE_FAMILY");
        context.setVariable("action","SECURE_FAMILY");
        context.setVariable("actionValues","SECURE_FAMILY,ABC,abc");  
        context.setVariable("sourceAppValue","SECURE_FAMILY");
        context.setVariable("serviceVersionValue","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-timestamp","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-user-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-workstation-id","");
        context.setVariable("request.header.vf-trace-source-person-id","SECURE_FAMILY");
        context.setVariable("acceptEncoding","SECURE_FAMILY");
        context.setVariable("acceptLanguage","SECURE_FAMILY");
        context.setVariable("personId","SECURE_FAMILY");
        context.setVariable("acceptJson","SECURE_FAMILY");                             
	    expect(checkRequestParams()).toBe();     
    });

        it ('Negative 5 :  ', function() {                   		   	          
        context.setVariable("request.header.vf-trace-subject-region","SECURE_FAMILY");
        context.setVariable("request.header.Accept","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-app","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-version","SECURE_FAMILY");
        context.setVariable("action","SECURE_FAMILY");
        context.setVariable("actionValues","SECURE_FAMILY,ABC,abc");  
        context.setVariable("sourceAppValue","SECURE_FAMILY");
        context.setVariable("serviceVersionValue","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-timestamp","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-user-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-workstation-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-person-id","");
        context.setVariable("acceptEncoding","SECURE_FAMILY");
        context.setVariable("acceptLanguage","SECURE_FAMILY");
        context.setVariable("personId","SECURE_FAMILY");
        context.setVariable("acceptJson","SECURE_FAMILY");                             
	    expect(checkRequestParams()).toBe();     
    });
    
	it ('Negative 6 : Incoming blank values ', function() {                   		   	          
        context.setVariable("request.header.vf-trace-subject-region","");
        context.setVariable("request.header.Accept","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-app","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-version","SECURE_FAMILY");
        context.setVariable("action","SECURE_FAMILY");
        context.setVariable("actionValues","SECURE_FAMILY,ABC,abc");  
        context.setVariable("sourceAppValue","SECURE_FAMILY");
        context.setVariable("serviceVersionValue","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-timestamp","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-user-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-workstation-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-person-id","");
        context.setVariable("acceptEncoding","SECURE_FAMILY");
        context.setVariable("acceptLanguage","SECURE_FAMILY");
        context.setVariable("personId","SECURE_FAMILY");
        context.setVariable("acceptJson","SECURE_FAMILY");                             
	    expect(checkRequestParams).toThrow();     
        expect(context.getVariable("errorJSON")).toBe('a42_generic_missing_request_parameter');    
    });
    
    	it ('Negative 7 : Incoming blank values ', function() {                   		   	          
        context.setVariable("request.header.vf-trace-subject-region","");
        context.setVariable("request.header.Accept","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-app","");
        context.setVariable("request.header.vf-trace-source-service-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-version","SECURE_FAMILY");
        context.setVariable("action","SECURE_FAMILY");
        context.setVariable("actionValues","SECURE_FAMILY,ABC,abc");  
        context.setVariable("sourceAppValue","SECURE_FAMILY");
        context.setVariable("serviceVersionValue","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-timestamp","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-user-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-workstation-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-person-id","");
        context.setVariable("acceptEncoding","SECURE_FAMILY");
        context.setVariable("acceptLanguage","SECURE_FAMILY");
        context.setVariable("personId","SECURE_FAMILY");
        context.setVariable("acceptJson","SECURE_FAMILY");                             
	    expect(checkRequestParams).toThrow();     
        expect(context.getVariable("errorJSON")).toBe('a42_generic_missing_request_parameter');    
    });
    
        	it ('Negative 8 : Incoming blank values ', function() {                   		   	          
        context.setVariable("request.header.vf-trace-subject-region","");
        context.setVariable("request.header.Accept","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-app","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-id","");
        context.setVariable("request.header.vf-trace-source-service-version","SECURE_FAMILY");
        context.setVariable("action","SECURE_FAMILY");
        context.setVariable("actionValues","SECURE_FAMILY,ABC,abc");  
        context.setVariable("sourceAppValue","SECURE_FAMILY");
        context.setVariable("serviceVersionValue","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-timestamp","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-user-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-workstation-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-person-id","");
        context.setVariable("acceptEncoding","SECURE_FAMILY");
        context.setVariable("acceptLanguage","SECURE_FAMILY");
        context.setVariable("personId","SECURE_FAMILY");
        context.setVariable("acceptJson","SECURE_FAMILY");                             
	    expect(checkRequestParams).toThrow();     
        expect(context.getVariable("errorJSON")).toBe('a42_generic_missing_request_parameter');    
    });
    
 	it ('Negative 9 : Incoming blank values ', function() {                   		   	          
        context.setVariable("request.header.vf-trace-subject-region","");
        context.setVariable("request.header.Accept","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-app","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-version","");
        context.setVariable("action","SECURE_FAMILY");
        context.setVariable("actionValues","SECURE_FAMILY,ABC,abc");  
        context.setVariable("sourceAppValue","SECURE_FAMILY");
        context.setVariable("serviceVersionValue","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-timestamp","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-user-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-workstation-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-person-id","SECURE_FAMILY");
        context.setVariable("acceptEncoding","SECURE_FAMILY");
        context.setVariable("acceptLanguage","SECURE_FAMILY");
        context.setVariable("personId","SECURE_FAMILY");
        context.setVariable("acceptJson","SECURE_FAMILY");                             
	    expect(checkRequestParams).toThrow();     
        expect(context.getVariable("errorJSON")).toBe('a42_generic_missing_request_parameter');    
    });
    
	it ('Negative 10 : Incoming blank values ', function() {                   		   	          
        context.setVariable("request.header.vf-trace-subject-region","");
        context.setVariable("request.header.Accept","");
        context.setVariable("request.header.vf-trace-source-app","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-version","");
        context.setVariable("action","SECURE_FAMILY");
        context.setVariable("actionValues","SECURE_FAMILY,ABC,abc");  
        context.setVariable("sourceAppValue","SECURE_FAMILY");
        context.setVariable("serviceVersionValue","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-timestamp","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-user-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-workstation-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-person-id","");
        context.setVariable("acceptEncoding","SECURE_FAMILY");
        context.setVariable("acceptLanguage","SECURE_FAMILY");
        context.setVariable("personId","SECURE_FAMILY");
        context.setVariable("acceptJson","SECURE_FAMILY");                             
	    expect(checkRequestParams).toThrow();     
        expect(context.getVariable("errorJSON")).toBe('a42_generic_missing_request_parameter');    
    });
    
    it ('Negative 11 : Incoming blank values ', function() {                   		   	          
        context.setVariable("request.header.vf-trace-subject-region","");
        context.setVariable("request.header.Accept","");
        context.setVariable("request.header.vf-trace-source-app","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-version","SECURE_FAMILY");
        context.setVariable("action","");        
        context.setVariable("actionValues","enroll,authenticate");  
        context.setVariable("sourceAppValue","SECURE_FAMILY");
        context.setVariable("serviceVersionValue","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-timestamp","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-user-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-workstation-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-person-id","SECURE_FAMILY");
        context.setVariable("acceptEncoding","SECURE_FAMILY");
        context.setVariable("acceptLanguage","SECURE_FAMILY");
        context.setVariable("personId","SECURE_FAMILY");
        context.setVariable("acceptJson","SECURE_FAMILY");                             
	    expect(checkRequestParams).toThrow();     
        expect(context.getVariable("errorJSON")).toBe('a42_generic_missing_request_parameter');    
    });
    
     it ('Negative 12 : Incoming blank values ', function() {       
     	context.setVariable("request.header.vf-trace-subject-region","SECURE_FAMILY");
        context.setVariable("request.header.Accept","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-app","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-version","SECURE_FAMILY"); 
        context.setVariable("sourceAppValue","SECURE_FAMILY");
        context.setVariable("serviceVersionValue","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-timestamp","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-user-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-workstation-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-person-id","SECURE_FAMILY");
        context.setVariable("acceptEncoding","SECURE_FAMILY");
        context.setVariable("acceptLanguage","SECURE_FAMILY");
        context.setVariable("personId","SECURE_FAMILY");
        context.setVariable("acceptJson","SECURE_FAMILY");   
        context.setVariable("action","enroll,authenticate");
        context.setVariable("actionValues","enroll,authenticate");                         
	    expect(checkRequestParams).toThrow();           
    });

	   it ('Negative 13 : Incoming blank values ', function() {    
	   context.setVariable("request.header.vf-trace-subject-region","SECURE_FAMILY");
        context.setVariable("request.header.Accept","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-app","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-version","SECURE_FAMILY");
        context.setVariable("sourceAppValue","SECURE_FAMILY");
        context.setVariable("serviceVersionValue","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-timestamp","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-user-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-workstation-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-person-id","SECURE_FAMILY");
        context.setVariable("acceptEncoding","SECURE_FAMILY");
        context.setVariable("acceptLanguage","SECURE_FAMILY");
        context.setVariable("personId","SECURE_FAMILY");
        context.setVariable("acceptJson","SECURE_FAMILY");      
        context.setVariable("action","enroll");
        context.setVariable("actionValues","ABC");                         
	    expect(checkRequestParams).toThrow();           
    });
    
     it ('Negative 14 : Incoming blank values ', function() { 
     	context.setVariable("request.header.vf-trace-subject-region","SECURE_FAMILY");
        context.setVariable("request.header.Accept","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-app","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-version","SECURE_FAMILY");
        context.setVariable("sourceAppValue","SECURE_FAMILY");
        context.setVariable("serviceVersionValue","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-timestamp","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-user-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-workstation-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-person-id","SECURE_FAMILY");
        context.setVariable("acceptEncoding","SECURE_FAMILY");
        context.setVariable("acceptLanguage","SECURE_FAMILY");
        context.setVariable("personId","SECURE_FAMILY");
        context.setVariable("acceptJson","SECURE_FAMILY");         
        context.setVariable("action","enroll");
        context.setVariable("actionValues","enroll,authenticate");                         
	    expect(checkRequestParams()).toBe();           
    });
    
    it ('Negative 14 : Incoming blank values ', function() { 
     	context.setVariable("request.header.vf-trace-subject-region","SECURE_FAMILY");
        context.setVariable("request.header.Accept","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-app","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-service-version","SECURE_FAMILY");
        context.setVariable("sourceAppValue","SECURE_FAMILY");
        context.setVariable("serviceVersionValue","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-timestamp","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-user-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-workstation-id","SECURE_FAMILY");
        context.setVariable("request.header.vf-trace-source-person-id","SECURE_FAMILY");
        context.setVariable("acceptEncoding","SECURE_FAMILY");
        context.setVariable("acceptLanguage","SECURE_FAMILY");
        context.setVariable("personId","SECURE_FAMILY");
        context.setVariable("acceptJson","SECURE_FAMILY");                
       context.setVariable("actionValues","enroll,authenticate");                         
	    expect(checkRequestParams()).toBe();           
    });
        
            
});
