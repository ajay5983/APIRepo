var ManageBackendErrorTest = require('../jsc/ManageBackendError/4-JS-ManageBackendError');
describe('ManageBackendError Suite', function() {
    beforeEach(function(){
      var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            },
            generateTimeStamp : function(){
              return this;
            }
        };
        context = new Context();
    });

    it ('Positive 1: Incoming valid  ', function() {    
    	var response = {"errorMessage":"sfsa","errorCode":"sgas"} ;
    	
        context.setVariable("fault.name","ErrorResponseCode");
        context.setVariable("response.content",JSON.stringify(response));
        context.setVariable("response.reason.phrase","400");
        context.setVariable("response.status.code","BAD_Request");          
        expect(manageBackendError()).toBe();        
     });  
    
    it ('Positive 1: Incoming valid  ', function() {    
    	var response = {"errorMessage1":"sfsa","errorCodea":"sgas"} ;
    	
        context.setVariable("fault.name","ErrorResponseCode");
        context.setVariable("response.content",JSON.stringify(response));
        context.setVariable("response.reason.phrase","400");
        context.setVariable("response.status.code","BAD_Request");          
        expect(manageBackendError()).toBe();        
     });  

    it ('Positive 1: Incoming valid  ', function() {    
    	var response = {"errorMessage":"sfsa","errorCode":"sgas"} ;
    	
        context.setVariable("fault.name","ErrorResponseCode");
        context.setVariable("response.content","JSON.stringify(response)");
        context.setVariable("response.reason.phrase","400");
        context.setVariable("response.status.code","BAD_Request");          
        expect(manageBackendError()).toBe();        
     });  
    it ('Positive 1: Incoming valid  ', function() {    
    	var response = {"errorMessage":"sfsa","errorCode":"sgas"} ;
    	
        context.setVariable("fault.name","ErrorResponseCodea");
        context.setVariable("response.content","JSON.stringify(response)");
        context.setVariable("response.reason.phrase","400");
        context.setVariable("response.status.code","BAD_Request");          
        expect(manageBackendError()).toBe();        
     });  
    
});
