var buildTargetURLTest = require('../jsc/BuildTargetURL/BuildTargetURL');
describe('buildTargetURL Suite', function() {
    beforeEach(function(){
      var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });


 it ('Positive case111: TargetEndPoint Verification for pathsuffix : /getCustomerEligibility ', function() {        
        var target ={
	    "BaaSVoice_TARGET_DEFAULT": {
		"TARGET_HOST": "pal-test.adyen.com",
		"TARGET_PORT": "443",
		"TARGET_ENABLED": true,
		"TARGET_SSL_ENABLED": true,
		"TARGET_SSL_CIPHERS": "",
		"TARGET_SSL_CLIENT_AUTH_ENABLED": true,
		"TARGET_SSL_KEY_STORE": "myKeystore",
		"TARGET_SSL_KEY_ALIAS": "stagingKey",
		"TARGET_SSL_TRUST_STORE": "",
		"TARGET_SSL_PROTOCOLS": "",
		"TARGET_SSL_IGNORE_VALIDATION_ERRORS": ""
	}
     };
        context.setVariable("targets_endpoint_properties",JSON.stringify(target));       
        context.setVariable("currentFlowName","getStatus");        
	    context.setVariable("request.verb","GET"); 
        expect(buildTargetURL()).toBe();
        
    });
    
    it ('Positive case111: TargetEndPoint Verification for pathsuffix : /getCustomerEligibility ', function() {        
        var target ={
	    "BaaSVoice_TARGET_DEFAULT": {
		"TARGET_HOST": "pal-test.adyen.com",
		"TARGET_PORT": "443",
		"TARGET_ENABLED": true,
		"TARGET_SSL_ENABLED": true,
		"TARGET_SSL_CIPHERS": "",
		"TARGET_SSL_CLIENT_AUTH_ENABLED": true,
		"TARGET_SSL_KEY_STORE": "myKeystore",
		"TARGET_SSL_KEY_ALIAS": "stagingKey",
		"TARGET_SSL_TRUST_STORE": "",
		"TARGET_SSL_PROTOCOLS": "",
		"TARGET_SSL_IGNORE_VALIDATION_ERRORS": ""
	}
     };
        context.setVariable("targets_endpoint_properties",JSON.stringify(target));       
        context.setVariable("currentFlowName","getStatus");        
	    context.setVariable("request.verb","GET"); 
        expect(buildTargetURL()).toBe();
        
    });
    
    it ('Positive caseA: TargetEndPoint Verification for pathsuffix : /getCustomerEligibility ', function() {        
        var target ={
	    "BaaSVoice_TARGET_DEFAULT": {
		"TARGET_HOST": "pal-test.adyen.com",
		"TARGET_PORT": "443",
		"TARGET_ENABLED": true,
		"TARGET_SSL_ENABLED": true,
		"TARGET_SSL_CIPHERS": "",
		"TARGET_SSL_CLIENT_AUTH_ENABLED": true,
		"TARGET_SSL_KEY_STORE": "myKeystore",
		"TARGET_SSL_KEY_ALIAS": "stagingKey",
		"TARGET_SSL_TRUST_STORE": "",
		"TARGET_SSL_PROTOCOLS": "",
		"TARGET_SSL_IGNORE_VALIDATION_ERRORS": ""
	}
     };
        context.setVariable("targets_endpoint_properties",JSON.stringify(target));       
        context.setVariable("currentFlowName","getStatus");        
	    context.setVariable("request.verb","GET"); 
        expect(buildTargetURL()).toBe();
        
    });
    
    it ('Positive caseB: TargetEndPoint Verification for pathsuffix : /getCustomerEligibility ', function() {        
        var target ={
	    "BaaSVoice_TARGET_DEFAULT": {
		"TARGET_HOST": "pal-test.adyen.com",
		"TARGET_PORT": "443",
		"TARGET_ENABLED": true,
		"TARGET_SSL_ENABLED": true,
		"TARGET_SSL_CIPHERS": "",
		"TARGET_SSL_CLIENT_AUTH_ENABLED": true,
		"TARGET_SSL_KEY_STORE": "myKeystore",
		"TARGET_SSL_KEY_ALIAS": "stagingKey",
		"TARGET_SSL_TRUST_STORE": "",
		"TARGET_SSL_PROTOCOLS": "",
		"TARGET_SSL_IGNORE_VALIDATION_ERRORS": ""
	}
     };
        context.setVariable("targets_endpoint_properties",JSON.stringify(target));       
        context.setVariable("currentFlowName","checkAudio");        
	    context.setVariable("request.verb","GET"); 
        expect(buildTargetURL()).toBe();
        
    });
    
    it ('Positive caseC: TargetEndPoint Verification for pathsuffix : /getCustomerEligibility ', function() {        
        var target ={
	    "BaaSVoice_TARGET_DEFAULT": {
		"TARGET_HOST": "pal-test.adyen.com",
		"TARGET_PORT": "443",
		"TARGET_ENABLED": true,
		"TARGET_SSL_ENABLED": true,
		"TARGET_SSL_CIPHERS": "",
		"TARGET_SSL_CLIENT_AUTH_ENABLED": true,
		"TARGET_SSL_KEY_STORE": "myKeystore",
		"TARGET_SSL_KEY_ALIAS": "stagingKey",
		"TARGET_SSL_TRUST_STORE": "",
		"TARGET_SSL_PROTOCOLS": "",
		"TARGET_SSL_IGNORE_VALIDATION_ERRORS": ""
	}
     };
        context.setVariable("targets_endpoint_properties",JSON.stringify(target));       
        context.setVariable("currentFlowName","enrollVoicePrint");        
	    context.setVariable("request.verb","GET"); 
        expect(buildTargetURL()).toBe();
        
    });
    
       it ('Positive caseD: TargetEndPoint Verification for pathsuffix : /getCustomerEligibility ', function() {        
        var target ={
	    "BaaSVoice_TARGET_DEFAULT": {
		"TARGET_HOST": "pal-test.adyen.com",
		"TARGET_PORT": "443",
		"TARGET_ENABLED": true,
		"TARGET_SSL_ENABLED": true,
		"TARGET_SSL_CIPHERS": "",
		"TARGET_SSL_CLIENT_AUTH_ENABLED": true,
		"TARGET_SSL_KEY_STORE": "myKeystore",
		"TARGET_SSL_KEY_ALIAS": "stagingKey",
		"TARGET_SSL_TRUST_STORE": "",
		"TARGET_SSL_PROTOCOLS": "",
		"TARGET_SSL_IGNORE_VALIDATION_ERRORS": ""
	}
     };
        context.setVariable("targets_endpoint_properties",JSON.stringify(target));       
        context.setVariable("currentFlowName","authenticateCustomer");        
	    context.setVariable("request.verb","GET"); 
        expect(buildTargetURL()).toBe();
        
    });
    
           it ('Positive caseE: TargetEndPoint Verification for pathsuffix : /getCustomerEligibility ', function() {        
        var target ={
	    "BaaSVoice_TARGET_DEFAULT": {
		"TARGET_HOST": "pal-test.adyen.com",
		"TARGET_PORT": "443",
		"TARGET_ENABLED": true,
		"TARGET_SSL_ENABLED": false,
		"TARGET_SSL_CIPHERS": "",
		"TARGET_SSL_CLIENT_AUTH_ENABLED": true,
		"TARGET_SSL_KEY_STORE": "myKeystore",
		"TARGET_SSL_KEY_ALIAS": "stagingKey",
		"TARGET_SSL_TRUST_STORE": "",
		"TARGET_SSL_PROTOCOLS": "",
		"TARGET_SSL_IGNORE_VALIDATION_ERRORS": ""
	}
     };
        context.setVariable("targets_endpoint_properties",JSON.stringify(target));       
        context.setVariable("currentFlowName","authenticateCustomer");        
	    context.setVariable("request.verb","GET"); 
        expect(buildTargetURL()).toBe();
        
    });
    
  	    it ('Positive caseE: TargetEndPoint Verification for pathsuffix : /getCustomerEligibility ', function() {        
        var target ={
	    "BaaSVoice_TARGET_DEFAULT": {
		"TARGET_HOST": "pal-test.adyen.com",
		"TARGET_PORT": "443",
		"TARGET_ENABLED": true,
		"TARGET_SSL_ENABLED": false,
		"TARGET_SSL_CIPHERS": "",
		"TARGET_SSL_CLIENT_AUTH_ENABLED": true,
		"TARGET_SSL_KEY_STORE": "myKeystore",
		"TARGET_SSL_KEY_ALIAS": "stagingKey",
		"TARGET_SSL_TRUST_STORE": "",
		"TARGET_SSL_PROTOCOLS": "",
		"TARGET_SSL_IGNORE_VALIDATION_ERRORS": ""
	}
     };
        context.setVariable("targets_endpoint_properties",JSON.stringify(target));       
        context.setVariable("currentFlowName","deleteVoicePrint");        
	    context.setVariable("request.verb","DELETE"); 
        expect(buildTargetURL()).toBe();
        
    });  


     it ('Positive case 1: TargetURL Verification for default Target for ES country', function() {
		context.setVariable("proxy.pathsuffix","/invites");
		context.setVariable("targets_endpoint_properties",'{"DEFAULT_TARGET": {"TARGET_HOST": "trusted-contacts-backend.smartlife.vodafo.ne","TARGET_PORT": "443","TARGET_ENABLED": true,"TARGET_SSL_ENABLED": true,"TARGET_SSL_CIPHERS": "","TARGET_SSL_CLIENT_AUTH_ENABLED": false,"TARGET_SSL_KEY_STORE": "","TARGET_SSL_KEY_ALIAS": "","TARGET_SSL_TRUST_STORE": "","TARGET_SSL_PROTOCOLS": "TLSv1.1,TLSv1.2","TARGET_SSL_IGNORE_VALIDATION_ERRORS": "false"},"TRUSTED_CONTACTS_TARGET_STUB": {"TARGET_HOST": "apidev.developer.vodafone.com/TrustedContactsStub","TARGET_PORT": "443","TARGET_ENABLED": true,"TARGET_SSL_ENABLED": true,"TARGET_SSL_CIPHERS": "","TARGET_SSL_CLIENT_AUTH_ENABLED": false,"TARGET_SSL_KEY_STORE": "myKeystore","TARGET_SSL_KEY_ALIAS": "stagingKey","TARGET_SSL_TRUST_STORE": "", "TARGET_SSL_PROTOCOLS": "","TARGET_SSL_IGNORE_VALIDATION_ERRORS": "false"}}');
		context.setVariable("request.verb","GET");
        expect(buildTargetURL).toThrow();
    });
     it ('Positive case 2: TargetURL Verification for default Target for ES country', function() {
		context.setVariable("proxy.pathsuffix","/invites/123");
		context.setVariable("targets_endpoint_properties",'{"DEFAULT_TARGET": {"TARGET_HOST": "trusted-contacts-backend.smartlife.vodafo.ne","TARGET_PORT": "443","TARGET_ENABLED": true,"TARGET_SSL_ENABLED": true,"TARGET_SSL_CIPHERS": "","TARGET_SSL_CLIENT_AUTH_ENABLED": false,"TARGET_SSL_KEY_STORE": "","TARGET_SSL_KEY_ALIAS": "","TARGET_SSL_TRUST_STORE": "","TARGET_SSL_PROTOCOLS": "TLSv1.1,TLSv1.2","TARGET_SSL_IGNORE_VALIDATION_ERRORS": "false"},"TRUSTED_CONTACTS_TARGET_STUB": {"TARGET_HOST": "apidev.developer.vodafone.com/TrustedContactsStub","TARGET_PORT": "443","TARGET_ENABLED": true,"TARGET_SSL_ENABLED": true,"TARGET_SSL_CIPHERS": "","TARGET_SSL_CLIENT_AUTH_ENABLED": false,"TARGET_SSL_KEY_STORE": "myKeystore","TARGET_SSL_KEY_ALIAS": "stagingKey","TARGET_SSL_TRUST_STORE": "", "TARGET_SSL_PROTOCOLS": "","TARGET_SSL_IGNORE_VALIDATION_ERRORS": "false"}}');
		context.setVariable("request.verb","GET");
        expect(buildTargetURL).toThrow();
    });
    
     it ('Positive case 3: TargetURL Verification for default Target for ES country', function() {
		context.setVariable("proxy.pathsuffix","/shares/");
		context.setVariable("targets_endpoint_properties",'{"DEFAULT_TARGET": {"TARGET_HOST": "trusted-contacts-backend.smartlife.vodafo.ne","TARGET_PORT": "443","TARGET_ENABLED": true,"TARGET_SSL_ENABLED": true,"TARGET_SSL_CIPHERS": "","TARGET_SSL_CLIENT_AUTH_ENABLED": false,"TARGET_SSL_KEY_STORE": "","TARGET_SSL_KEY_ALIAS": "","TARGET_SSL_TRUST_STORE": "","TARGET_SSL_PROTOCOLS": "TLSv1.1,TLSv1.2","TARGET_SSL_IGNORE_VALIDATION_ERRORS": "false"},"TRUSTED_CONTACTS_TARGET_STUB": {"TARGET_HOST": "apidev.developer.vodafone.com/TrustedContactsStub","TARGET_PORT": "443","TARGET_ENABLED": true,"TARGET_SSL_ENABLED": true,"TARGET_SSL_CIPHERS": "","TARGET_SSL_CLIENT_AUTH_ENABLED": false,"TARGET_SSL_KEY_STORE": "myKeystore","TARGET_SSL_KEY_ALIAS": "stagingKey","TARGET_SSL_TRUST_STORE": "", "TARGET_SSL_PROTOCOLS": "","TARGET_SSL_IGNORE_VALIDATION_ERRORS": "false"}}');
		context.setVariable("request.verb","GET");
        expect(buildTargetURL).toThrow();
    });
	it ('Positive case 4: TargetURL Verification for default Target for ES country', function() {
		context.setVariable("proxy.pathsuffix","/shares/123");
		context.setVariable("targets_endpoint_properties",'{"DEFAULT_TARGET": {"TARGET_HOST": "trusted-contacts-backend.smartlife.vodafo.ne","TARGET_PORT": "443","TARGET_ENABLED": true,"TARGET_SSL_ENABLED": true,"TARGET_SSL_CIPHERS": "","TARGET_SSL_CLIENT_AUTH_ENABLED": false,"TARGET_SSL_KEY_STORE": "","TARGET_SSL_KEY_ALIAS": "","TARGET_SSL_TRUST_STORE": "","TARGET_SSL_PROTOCOLS": "TLSv1.1,TLSv1.2","TARGET_SSL_IGNORE_VALIDATION_ERRORS": "false"},"TRUSTED_CONTACTS_TARGET_STUB": {"TARGET_HOST": "apidev.developer.vodafone.com/TrustedContactsStub","TARGET_PORT": "443","TARGET_ENABLED": true,"TARGET_SSL_ENABLED": true,"TARGET_SSL_CIPHERS": "","TARGET_SSL_CLIENT_AUTH_ENABLED": false,"TARGET_SSL_KEY_STORE": "myKeystore","TARGET_SSL_KEY_ALIAS": "stagingKey","TARGET_SSL_TRUST_STORE": "", "TARGET_SSL_PROTOCOLS": "","TARGET_SSL_IGNORE_VALIDATION_ERRORS": "false"}}');
		context.setVariable("request.verb","GET");
        expect(buildTargetURL).toThrow();
    });    
   it ('Positive case 5: TargetURL Verification for default Target for ES country', function() {
		//context.setVariable("proxy.pathsuffix","/shares/123");
		context.setVariable("targets_endpoint_properties",'{"DEFAULT_TARGET": {"TARGET_HOST": "trusted-contacts-backend.smartlife.vodafo.ne","TARGET_PORT": "443","TARGET_ENABLED": true,"TARGET_SSL_ENABLED": true,"TARGET_SSL_CIPHERS": "","TARGET_SSL_CLIENT_AUTH_ENABLED": false,"TARGET_SSL_KEY_STORE": "","TARGET_SSL_KEY_ALIAS": "","TARGET_SSL_TRUST_STORE": "","TARGET_SSL_PROTOCOLS": "TLSv1.1,TLSv1.2","TARGET_SSL_IGNORE_VALIDATION_ERRORS": "false"},"TRUSTED_CONTACTS_TARGET_STUB": {"TARGET_HOST": "apidev.developer.vodafone.com/TrustedContactsStub","TARGET_PORT": "443","TARGET_ENABLED": true,"TARGET_SSL_ENABLED": true,"TARGET_SSL_CIPHERS": "","TARGET_SSL_CLIENT_AUTH_ENABLED": false,"TARGET_SSL_KEY_STORE": "myKeystore","TARGET_SSL_KEY_ALIAS": "stagingKey","TARGET_SSL_TRUST_STORE": "", "TARGET_SSL_PROTOCOLS": "","TARGET_SSL_IGNORE_VALIDATION_ERRORS": "false"}}');
		context.setVariable("request.verb","GET");
        expect(buildTargetURL).toThrow();
    });
	it ('Positive case 6: TargetURL Verification for default Target for ES country', function() {
		context.setVariable("proxy.pathsuffix","/shares/123");
		context.setVariable("request.header.vf-target-stub","true");
		context.setVariable("targets_endpoint_properties",'{"DEFAULT_TARGET": {"TARGET_HOST": "trusted-contacts-backend.smartlife.vodafo.ne","TARGET_PORT": "443","TARGET_ENABLED": true,"TARGET_SSL_ENABLED": true,"TARGET_SSL_CIPHERS": "","TARGET_SSL_CLIENT_AUTH_ENABLED": false,"TARGET_SSL_KEY_STORE": "","TARGET_SSL_KEY_ALIAS": "","TARGET_SSL_TRUST_STORE": "","TARGET_SSL_PROTOCOLS": "TLSv1.1,TLSv1.2","TARGET_SSL_IGNORE_VALIDATION_ERRORS": "false"},"TARGET_STUB": {"TARGET_HOST": "apidev.developer.vodafone.com/TrustedContactsStub","TARGET_PORT": "443","TARGET_ENABLED": true,"TARGET_SSL_ENABLED": true,"TARGET_SSL_CIPHERS": "","TARGET_SSL_CLIENT_AUTH_ENABLED": false,"TARGET_SSL_KEY_STORE": "myKeystore","TARGET_SSL_KEY_ALIAS": "stagingKey","TARGET_SSL_TRUST_STORE": "", "TARGET_SSL_PROTOCOLS": "","TARGET_SSL_IGNORE_VALIDATION_ERRORS": "false"}}');
		context.setVariable("request.verb","GET");
        expect(buildTargetURL).toThrow();
    });
	
	it ('Negative case 7: TargetURL Verification for default Target for ES country', function() {
		context.setVariable("proxy.pathsuffix","/shares/123");
		//context.setVariable("request.header.vf-target-stub","true");
		context.setVariable("targets_endpoint_properties",'{"DEFAULT_TARGET": {"TARGET_HOSTA": "trusted-contacts-backend.smartlife.vodafo.ne","TARGET_PORT": "443","TARGET_ENABLED": true,"TARGET_SSL_ENABLED": true,"TARGET_SSL_CIPHERS": "","TARGET_SSL_CLIENT_AUTH_ENABLED": false,"TARGET_SSL_KEY_STORE": "","TARGET_SSL_KEY_ALIAS": "","TARGET_SSL_TRUST_STORE": "","TARGET_SSL_PROTOCOLS": "TLSv1.1,TLSv1.2","TARGET_SSL_IGNORE_VALIDATION_ERRORS": "false"},"TARGET_STUB": {"TARGET_HOST": "apidev.developer.vodafone.com/TrustedContactsStub","TARGET_PORT": "443","TARGET_ENABLED": true,"TARGET_SSL_ENABLED": true,"TARGET_SSL_CIPHERS": "","TARGET_SSL_CLIENT_AUTH_ENABLED": false,"TARGET_SSL_KEY_STORE": "myKeystore","TARGET_SSL_KEY_ALIAS": "stagingKey","TARGET_SSL_TRUST_STORE": "", "TARGET_SSL_PROTOCOLS": "","TARGET_SSL_IGNORE_VALIDATION_ERRORS": "false"}}');
		context.setVariable("request.verb","GET");
        expect(buildTargetURL).toThrow();
    });
    
    it ('Negative case 8: TargetURL Verification for default Target for ES country', function() {
		context.setVariable("proxy.pathsuffix","/shares/123");
		//context.setVariable("request.header.vf-target-stub","true");
		context.setVariable("targets_endpoint_properties","asfd");
		context.setVariable("request.verb","GET");
        expect(buildTargetURL).toThrow();
    });
    
    it ('Negative case 9: TargetURL Verification for default Target for ES country', function() {
		context.setVariable("proxy.pathsuffix","/shares/123");
		context.setVariable("request.header.vf-target-stub","true");
		//context.setVariable("targets_endpoint_properties",'{"DEFAULT_TARGET": {"TARGET_HOST": "trusted-contacts-backend.smartlife.vodafo.ne","TARGET_PORT": "443","TARGET_ENABLED": true,"TARGET_SSL_ENABLED": true,"TARGET_SSL_CIPHERS": "","TARGET_SSL_CLIENT_AUTH_ENABLED": false,"TARGET_SSL_KEY_STORE": "","TARGET_SSL_KEY_ALIAS": "","TARGET_SSL_TRUST_STORE": "","TARGET_SSL_PROTOCOLS": "TLSv1.1,TLSv1.2","TARGET_SSL_IGNORE_VALIDATION_ERRORS": "false"},"TARGET_STUB": {"TARGET_HOST": "apidev.developer.vodafone.com/TrustedContactsStub","TARGET_PORT": "443","TARGET_ENABLED": true,"TARGET_SSL_ENABLED": true,"TARGET_SSL_CIPHERS": "","TARGET_SSL_CLIENT_AUTH_ENABLED": false,"TARGET_SSL_KEY_STORE": "myKeystore","TARGET_SSL_KEY_ALIAS": "stagingKey","TARGET_SSL_TRUST_STORE": "", "TARGET_SSL_PROTOCOLS": "","TARGET_SSL_IGNORE_VALIDATION_ERRORS": "false"}}');
		context.setVariable("request.verb","GET");
        expect(buildTargetURL).toThrow();
    });
});



