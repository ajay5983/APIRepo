var ScopeValidationTest = require('../jsc/ScopeValidation/ScopeValidation');
describe('ScopeValidation Suite', function() {
    beforeEach(function(){
      var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            }
        };
        context = new Context();
    });

    it ('1: Positive: Incoming valid Scope ', function() {
    	context.setVariable("apiScopes","USER_CHECK,OPEN");
        context.setVariable("accesstoken.scope","USER_CHECK");
        context.setVariable("current.flow.name","CustomerInfo");
        context.setVariable("allowedScopes","[{\"flowName\":\"CustomerInfo\",\"allowedScopesList\":\"USER_CHECK,OPEN\"}]");
        context.setVariable("accesstoken.msisdn","9876467123");
        
        expect(scopeValidation()).toBe();         
        expect(context.getVariable("errorJSON")).toBe(undefined);	
    });
    it ('2: Negative: Invalid scope combination', function() {
    	context.setVariable("apiScopes","OPEN");
        context.setVariable("accesstoken.scope","USER_CHECK");
        context.setVariable("current.flow.name","CustomerInfo");
        context.setVariable("allowedScopes","[{\"flowName\":\"CustomerInfo\",\"allowedScopesList\":\"USER_CHECK,OPEN\"}]");
        context.setVariable("accesstoken.msisdn","9876467123");
        
        expect(scopeValidation).toThrow();         
        expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_scope_for_api");	
    });  
    it ('3: Negative: Invalid flow name', function() {
    	context.setVariable("apiScopes","OPEN,USER_CHECK");
        context.setVariable("accesstoken.scope","USER_CHECK");
        context.setVariable("current.flow.name","GET_DOWNLOAD");
        context.setVariable("allowedScopes","[{\"flowName\":\"CustomerInfo\",\"allowedScopesList\":\"USER_CHECK,OPEN\"}]");
        context.setVariable("accesstoken.msisdn","9876467123");
        
        expect(scopeValidation).toThrow();         
        expect(context.getVariable("errorJSON")).toBe("a42_generic_insufficient_scope");
    }); 
    it ('4: Negative: Invalid scope', function() {
        context.setVariable("accesstoken.scope","OPEN");
        context.setVariable("current.flow.name","CustomerInfo");
        context.setVariable("allowedScopes","[{\"flowName\":\"CustomerInfo\",\"allowedScopesList\":\"USER_CHECK,OPEN\"}]");
        context.setVariable("accesstoken.msisdn","9876467123");
        
        expect(scopeValidation).toThrow();         
        expect(context.getVariable("errorJSON")).toBe("a42_generic_invalid_scope_for_api");
    }); 
    
    it ('5: Negative: Invalid scope', function() {
    	context.setVariable("apiScopes","USER_CHECK");
        context.setVariable("accesstoken.scope","USER_CHECK");
        context.setVariable("current.flow.name","CustomerInfo");
        context.setVariable("allowedScopes","[{\"flowName\":\"CustomerInfo\",\"allowedScopesList\":\"OPEN,OAUTH\"}]");
        context.setVariable("accesstoken.msisdn","9876467123");
        
        expect(scopeValidation).toThrow();         
        expect(context.getVariable("errorJSON")).toBe("a42_generic_insufficient_scope");
    }); 
});

