var AssignResponseTest = require('../jsc/AssignResponse/4-JS-AssignResponse');
describe('AssignResponse Suite', function() {
    beforeEach(function(){
      var Context = function(){
        };
        Context.prototype = {
            setVariable: function(propertyName, propertyValue){
            this[propertyName] = propertyValue;
            },
            getVariable: function(propertyName){
              return this[propertyName];
            },
            generateTimeStamp : function(){
              return this;
            }
        };
        context = new Context();
    });

    it ('Positive 1: Set values  ', function() {       
        
		var response = {"errorMessage":"sfsa","errorCode":"sgas"} ;		
		context.setVariable("response.content",JSON.stringify(response));
        expect(assignResponse()).toBe();        
     }); 
             
        
});
